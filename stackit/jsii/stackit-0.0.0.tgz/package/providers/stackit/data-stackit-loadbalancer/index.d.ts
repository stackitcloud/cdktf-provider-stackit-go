import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitLoadbalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Load balancer name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#name DataStackitLoadbalancer#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the Load Balancer is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#project_id DataStackitLoadbalancer#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#region DataStackitLoadbalancer#region}
    */
    readonly region?: string;
}
export interface DataStackitLoadbalancerListenersServerNameIndicators {
    /**
    * A domain name to match in order to pass TLS traffic to the target pool in the current listener
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#name DataStackitLoadbalancer#name}
    */
    readonly name?: string;
}
export declare function dataStackitLoadbalancerListenersServerNameIndicatorsToTerraform(struct?: DataStackitLoadbalancerListenersServerNameIndicators | cdktf.IResolvable): any;
export declare function dataStackitLoadbalancerListenersServerNameIndicatorsToHclTerraform(struct?: DataStackitLoadbalancerListenersServerNameIndicators | cdktf.IResolvable): any;
export declare class DataStackitLoadbalancerListenersServerNameIndicatorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitLoadbalancerListenersServerNameIndicators | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitLoadbalancerListenersServerNameIndicators | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class DataStackitLoadbalancerListenersServerNameIndicatorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataStackitLoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitLoadbalancerListenersServerNameIndicatorsOutputReference;
}
export interface DataStackitLoadbalancerListenersTcp {
}
export declare function dataStackitLoadbalancerListenersTcpToTerraform(struct?: DataStackitLoadbalancerListenersTcp): any;
export declare function dataStackitLoadbalancerListenersTcpToHclTerraform(struct?: DataStackitLoadbalancerListenersTcp): any;
export declare class DataStackitLoadbalancerListenersTcpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerListenersTcp | undefined;
    set internalValue(value: DataStackitLoadbalancerListenersTcp | undefined);
    get idleTimeout(): string;
}
export interface DataStackitLoadbalancerListenersUdp {
}
export declare function dataStackitLoadbalancerListenersUdpToTerraform(struct?: DataStackitLoadbalancerListenersUdp): any;
export declare function dataStackitLoadbalancerListenersUdpToHclTerraform(struct?: DataStackitLoadbalancerListenersUdp): any;
export declare class DataStackitLoadbalancerListenersUdpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerListenersUdp | undefined;
    set internalValue(value: DataStackitLoadbalancerListenersUdp | undefined);
    get idleTimeout(): string;
}
export interface DataStackitLoadbalancerListeners {
    /**
    * A list of domain names to match in order to pass TLS traffic to the target pool in the current listener
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#server_name_indicators DataStackitLoadbalancer#server_name_indicators}
    */
    readonly serverNameIndicators?: DataStackitLoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable;
}
export declare function dataStackitLoadbalancerListenersToTerraform(struct?: DataStackitLoadbalancerListeners): any;
export declare function dataStackitLoadbalancerListenersToHclTerraform(struct?: DataStackitLoadbalancerListeners): any;
export declare class DataStackitLoadbalancerListenersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitLoadbalancerListeners | undefined;
    set internalValue(value: DataStackitLoadbalancerListeners | undefined);
    get displayName(): string;
    get port(): number;
    get protocol(): string;
    private _serverNameIndicators;
    get serverNameIndicators(): DataStackitLoadbalancerListenersServerNameIndicatorsList;
    putServerNameIndicators(value: DataStackitLoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable): void;
    resetServerNameIndicators(): void;
    get serverNameIndicatorsInput(): cdktf.IResolvable | DataStackitLoadbalancerListenersServerNameIndicators[] | undefined;
    get targetPool(): string;
    private _tcp;
    get tcp(): DataStackitLoadbalancerListenersTcpOutputReference;
    private _udp;
    get udp(): DataStackitLoadbalancerListenersUdpOutputReference;
}
export declare class DataStackitLoadbalancerListenersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataStackitLoadbalancerListeners[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitLoadbalancerListenersOutputReference;
}
export interface DataStackitLoadbalancerNetworks {
}
export declare function dataStackitLoadbalancerNetworksToTerraform(struct?: DataStackitLoadbalancerNetworks): any;
export declare function dataStackitLoadbalancerNetworksToHclTerraform(struct?: DataStackitLoadbalancerNetworks): any;
export declare class DataStackitLoadbalancerNetworksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitLoadbalancerNetworks | undefined;
    set internalValue(value: DataStackitLoadbalancerNetworks | undefined);
    get networkId(): string;
    get role(): string;
}
export declare class DataStackitLoadbalancerNetworksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitLoadbalancerNetworksOutputReference;
}
export interface DataStackitLoadbalancerOptionsObservabilityLogs {
}
export declare function dataStackitLoadbalancerOptionsObservabilityLogsToTerraform(struct?: DataStackitLoadbalancerOptionsObservabilityLogs): any;
export declare function dataStackitLoadbalancerOptionsObservabilityLogsToHclTerraform(struct?: DataStackitLoadbalancerOptionsObservabilityLogs): any;
export declare class DataStackitLoadbalancerOptionsObservabilityLogsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerOptionsObservabilityLogs | undefined;
    set internalValue(value: DataStackitLoadbalancerOptionsObservabilityLogs | undefined);
    get credentialsRef(): string;
    get pushUrl(): string;
}
export interface DataStackitLoadbalancerOptionsObservabilityMetrics {
}
export declare function dataStackitLoadbalancerOptionsObservabilityMetricsToTerraform(struct?: DataStackitLoadbalancerOptionsObservabilityMetrics): any;
export declare function dataStackitLoadbalancerOptionsObservabilityMetricsToHclTerraform(struct?: DataStackitLoadbalancerOptionsObservabilityMetrics): any;
export declare class DataStackitLoadbalancerOptionsObservabilityMetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerOptionsObservabilityMetrics | undefined;
    set internalValue(value: DataStackitLoadbalancerOptionsObservabilityMetrics | undefined);
    get credentialsRef(): string;
    get pushUrl(): string;
}
export interface DataStackitLoadbalancerOptionsObservability {
}
export declare function dataStackitLoadbalancerOptionsObservabilityToTerraform(struct?: DataStackitLoadbalancerOptionsObservability): any;
export declare function dataStackitLoadbalancerOptionsObservabilityToHclTerraform(struct?: DataStackitLoadbalancerOptionsObservability): any;
export declare class DataStackitLoadbalancerOptionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerOptionsObservability | undefined;
    set internalValue(value: DataStackitLoadbalancerOptionsObservability | undefined);
    private _logs;
    get logs(): DataStackitLoadbalancerOptionsObservabilityLogsOutputReference;
    private _metrics;
    get metrics(): DataStackitLoadbalancerOptionsObservabilityMetricsOutputReference;
}
export interface DataStackitLoadbalancerOptions {
}
export declare function dataStackitLoadbalancerOptionsToTerraform(struct?: DataStackitLoadbalancerOptions): any;
export declare function dataStackitLoadbalancerOptionsToHclTerraform(struct?: DataStackitLoadbalancerOptions): any;
export declare class DataStackitLoadbalancerOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerOptions | undefined;
    set internalValue(value: DataStackitLoadbalancerOptions | undefined);
    get acl(): string[];
    private _observability;
    get observability(): DataStackitLoadbalancerOptionsObservabilityOutputReference;
    get privateNetworkOnly(): cdktf.IResolvable;
}
export interface DataStackitLoadbalancerTargetPoolsActiveHealthCheck {
}
export declare function dataStackitLoadbalancerTargetPoolsActiveHealthCheckToTerraform(struct?: DataStackitLoadbalancerTargetPoolsActiveHealthCheck): any;
export declare function dataStackitLoadbalancerTargetPoolsActiveHealthCheckToHclTerraform(struct?: DataStackitLoadbalancerTargetPoolsActiveHealthCheck): any;
export declare class DataStackitLoadbalancerTargetPoolsActiveHealthCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerTargetPoolsActiveHealthCheck | undefined;
    set internalValue(value: DataStackitLoadbalancerTargetPoolsActiveHealthCheck | undefined);
    get healthyThreshold(): number;
    get interval(): string;
    get intervalJitter(): string;
    get timeout(): string;
    get unhealthyThreshold(): number;
}
export interface DataStackitLoadbalancerTargetPoolsSessionPersistence {
}
export declare function dataStackitLoadbalancerTargetPoolsSessionPersistenceToTerraform(struct?: DataStackitLoadbalancerTargetPoolsSessionPersistence): any;
export declare function dataStackitLoadbalancerTargetPoolsSessionPersistenceToHclTerraform(struct?: DataStackitLoadbalancerTargetPoolsSessionPersistence): any;
export declare class DataStackitLoadbalancerTargetPoolsSessionPersistenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLoadbalancerTargetPoolsSessionPersistence | undefined;
    set internalValue(value: DataStackitLoadbalancerTargetPoolsSessionPersistence | undefined);
    get useSourceIpAddress(): cdktf.IResolvable;
}
export interface DataStackitLoadbalancerTargetPoolsTargets {
}
export declare function dataStackitLoadbalancerTargetPoolsTargetsToTerraform(struct?: DataStackitLoadbalancerTargetPoolsTargets): any;
export declare function dataStackitLoadbalancerTargetPoolsTargetsToHclTerraform(struct?: DataStackitLoadbalancerTargetPoolsTargets): any;
export declare class DataStackitLoadbalancerTargetPoolsTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitLoadbalancerTargetPoolsTargets | undefined;
    set internalValue(value: DataStackitLoadbalancerTargetPoolsTargets | undefined);
    get displayName(): string;
    get ip(): string;
}
export declare class DataStackitLoadbalancerTargetPoolsTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitLoadbalancerTargetPoolsTargetsOutputReference;
}
export interface DataStackitLoadbalancerTargetPools {
}
export declare function dataStackitLoadbalancerTargetPoolsToTerraform(struct?: DataStackitLoadbalancerTargetPools): any;
export declare function dataStackitLoadbalancerTargetPoolsToHclTerraform(struct?: DataStackitLoadbalancerTargetPools): any;
export declare class DataStackitLoadbalancerTargetPoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitLoadbalancerTargetPools | undefined;
    set internalValue(value: DataStackitLoadbalancerTargetPools | undefined);
    private _activeHealthCheck;
    get activeHealthCheck(): DataStackitLoadbalancerTargetPoolsActiveHealthCheckOutputReference;
    get name(): string;
    private _sessionPersistence;
    get sessionPersistence(): DataStackitLoadbalancerTargetPoolsSessionPersistenceOutputReference;
    get targetPort(): number;
    private _targets;
    get targets(): DataStackitLoadbalancerTargetPoolsTargetsList;
}
export declare class DataStackitLoadbalancerTargetPoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitLoadbalancerTargetPoolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer stackit_loadbalancer}
*/
export declare class DataStackitLoadbalancer extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_loadbalancer";
    /**
    * Generates CDKTF code for importing a DataStackitLoadbalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitLoadbalancer to import
    * @param importFromId The id of the existing DataStackitLoadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitLoadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/loadbalancer stackit_loadbalancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitLoadbalancerConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitLoadbalancerConfig);
    get disableSecurityGroupAssignment(): cdktf.IResolvable;
    get externalAddress(): string;
    get id(): string;
    private _listeners;
    get listeners(): DataStackitLoadbalancerListenersList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networks;
    get networks(): DataStackitLoadbalancerNetworksList;
    private _options;
    get options(): DataStackitLoadbalancerOptionsOutputReference;
    get planId(): string;
    get privateAddress(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    private _targetPools;
    get targetPools(): DataStackitLoadbalancerTargetPoolsList;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
