# `data_stackit_loadbalancer`

Refer to the Terraform Registry for docs: [`data_stackit_loadbalancer`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/loadbalancer).
