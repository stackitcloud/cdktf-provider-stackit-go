import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EdgecloudKubeconfigConfig extends cdktf.TerraformMetaArguments {
    /**
    * Expiration time of the kubeconfig, in seconds. Minimum is 600, Maximum is 15552000. Defaults to `3600`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#expiration EdgecloudKubeconfig#expiration}
    */
    readonly expiration?: number;
    /**
    * ID of the Edge Cloud instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#instance_id EdgecloudKubeconfig#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Name of the Edge Cloud instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#instance_name EdgecloudKubeconfig#instance_name}
    */
    readonly instanceName?: string;
    /**
    * STACKIT project ID to which the Edge Cloud instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#project_id EdgecloudKubeconfig#project_id}
    */
    readonly projectId: string;
    /**
    * Number of seconds before expiration to trigger recreation of the kubeconfig at.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#recreate_before EdgecloudKubeconfig#recreate_before}
    */
    readonly recreateBefore?: number;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#region EdgecloudKubeconfig#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig stackit_edgecloud_kubeconfig}
*/
export declare class EdgecloudKubeconfig extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_edgecloud_kubeconfig";
    /**
    * Generates CDKTF code for importing a EdgecloudKubeconfig resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EdgecloudKubeconfig to import
    * @param importFromId The id of the existing EdgecloudKubeconfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EdgecloudKubeconfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/edgecloud_kubeconfig stackit_edgecloud_kubeconfig} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EdgecloudKubeconfigConfig
    */
    constructor(scope: Construct, id: string, config: EdgecloudKubeconfigConfig);
    get creationTime(): string;
    private _expiration?;
    get expiration(): number;
    set expiration(value: number);
    resetExpiration(): void;
    get expirationInput(): number | undefined;
    get expiresAt(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    resetInstanceName(): void;
    get instanceNameInput(): string | undefined;
    get kubeconfig(): string;
    get kubeconfigId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _recreateBefore?;
    get recreateBefore(): number;
    set recreateBefore(value: number);
    resetRecreateBefore(): void;
    get recreateBeforeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
