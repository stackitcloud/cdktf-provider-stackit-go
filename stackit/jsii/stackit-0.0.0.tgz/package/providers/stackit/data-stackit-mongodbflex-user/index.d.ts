import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitMongodbflexUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the MongoDB Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user#instance_id DataStackitMongodbflexUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user#project_id DataStackitMongodbflexUser#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user#region DataStackitMongodbflexUser#region}
    */
    readonly region?: string;
    /**
    * User ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user#user_id DataStackitMongodbflexUser#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user stackit_mongodbflex_user}
*/
export declare class DataStackitMongodbflexUser extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_mongodbflex_user";
    /**
    * Generates CDKTF code for importing a DataStackitMongodbflexUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitMongodbflexUser to import
    * @param importFromId The id of the existing DataStackitMongodbflexUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitMongodbflexUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/mongodbflex_user stackit_mongodbflex_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitMongodbflexUserConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitMongodbflexUserConfig);
    get database(): string;
    get host(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roles(): string[];
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
