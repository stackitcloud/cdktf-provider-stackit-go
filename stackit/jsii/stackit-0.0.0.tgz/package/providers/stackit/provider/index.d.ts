import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface StackitProviderConfig {
    /**
    * Custom endpoint for the Membership service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#authorization_custom_endpoint StackitProvider#authorization_custom_endpoint}
    */
    readonly authorizationCustomEndpoint?: string;
    /**
    * Custom endpoint for the CDN service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#cdn_custom_endpoint StackitProvider#cdn_custom_endpoint}
    */
    readonly cdnCustomEndpoint?: string;
    /**
    * Path of JSON from where the credentials are read. Takes precedence over the env var `STACKIT_CREDENTIALS_PATH`. Default value is `~/.stackit/credentials.json`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#credentials_path StackitProvider#credentials_path}
    */
    readonly credentialsPath?: string;
    /**
    * Region will be used as the default location for regional services. Not all services require a region, some are global
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#default_region StackitProvider#default_region}
    */
    readonly defaultRegion?: string;
    /**
    * Custom endpoint for the DNS service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#dns_custom_endpoint StackitProvider#dns_custom_endpoint}
    */
    readonly dnsCustomEndpoint?: string;
    /**
    * Custom endpoint for the Edge Cloud service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#edgecloud_custom_endpoint StackitProvider#edgecloud_custom_endpoint}
    */
    readonly edgecloudCustomEndpoint?: string;
    /**
    * Enable beta resources. Default is false.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#enable_beta_resources StackitProvider#enable_beta_resources}
    */
    readonly enableBetaResources?: boolean | cdktf.IResolvable;
    /**
    * Enables experiments. These are unstable features without official support. More information can be found in the README. Available Experiments: iam, routing-tables, network
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#experiments StackitProvider#experiments}
    */
    readonly experiments?: string[];
    /**
    * Custom endpoint for the Git service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#git_custom_endpoint StackitProvider#git_custom_endpoint}
    */
    readonly gitCustomEndpoint?: string;
    /**
    * Custom endpoint for the IaaS service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#iaas_custom_endpoint StackitProvider#iaas_custom_endpoint}
    */
    readonly iaasCustomEndpoint?: string;
    /**
    * Custom endpoint for the KMS service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#kms_custom_endpoint StackitProvider#kms_custom_endpoint}
    */
    readonly kmsCustomEndpoint?: string;
    /**
    * Custom endpoint for the Load Balancer service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#loadbalancer_custom_endpoint StackitProvider#loadbalancer_custom_endpoint}
    */
    readonly loadbalancerCustomEndpoint?: string;
    /**
    * Custom endpoint for the LogMe service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#logme_custom_endpoint StackitProvider#logme_custom_endpoint}
    */
    readonly logmeCustomEndpoint?: string;
    /**
    * Custom endpoint for the Logs service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#logs_custom_endpoint StackitProvider#logs_custom_endpoint}
    */
    readonly logsCustomEndpoint?: string;
    /**
    * Custom endpoint for the MariaDB service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#mariadb_custom_endpoint StackitProvider#mariadb_custom_endpoint}
    */
    readonly mariadbCustomEndpoint?: string;
    /**
    * Custom endpoint for the AI Model Serving service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#modelserving_custom_endpoint StackitProvider#modelserving_custom_endpoint}
    */
    readonly modelservingCustomEndpoint?: string;
    /**
    * Custom endpoint for the MongoDB Flex service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#mongodbflex_custom_endpoint StackitProvider#mongodbflex_custom_endpoint}
    */
    readonly mongodbflexCustomEndpoint?: string;
    /**
    * Custom endpoint for the Object Storage service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#objectstorage_custom_endpoint StackitProvider#objectstorage_custom_endpoint}
    */
    readonly objectstorageCustomEndpoint?: string;
    /**
    * Custom endpoint for the Observability service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#observability_custom_endpoint StackitProvider#observability_custom_endpoint}
    */
    readonly observabilityCustomEndpoint?: string;
    /**
    * The bearer token for the request to the OIDC provider. For use when authenticating as a Service Account using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#oidc_request_token StackitProvider#oidc_request_token}
    */
    readonly oidcRequestToken?: string;
    /**
    * The URL for the OIDC provider from which to request an ID token. For use when authenticating as a Service Account using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#oidc_request_url StackitProvider#oidc_request_url}
    */
    readonly oidcRequestUrl?: string;
    /**
    * Custom endpoint for the OpenSearch service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#opensearch_custom_endpoint StackitProvider#opensearch_custom_endpoint}
    */
    readonly opensearchCustomEndpoint?: string;
    /**
    * Custom endpoint for the PostgresFlex service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#postgresflex_custom_endpoint StackitProvider#postgresflex_custom_endpoint}
    */
    readonly postgresflexCustomEndpoint?: string;
    /**
    * Private RSA key used for authentication, relevant for the key flow. It takes precedence over the private key that is included in the service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#private_key StackitProvider#private_key}
    */
    readonly privateKey?: string;
    /**
    * Path for the private RSA key used for authentication, relevant for the key flow. It takes precedence over the private key that is included in the service account key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#private_key_path StackitProvider#private_key_path}
    */
    readonly privateKeyPath?: string;
    /**
    * Custom endpoint for the RabbitMQ service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#rabbitmq_custom_endpoint StackitProvider#rabbitmq_custom_endpoint}
    */
    readonly rabbitmqCustomEndpoint?: string;
    /**
    * Custom endpoint for the Redis service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#redis_custom_endpoint StackitProvider#redis_custom_endpoint}
    */
    readonly redisCustomEndpoint?: string;
    /**
    * Region will be used as the default location for regional services. Not all services require a region, some are global
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#region StackitProvider#region}
    */
    readonly region?: string;
    /**
    * Custom endpoint for the Resource Manager service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#resourcemanager_custom_endpoint StackitProvider#resourcemanager_custom_endpoint}
    */
    readonly resourcemanagerCustomEndpoint?: string;
    /**
    * Custom endpoint for the Cloud Foundry (SCF) service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#scf_custom_endpoint StackitProvider#scf_custom_endpoint}
    */
    readonly scfCustomEndpoint?: string;
    /**
    * Custom endpoint for the Secrets Manager service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#secretsmanager_custom_endpoint StackitProvider#secretsmanager_custom_endpoint}
    */
    readonly secretsmanagerCustomEndpoint?: string;
    /**
    * Custom endpoint for the Server Backup service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#server_backup_custom_endpoint StackitProvider#server_backup_custom_endpoint}
    */
    readonly serverBackupCustomEndpoint?: string;
    /**
    * Custom endpoint for the Server Update service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#server_update_custom_endpoint StackitProvider#server_update_custom_endpoint}
    */
    readonly serverUpdateCustomEndpoint?: string;
    /**
    * Custom endpoint for the Service Account service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_custom_endpoint StackitProvider#service_account_custom_endpoint}
    */
    readonly serviceAccountCustomEndpoint?: string;
    /**
    * Service account email. It can also be set using the environment variable STACKIT_SERVICE_ACCOUNT_EMAIL. It is required if you want to use the resource manager project resource. This value is required using OpenID Connect authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_email StackitProvider#service_account_email}
    */
    readonly serviceAccountEmail?: string;
    /**
    * The OIDC ID token for use when authenticating as a Service Account using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_federated_token StackitProvider#service_account_federated_token}
    */
    readonly serviceAccountFederatedToken?: string;
    /**
    * Path for workload identity assertion. It can also be set using the environment variable STACKIT_FEDERATED_TOKEN_FILE.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_federated_token_path StackitProvider#service_account_federated_token_path}
    */
    readonly serviceAccountFederatedTokenPath?: string;
    /**
    * Service account key used for authentication. If set, the key flow will be used to authenticate all operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_key StackitProvider#service_account_key}
    */
    readonly serviceAccountKey?: string;
    /**
    * Path for the service account key used for authentication. If set, the key flow will be used to authenticate all operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_key_path StackitProvider#service_account_key_path}
    */
    readonly serviceAccountKeyPath?: string;
    /**
    * Token used for authentication. If set, the token flow will be used to authenticate all operations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_account_token StackitProvider#service_account_token}
    */
    readonly serviceAccountToken?: string;
    /**
    * Custom endpoint for the Service Enablement API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#service_enablement_custom_endpoint StackitProvider#service_enablement_custom_endpoint}
    */
    readonly serviceEnablementCustomEndpoint?: string;
    /**
    * Custom endpoint for the Stackit Filestorage API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#sfs_custom_endpoint StackitProvider#sfs_custom_endpoint}
    */
    readonly sfsCustomEndpoint?: string;
    /**
    * Custom endpoint for the Kubernetes Engine (SKE) service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#ske_custom_endpoint StackitProvider#ske_custom_endpoint}
    */
    readonly skeCustomEndpoint?: string;
    /**
    * Custom endpoint for the SQL Server Flex service
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#sqlserverflex_custom_endpoint StackitProvider#sqlserverflex_custom_endpoint}
    */
    readonly sqlserverflexCustomEndpoint?: string;
    /**
    * Custom endpoint for the token API, which is used to request access tokens when using the key flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#token_custom_endpoint StackitProvider#token_custom_endpoint}
    */
    readonly tokenCustomEndpoint?: string;
    /**
    * Enables OIDC for Authentication. This can also be sourced from the `STACKIT_USE_OIDC` Environment Variable. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#use_oidc StackitProvider#use_oidc}
    */
    readonly useOidc?: boolean | cdktf.IResolvable;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#alias StackitProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs stackit}
*/
export declare class StackitProvider extends cdktf.TerraformProvider {
    static readonly tfResourceType = "stackit";
    /**
    * Generates CDKTF code for importing a StackitProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the StackitProvider to import
    * @param importFromId The id of the existing StackitProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the StackitProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs stackit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options StackitProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: StackitProviderConfig);
    private _authorizationCustomEndpoint?;
    get authorizationCustomEndpoint(): string | undefined;
    set authorizationCustomEndpoint(value: string | undefined);
    resetAuthorizationCustomEndpoint(): void;
    get authorizationCustomEndpointInput(): string | undefined;
    private _cdnCustomEndpoint?;
    get cdnCustomEndpoint(): string | undefined;
    set cdnCustomEndpoint(value: string | undefined);
    resetCdnCustomEndpoint(): void;
    get cdnCustomEndpointInput(): string | undefined;
    private _credentialsPath?;
    get credentialsPath(): string | undefined;
    set credentialsPath(value: string | undefined);
    resetCredentialsPath(): void;
    get credentialsPathInput(): string | undefined;
    private _defaultRegion?;
    get defaultRegion(): string | undefined;
    set defaultRegion(value: string | undefined);
    resetDefaultRegion(): void;
    get defaultRegionInput(): string | undefined;
    private _dnsCustomEndpoint?;
    get dnsCustomEndpoint(): string | undefined;
    set dnsCustomEndpoint(value: string | undefined);
    resetDnsCustomEndpoint(): void;
    get dnsCustomEndpointInput(): string | undefined;
    private _edgecloudCustomEndpoint?;
    get edgecloudCustomEndpoint(): string | undefined;
    set edgecloudCustomEndpoint(value: string | undefined);
    resetEdgecloudCustomEndpoint(): void;
    get edgecloudCustomEndpointInput(): string | undefined;
    private _enableBetaResources?;
    get enableBetaResources(): boolean | cdktf.IResolvable | undefined;
    set enableBetaResources(value: boolean | cdktf.IResolvable | undefined);
    resetEnableBetaResources(): void;
    get enableBetaResourcesInput(): boolean | cdktf.IResolvable | undefined;
    private _experiments?;
    get experiments(): string[] | undefined;
    set experiments(value: string[] | undefined);
    resetExperiments(): void;
    get experimentsInput(): string[] | undefined;
    private _gitCustomEndpoint?;
    get gitCustomEndpoint(): string | undefined;
    set gitCustomEndpoint(value: string | undefined);
    resetGitCustomEndpoint(): void;
    get gitCustomEndpointInput(): string | undefined;
    private _iaasCustomEndpoint?;
    get iaasCustomEndpoint(): string | undefined;
    set iaasCustomEndpoint(value: string | undefined);
    resetIaasCustomEndpoint(): void;
    get iaasCustomEndpointInput(): string | undefined;
    private _kmsCustomEndpoint?;
    get kmsCustomEndpoint(): string | undefined;
    set kmsCustomEndpoint(value: string | undefined);
    resetKmsCustomEndpoint(): void;
    get kmsCustomEndpointInput(): string | undefined;
    private _loadbalancerCustomEndpoint?;
    get loadbalancerCustomEndpoint(): string | undefined;
    set loadbalancerCustomEndpoint(value: string | undefined);
    resetLoadbalancerCustomEndpoint(): void;
    get loadbalancerCustomEndpointInput(): string | undefined;
    private _logmeCustomEndpoint?;
    get logmeCustomEndpoint(): string | undefined;
    set logmeCustomEndpoint(value: string | undefined);
    resetLogmeCustomEndpoint(): void;
    get logmeCustomEndpointInput(): string | undefined;
    private _logsCustomEndpoint?;
    get logsCustomEndpoint(): string | undefined;
    set logsCustomEndpoint(value: string | undefined);
    resetLogsCustomEndpoint(): void;
    get logsCustomEndpointInput(): string | undefined;
    private _mariadbCustomEndpoint?;
    get mariadbCustomEndpoint(): string | undefined;
    set mariadbCustomEndpoint(value: string | undefined);
    resetMariadbCustomEndpoint(): void;
    get mariadbCustomEndpointInput(): string | undefined;
    private _modelservingCustomEndpoint?;
    get modelservingCustomEndpoint(): string | undefined;
    set modelservingCustomEndpoint(value: string | undefined);
    resetModelservingCustomEndpoint(): void;
    get modelservingCustomEndpointInput(): string | undefined;
    private _mongodbflexCustomEndpoint?;
    get mongodbflexCustomEndpoint(): string | undefined;
    set mongodbflexCustomEndpoint(value: string | undefined);
    resetMongodbflexCustomEndpoint(): void;
    get mongodbflexCustomEndpointInput(): string | undefined;
    private _objectstorageCustomEndpoint?;
    get objectstorageCustomEndpoint(): string | undefined;
    set objectstorageCustomEndpoint(value: string | undefined);
    resetObjectstorageCustomEndpoint(): void;
    get objectstorageCustomEndpointInput(): string | undefined;
    private _observabilityCustomEndpoint?;
    get observabilityCustomEndpoint(): string | undefined;
    set observabilityCustomEndpoint(value: string | undefined);
    resetObservabilityCustomEndpoint(): void;
    get observabilityCustomEndpointInput(): string | undefined;
    private _oidcRequestToken?;
    get oidcRequestToken(): string | undefined;
    set oidcRequestToken(value: string | undefined);
    resetOidcRequestToken(): void;
    get oidcRequestTokenInput(): string | undefined;
    private _oidcRequestUrl?;
    get oidcRequestUrl(): string | undefined;
    set oidcRequestUrl(value: string | undefined);
    resetOidcRequestUrl(): void;
    get oidcRequestUrlInput(): string | undefined;
    private _opensearchCustomEndpoint?;
    get opensearchCustomEndpoint(): string | undefined;
    set opensearchCustomEndpoint(value: string | undefined);
    resetOpensearchCustomEndpoint(): void;
    get opensearchCustomEndpointInput(): string | undefined;
    private _postgresflexCustomEndpoint?;
    get postgresflexCustomEndpoint(): string | undefined;
    set postgresflexCustomEndpoint(value: string | undefined);
    resetPostgresflexCustomEndpoint(): void;
    get postgresflexCustomEndpointInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string | undefined;
    set privateKey(value: string | undefined);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyPath?;
    get privateKeyPath(): string | undefined;
    set privateKeyPath(value: string | undefined);
    resetPrivateKeyPath(): void;
    get privateKeyPathInput(): string | undefined;
    private _rabbitmqCustomEndpoint?;
    get rabbitmqCustomEndpoint(): string | undefined;
    set rabbitmqCustomEndpoint(value: string | undefined);
    resetRabbitmqCustomEndpoint(): void;
    get rabbitmqCustomEndpointInput(): string | undefined;
    private _redisCustomEndpoint?;
    get redisCustomEndpoint(): string | undefined;
    set redisCustomEndpoint(value: string | undefined);
    resetRedisCustomEndpoint(): void;
    get redisCustomEndpointInput(): string | undefined;
    private _region?;
    get region(): string | undefined;
    set region(value: string | undefined);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcemanagerCustomEndpoint?;
    get resourcemanagerCustomEndpoint(): string | undefined;
    set resourcemanagerCustomEndpoint(value: string | undefined);
    resetResourcemanagerCustomEndpoint(): void;
    get resourcemanagerCustomEndpointInput(): string | undefined;
    private _scfCustomEndpoint?;
    get scfCustomEndpoint(): string | undefined;
    set scfCustomEndpoint(value: string | undefined);
    resetScfCustomEndpoint(): void;
    get scfCustomEndpointInput(): string | undefined;
    private _secretsmanagerCustomEndpoint?;
    get secretsmanagerCustomEndpoint(): string | undefined;
    set secretsmanagerCustomEndpoint(value: string | undefined);
    resetSecretsmanagerCustomEndpoint(): void;
    get secretsmanagerCustomEndpointInput(): string | undefined;
    private _serverBackupCustomEndpoint?;
    get serverBackupCustomEndpoint(): string | undefined;
    set serverBackupCustomEndpoint(value: string | undefined);
    resetServerBackupCustomEndpoint(): void;
    get serverBackupCustomEndpointInput(): string | undefined;
    private _serverUpdateCustomEndpoint?;
    get serverUpdateCustomEndpoint(): string | undefined;
    set serverUpdateCustomEndpoint(value: string | undefined);
    resetServerUpdateCustomEndpoint(): void;
    get serverUpdateCustomEndpointInput(): string | undefined;
    private _serviceAccountCustomEndpoint?;
    get serviceAccountCustomEndpoint(): string | undefined;
    set serviceAccountCustomEndpoint(value: string | undefined);
    resetServiceAccountCustomEndpoint(): void;
    get serviceAccountCustomEndpointInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string | undefined;
    set serviceAccountEmail(value: string | undefined);
    resetServiceAccountEmail(): void;
    get serviceAccountEmailInput(): string | undefined;
    private _serviceAccountFederatedToken?;
    get serviceAccountFederatedToken(): string | undefined;
    set serviceAccountFederatedToken(value: string | undefined);
    resetServiceAccountFederatedToken(): void;
    get serviceAccountFederatedTokenInput(): string | undefined;
    private _serviceAccountFederatedTokenPath?;
    get serviceAccountFederatedTokenPath(): string | undefined;
    set serviceAccountFederatedTokenPath(value: string | undefined);
    resetServiceAccountFederatedTokenPath(): void;
    get serviceAccountFederatedTokenPathInput(): string | undefined;
    private _serviceAccountKey?;
    get serviceAccountKey(): string | undefined;
    set serviceAccountKey(value: string | undefined);
    resetServiceAccountKey(): void;
    get serviceAccountKeyInput(): string | undefined;
    private _serviceAccountKeyPath?;
    get serviceAccountKeyPath(): string | undefined;
    set serviceAccountKeyPath(value: string | undefined);
    resetServiceAccountKeyPath(): void;
    get serviceAccountKeyPathInput(): string | undefined;
    private _serviceAccountToken?;
    get serviceAccountToken(): string | undefined;
    set serviceAccountToken(value: string | undefined);
    resetServiceAccountToken(): void;
    get serviceAccountTokenInput(): string | undefined;
    private _serviceEnablementCustomEndpoint?;
    get serviceEnablementCustomEndpoint(): string | undefined;
    set serviceEnablementCustomEndpoint(value: string | undefined);
    resetServiceEnablementCustomEndpoint(): void;
    get serviceEnablementCustomEndpointInput(): string | undefined;
    private _sfsCustomEndpoint?;
    get sfsCustomEndpoint(): string | undefined;
    set sfsCustomEndpoint(value: string | undefined);
    resetSfsCustomEndpoint(): void;
    get sfsCustomEndpointInput(): string | undefined;
    private _skeCustomEndpoint?;
    get skeCustomEndpoint(): string | undefined;
    set skeCustomEndpoint(value: string | undefined);
    resetSkeCustomEndpoint(): void;
    get skeCustomEndpointInput(): string | undefined;
    private _sqlserverflexCustomEndpoint?;
    get sqlserverflexCustomEndpoint(): string | undefined;
    set sqlserverflexCustomEndpoint(value: string | undefined);
    resetSqlserverflexCustomEndpoint(): void;
    get sqlserverflexCustomEndpointInput(): string | undefined;
    private _tokenCustomEndpoint?;
    get tokenCustomEndpoint(): string | undefined;
    set tokenCustomEndpoint(value: string | undefined);
    resetTokenCustomEndpoint(): void;
    get tokenCustomEndpointInput(): string | undefined;
    private _useOidc?;
    get useOidc(): boolean | cdktf.IResolvable | undefined;
    set useOidc(value: boolean | cdktf.IResolvable | undefined);
    resetUseOidc(): void;
    get useOidcInput(): boolean | cdktf.IResolvable | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
