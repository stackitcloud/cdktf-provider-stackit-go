import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitRoutingTableRoutesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes#network_area_id DataStackitRoutingTableRoutes#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes#organization_id DataStackitRoutingTableRoutes#organization_id}
    */
    readonly organizationId: string;
    /**
    * The datasource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes#region DataStackitRoutingTableRoutes#region}
    */
    readonly region?: string;
    /**
    * The routing tables ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes#routing_table_id DataStackitRoutingTableRoutes#routing_table_id}
    */
    readonly routingTableId: string;
}
export interface DataStackitRoutingTableRoutesRoutesDestination {
}
export declare function dataStackitRoutingTableRoutesRoutesDestinationToTerraform(struct?: DataStackitRoutingTableRoutesRoutesDestination): any;
export declare function dataStackitRoutingTableRoutesRoutesDestinationToHclTerraform(struct?: DataStackitRoutingTableRoutesRoutesDestination): any;
export declare class DataStackitRoutingTableRoutesRoutesDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitRoutingTableRoutesRoutesDestination | undefined;
    set internalValue(value: DataStackitRoutingTableRoutesRoutesDestination | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitRoutingTableRoutesRoutesNextHop {
}
export declare function dataStackitRoutingTableRoutesRoutesNextHopToTerraform(struct?: DataStackitRoutingTableRoutesRoutesNextHop): any;
export declare function dataStackitRoutingTableRoutesRoutesNextHopToHclTerraform(struct?: DataStackitRoutingTableRoutesRoutesNextHop): any;
export declare class DataStackitRoutingTableRoutesRoutesNextHopOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitRoutingTableRoutesRoutesNextHop | undefined;
    set internalValue(value: DataStackitRoutingTableRoutesRoutesNextHop | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitRoutingTableRoutesRoutes {
}
export declare function dataStackitRoutingTableRoutesRoutesToTerraform(struct?: DataStackitRoutingTableRoutesRoutes): any;
export declare function dataStackitRoutingTableRoutesRoutesToHclTerraform(struct?: DataStackitRoutingTableRoutesRoutes): any;
export declare class DataStackitRoutingTableRoutesRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitRoutingTableRoutesRoutes | undefined;
    set internalValue(value: DataStackitRoutingTableRoutesRoutes | undefined);
    get createdAt(): string;
    private _destination;
    get destination(): DataStackitRoutingTableRoutesRoutesDestinationOutputReference;
    private _labels;
    get labels(): cdktf.StringMap;
    private _nextHop;
    get nextHop(): DataStackitRoutingTableRoutesRoutesNextHopOutputReference;
    get routeId(): string;
    get updatedAt(): string;
}
export declare class DataStackitRoutingTableRoutesRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitRoutingTableRoutesRoutesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes stackit_routing_table_routes}
*/
export declare class DataStackitRoutingTableRoutes extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_routing_table_routes";
    /**
    * Generates CDKTF code for importing a DataStackitRoutingTableRoutes resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitRoutingTableRoutes to import
    * @param importFromId The id of the existing DataStackitRoutingTableRoutes that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitRoutingTableRoutes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/routing_table_routes stackit_routing_table_routes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitRoutingTableRoutesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitRoutingTableRoutesConfig);
    get id(): string;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routes;
    get routes(): DataStackitRoutingTableRoutesRoutesList;
    private _routingTableId?;
    get routingTableId(): string;
    set routingTableId(value: string);
    get routingTableIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
