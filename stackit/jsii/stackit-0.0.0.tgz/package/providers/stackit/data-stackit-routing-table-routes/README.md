# `data_stackit_routing_table_routes`

Refer to the Terraform Registry for docs: [`data_stackit_routing_table_routes`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/routing_table_routes).
