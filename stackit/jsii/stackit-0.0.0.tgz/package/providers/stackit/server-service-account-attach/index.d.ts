import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerServiceAccountAttachConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the service account attachment is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach#project_id ServerServiceAccountAttach#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach#region ServerServiceAccountAttach#region}
    */
    readonly region?: string;
    /**
    * The server ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach#server_id ServerServiceAccountAttach#server_id}
    */
    readonly serverId: string;
    /**
    * The service account email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach#service_account_email ServerServiceAccountAttach#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach stackit_server_service_account_attach}
*/
export declare class ServerServiceAccountAttach extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_service_account_attach";
    /**
    * Generates CDKTF code for importing a ServerServiceAccountAttach resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerServiceAccountAttach to import
    * @param importFromId The id of the existing ServerServiceAccountAttach that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerServiceAccountAttach to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/server_service_account_attach stackit_server_service_account_attach} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerServiceAccountAttachConfig
    */
    constructor(scope: Construct, id: string, config: ServerServiceAccountAttachConfig);
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
