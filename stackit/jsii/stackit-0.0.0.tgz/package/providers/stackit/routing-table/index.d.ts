import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RoutingTableConfig extends cdktf.TerraformMetaArguments {
    /**
    * Description of the routing table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#description RoutingTable#description}
    */
    readonly description?: string;
    /**
    * This controls whether dynamic routes are propagated to this routing table
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#dynamic_routes RoutingTable#dynamic_routes}
    */
    readonly dynamicRoutes?: boolean | cdktf.IResolvable;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#labels RoutingTable#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the routing table.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#name RoutingTable#name}
    */
    readonly name: string;
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#network_area_id RoutingTable#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#organization_id RoutingTable#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#region RoutingTable#region}
    */
    readonly region?: string;
    /**
    * This controls whether the routes for project-to-project communication are created automatically or not.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#system_routes RoutingTable#system_routes}
    */
    readonly systemRoutes?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table stackit_routing_table}
*/
export declare class RoutingTable extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_routing_table";
    /**
    * Generates CDKTF code for importing a RoutingTable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RoutingTable to import
    * @param importFromId The id of the existing RoutingTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RoutingTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/routing_table stackit_routing_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoutingTableConfig
    */
    constructor(scope: Construct, id: string, config: RoutingTableConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dynamicRoutes?;
    get dynamicRoutes(): boolean | cdktf.IResolvable;
    set dynamicRoutes(value: boolean | cdktf.IResolvable);
    resetDynamicRoutes(): void;
    get dynamicRoutesInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routingTableId(): string;
    private _systemRoutes?;
    get systemRoutes(): boolean | cdktf.IResolvable;
    set systemRoutes(value: boolean | cdktf.IResolvable);
    resetSystemRoutes(): void;
    get systemRoutesInput(): boolean | cdktf.IResolvable | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
