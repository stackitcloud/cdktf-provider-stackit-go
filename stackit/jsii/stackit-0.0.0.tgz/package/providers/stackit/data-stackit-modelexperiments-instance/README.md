# `data_stackit_modelexperiments_instance`

Refer to the Terraform Registry for docs: [`data_stackit_modelexperiments_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/modelexperiments_instance).
