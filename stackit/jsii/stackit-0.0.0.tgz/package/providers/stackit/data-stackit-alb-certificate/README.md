# `data_stackit_alb_certificate`

Refer to the Terraform Registry for docs: [`data_stackit_alb_certificate`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/alb_certificate).
