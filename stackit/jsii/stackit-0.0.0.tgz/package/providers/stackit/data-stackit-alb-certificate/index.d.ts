import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAlbCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/alb_certificate#cert_id DataStackitAlbCertificate#cert_id}
    */
    readonly certId: string;
    /**
    * STACKIT project ID to which the certificate is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/alb_certificate#project_id DataStackitAlbCertificate#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/alb_certificate stackit_alb_certificate}
*/
export declare class DataStackitAlbCertificate extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_alb_certificate";
    /**
    * Generates CDKTF code for importing a DataStackitAlbCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAlbCertificate to import
    * @param importFromId The id of the existing DataStackitAlbCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/alb_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAlbCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/alb_certificate stackit_alb_certificate} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAlbCertificateConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAlbCertificateConfig);
    private _certId?;
    get certId(): string;
    set certId(value: string);
    get certIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get publicKey(): string;
    get region(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
