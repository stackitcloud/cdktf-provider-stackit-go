# `data_stackit_vpc`

Refer to the Terraform Registry for docs: [`data_stackit_vpc`](https://registry.terraform.io/providers/stackitcloud/stackit/0.118.0/docs/data-sources/vpc).
