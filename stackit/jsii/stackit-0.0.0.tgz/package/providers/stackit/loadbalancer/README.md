# `stackit_loadbalancer`

Refer to the Terraform Registry for docs: [`stackit_loadbalancer`](https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/resources/loadbalancer).
