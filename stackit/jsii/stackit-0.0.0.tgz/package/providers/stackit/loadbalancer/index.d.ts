import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LoadbalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * If set to true, this will disable the automatic assignment of a security group to the load balancer's targets. This option is primarily used to allow targets that are not within the load balancer's own network or SNA (STACKIT network area). When this is enabled, you are fully responsible for ensuring network connectivity to the targets, including managing all routing and security group rules manually. This setting cannot be changed after the load balancer is created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#disable_security_group_assignment Loadbalancer#disable_security_group_assignment}
    */
    readonly disableSecurityGroupAssignment?: boolean | cdktf.IResolvable;
    /**
    * External Load Balancer IP address where this Load Balancer is exposed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#external_address Loadbalancer#external_address}
    */
    readonly externalAddress?: string;
    /**
    * List of all listeners which will accept traffic. Limited to 20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#listeners Loadbalancer#listeners}
    */
    readonly listeners: LoadbalancerListeners[] | cdktf.IResolvable;
    /**
    * Load balancer name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#name Loadbalancer#name}
    */
    readonly name: string;
    /**
    * List of networks that listeners and targets reside in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#networks Loadbalancer#networks}
    */
    readonly networks: LoadbalancerNetworks[] | cdktf.IResolvable;
    /**
    * Defines any optional functionality you want to have enabled on your load balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#options Loadbalancer#options}
    */
    readonly options?: LoadbalancerOptions;
    /**
    * The service plan ID. If not defined, the default service plan is `p10`. Possible values are: `p10`, `p50`, `p250`, `p750`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#plan_id Loadbalancer#plan_id}
    */
    readonly planId?: string;
    /**
    * STACKIT project ID to which the Load Balancer is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#project_id Loadbalancer#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#region Loadbalancer#region}
    */
    readonly region?: string;
    /**
    * List of all target pools which will be used in the Load Balancer. Limited to 20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#target_pools Loadbalancer#target_pools}
    */
    readonly targetPools: LoadbalancerTargetPools[] | cdktf.IResolvable;
}
export interface LoadbalancerListenersServerNameIndicators {
    /**
    * A domain name to match in order to pass TLS traffic to the target pool in the current listener
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#name Loadbalancer#name}
    */
    readonly name?: string;
}
export declare function loadbalancerListenersServerNameIndicatorsToTerraform(struct?: LoadbalancerListenersServerNameIndicators | cdktf.IResolvable): any;
export declare function loadbalancerListenersServerNameIndicatorsToHclTerraform(struct?: LoadbalancerListenersServerNameIndicators | cdktf.IResolvable): any;
export declare class LoadbalancerListenersServerNameIndicatorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerListenersServerNameIndicators | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerListenersServerNameIndicators | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
}
export declare class LoadbalancerListenersServerNameIndicatorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerListenersServerNameIndicatorsOutputReference;
}
export interface LoadbalancerListenersTcp {
    /**
    * Time after which an idle connection is closed. The default value is set to 300 seconds, and the maximum value is 3600 seconds. The format is a duration and the unit must be seconds. Example: 30s
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#idle_timeout Loadbalancer#idle_timeout}
    */
    readonly idleTimeout?: string;
}
export declare function loadbalancerListenersTcpToTerraform(struct?: LoadbalancerListenersTcp | cdktf.IResolvable): any;
export declare function loadbalancerListenersTcpToHclTerraform(struct?: LoadbalancerListenersTcp | cdktf.IResolvable): any;
export declare class LoadbalancerListenersTcpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerListenersTcp | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerListenersTcp | cdktf.IResolvable | undefined);
    private _idleTimeout?;
    get idleTimeout(): string;
    set idleTimeout(value: string);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): string | undefined;
}
export interface LoadbalancerListenersUdp {
    /**
    * Time after which an idle session is closed. The default value is set to 1 minute, and the maximum value is 2 minutes. The format is a duration and the unit must be seconds. Example: 30s
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#idle_timeout Loadbalancer#idle_timeout}
    */
    readonly idleTimeout?: string;
}
export declare function loadbalancerListenersUdpToTerraform(struct?: LoadbalancerListenersUdp | cdktf.IResolvable): any;
export declare function loadbalancerListenersUdpToHclTerraform(struct?: LoadbalancerListenersUdp | cdktf.IResolvable): any;
export declare class LoadbalancerListenersUdpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerListenersUdp | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerListenersUdp | cdktf.IResolvable | undefined);
    private _idleTimeout?;
    get idleTimeout(): string;
    set idleTimeout(value: string);
    resetIdleTimeout(): void;
    get idleTimeoutInput(): string | undefined;
}
export interface LoadbalancerListeners {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#display_name Loadbalancer#display_name}
    */
    readonly displayName?: string;
    /**
    * Port number where we listen for traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#port Loadbalancer#port}
    */
    readonly port: number;
    /**
    * Protocol is the highest network protocol we understand to load balance. Possible values are: `PROTOCOL_UNSPECIFIED`, `PROTOCOL_TCP`, `PROTOCOL_UDP`, `PROTOCOL_TCP_PROXY`, `PROTOCOL_TLS_PASSTHROUGH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#protocol Loadbalancer#protocol}
    */
    readonly protocol: string;
    /**
    * A list of domain names to match in order to pass TLS traffic to the target pool in the current listener
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#server_name_indicators Loadbalancer#server_name_indicators}
    */
    readonly serverNameIndicators?: LoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable;
    /**
    * Reference target pool by target pool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#target_pool Loadbalancer#target_pool}
    */
    readonly targetPool: string;
    /**
    * Options that are specific to the TCP protocol.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#tcp Loadbalancer#tcp}
    */
    readonly tcp?: LoadbalancerListenersTcp;
    /**
    * Options that are specific to the UDP protocol.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#udp Loadbalancer#udp}
    */
    readonly udp?: LoadbalancerListenersUdp;
}
export declare function loadbalancerListenersToTerraform(struct?: LoadbalancerListeners | cdktf.IResolvable): any;
export declare function loadbalancerListenersToHclTerraform(struct?: LoadbalancerListeners | cdktf.IResolvable): any;
export declare class LoadbalancerListenersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerListeners | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerListeners | cdktf.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _serverNameIndicators;
    get serverNameIndicators(): LoadbalancerListenersServerNameIndicatorsList;
    putServerNameIndicators(value: LoadbalancerListenersServerNameIndicators[] | cdktf.IResolvable): void;
    resetServerNameIndicators(): void;
    get serverNameIndicatorsInput(): cdktf.IResolvable | LoadbalancerListenersServerNameIndicators[] | undefined;
    private _targetPool?;
    get targetPool(): string;
    set targetPool(value: string);
    get targetPoolInput(): string | undefined;
    private _tcp;
    get tcp(): LoadbalancerListenersTcpOutputReference;
    putTcp(value: LoadbalancerListenersTcp): void;
    resetTcp(): void;
    get tcpInput(): cdktf.IResolvable | LoadbalancerListenersTcp | undefined;
    private _udp;
    get udp(): LoadbalancerListenersUdpOutputReference;
    putUdp(value: LoadbalancerListenersUdp): void;
    resetUdp(): void;
    get udpInput(): cdktf.IResolvable | LoadbalancerListenersUdp | undefined;
}
export declare class LoadbalancerListenersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoadbalancerListeners[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerListenersOutputReference;
}
export interface LoadbalancerNetworks {
    /**
    * Openstack network ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#network_id Loadbalancer#network_id}
    */
    readonly networkId: string;
    /**
    * The role defines how the load balancer is using the network. Possible values are: `ROLE_UNSPECIFIED`, `ROLE_LISTENERS_AND_TARGETS`, `ROLE_LISTENERS`, `ROLE_TARGETS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#role Loadbalancer#role}
    */
    readonly role: string;
}
export declare function loadbalancerNetworksToTerraform(struct?: LoadbalancerNetworks | cdktf.IResolvable): any;
export declare function loadbalancerNetworksToHclTerraform(struct?: LoadbalancerNetworks | cdktf.IResolvable): any;
export declare class LoadbalancerNetworksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerNetworks | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerNetworks | cdktf.IResolvable | undefined);
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export declare class LoadbalancerNetworksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoadbalancerNetworks[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerNetworksOutputReference;
}
export interface LoadbalancerOptionsObservabilityLogs {
    /**
    * Credentials reference for logs. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#credentials_ref Loadbalancer#credentials_ref}
    */
    readonly credentialsRef?: string;
    /**
    * The ARGUS/Loki remote write Push URL to ship the logs to. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#push_url Loadbalancer#push_url}
    */
    readonly pushUrl?: string;
}
export declare function loadbalancerOptionsObservabilityLogsToTerraform(struct?: LoadbalancerOptionsObservabilityLogs | cdktf.IResolvable): any;
export declare function loadbalancerOptionsObservabilityLogsToHclTerraform(struct?: LoadbalancerOptionsObservabilityLogs | cdktf.IResolvable): any;
export declare class LoadbalancerOptionsObservabilityLogsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerOptionsObservabilityLogs | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerOptionsObservabilityLogs | cdktf.IResolvable | undefined);
    private _credentialsRef?;
    get credentialsRef(): string;
    set credentialsRef(value: string);
    resetCredentialsRef(): void;
    get credentialsRefInput(): string | undefined;
    private _pushUrl?;
    get pushUrl(): string;
    set pushUrl(value: string);
    resetPushUrl(): void;
    get pushUrlInput(): string | undefined;
}
export interface LoadbalancerOptionsObservabilityMetrics {
    /**
    * Credentials reference for metrics. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#credentials_ref Loadbalancer#credentials_ref}
    */
    readonly credentialsRef?: string;
    /**
    * The ARGUS/Prometheus remote write Push URL to ship the metrics to. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#push_url Loadbalancer#push_url}
    */
    readonly pushUrl?: string;
}
export declare function loadbalancerOptionsObservabilityMetricsToTerraform(struct?: LoadbalancerOptionsObservabilityMetrics | cdktf.IResolvable): any;
export declare function loadbalancerOptionsObservabilityMetricsToHclTerraform(struct?: LoadbalancerOptionsObservabilityMetrics | cdktf.IResolvable): any;
export declare class LoadbalancerOptionsObservabilityMetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerOptionsObservabilityMetrics | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerOptionsObservabilityMetrics | cdktf.IResolvable | undefined);
    private _credentialsRef?;
    get credentialsRef(): string;
    set credentialsRef(value: string);
    resetCredentialsRef(): void;
    get credentialsRefInput(): string | undefined;
    private _pushUrl?;
    get pushUrl(): string;
    set pushUrl(value: string);
    resetPushUrl(): void;
    get pushUrlInput(): string | undefined;
}
export interface LoadbalancerOptionsObservability {
    /**
    * Observability logs configuration. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#logs Loadbalancer#logs}
    */
    readonly logs?: LoadbalancerOptionsObservabilityLogs;
    /**
    * Observability metrics configuration. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#metrics Loadbalancer#metrics}
    */
    readonly metrics?: LoadbalancerOptionsObservabilityMetrics;
}
export declare function loadbalancerOptionsObservabilityToTerraform(struct?: LoadbalancerOptionsObservability | cdktf.IResolvable): any;
export declare function loadbalancerOptionsObservabilityToHclTerraform(struct?: LoadbalancerOptionsObservability | cdktf.IResolvable): any;
export declare class LoadbalancerOptionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerOptionsObservability | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerOptionsObservability | cdktf.IResolvable | undefined);
    private _logs;
    get logs(): LoadbalancerOptionsObservabilityLogsOutputReference;
    putLogs(value: LoadbalancerOptionsObservabilityLogs): void;
    resetLogs(): void;
    get logsInput(): cdktf.IResolvable | LoadbalancerOptionsObservabilityLogs | undefined;
    private _metrics;
    get metrics(): LoadbalancerOptionsObservabilityMetricsOutputReference;
    putMetrics(value: LoadbalancerOptionsObservabilityMetrics): void;
    resetMetrics(): void;
    get metricsInput(): cdktf.IResolvable | LoadbalancerOptionsObservabilityMetrics | undefined;
}
export interface LoadbalancerOptions {
    /**
    * Load Balancer is accessible only from an IP address in this range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#acl Loadbalancer#acl}
    */
    readonly acl?: string[];
    /**
    * We offer Load Balancer metrics observability via ARGUS or external solutions. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#observability Loadbalancer#observability}
    */
    readonly observability?: LoadbalancerOptionsObservability;
    /**
    * If true, Load Balancer is accessible only via a private network IP address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#private_network_only Loadbalancer#private_network_only}
    */
    readonly privateNetworkOnly?: boolean | cdktf.IResolvable;
}
export declare function loadbalancerOptionsToTerraform(struct?: LoadbalancerOptions | cdktf.IResolvable): any;
export declare function loadbalancerOptionsToHclTerraform(struct?: LoadbalancerOptions | cdktf.IResolvable): any;
export declare class LoadbalancerOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerOptions | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerOptions | cdktf.IResolvable | undefined);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    resetAcl(): void;
    get aclInput(): string[] | undefined;
    private _observability;
    get observability(): LoadbalancerOptionsObservabilityOutputReference;
    putObservability(value: LoadbalancerOptionsObservability): void;
    resetObservability(): void;
    get observabilityInput(): cdktf.IResolvable | LoadbalancerOptionsObservability | undefined;
    private _privateNetworkOnly?;
    get privateNetworkOnly(): boolean | cdktf.IResolvable;
    set privateNetworkOnly(value: boolean | cdktf.IResolvable);
    resetPrivateNetworkOnly(): void;
    get privateNetworkOnlyInput(): boolean | cdktf.IResolvable | undefined;
}
export interface LoadbalancerTargetPoolsActiveHealthCheck {
    /**
    * Healthy threshold of the health checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#healthy_threshold Loadbalancer#healthy_threshold}
    */
    readonly healthyThreshold?: number;
    /**
    * Interval duration of health checking in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#interval Loadbalancer#interval}
    */
    readonly interval?: string;
    /**
    * Interval duration threshold of the health checking in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#interval_jitter Loadbalancer#interval_jitter}
    */
    readonly intervalJitter?: string;
    /**
    * Active health checking timeout duration in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#timeout Loadbalancer#timeout}
    */
    readonly timeout?: string;
    /**
    * Unhealthy threshold of the health checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#unhealthy_threshold Loadbalancer#unhealthy_threshold}
    */
    readonly unhealthyThreshold?: number;
}
export declare function loadbalancerTargetPoolsActiveHealthCheckToTerraform(struct?: LoadbalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable): any;
export declare function loadbalancerTargetPoolsActiveHealthCheckToHclTerraform(struct?: LoadbalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable): any;
export declare class LoadbalancerTargetPoolsActiveHealthCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable | undefined);
    private _healthyThreshold?;
    get healthyThreshold(): number;
    set healthyThreshold(value: number);
    resetHealthyThreshold(): void;
    get healthyThresholdInput(): number | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _intervalJitter?;
    get intervalJitter(): string;
    set intervalJitter(value: string);
    resetIntervalJitter(): void;
    get intervalJitterInput(): string | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    resetTimeout(): void;
    get timeoutInput(): string | undefined;
    private _unhealthyThreshold?;
    get unhealthyThreshold(): number;
    set unhealthyThreshold(value: number);
    resetUnhealthyThreshold(): void;
    get unhealthyThresholdInput(): number | undefined;
}
export interface LoadbalancerTargetPoolsSessionPersistence {
    /**
    * If true then all connections from one source IP address are redirected to the same target. This setting changes the load balancing algorithm to Maglev.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#use_source_ip_address Loadbalancer#use_source_ip_address}
    */
    readonly useSourceIpAddress?: boolean | cdktf.IResolvable;
}
export declare function loadbalancerTargetPoolsSessionPersistenceToTerraform(struct?: LoadbalancerTargetPoolsSessionPersistence | cdktf.IResolvable): any;
export declare function loadbalancerTargetPoolsSessionPersistenceToHclTerraform(struct?: LoadbalancerTargetPoolsSessionPersistence | cdktf.IResolvable): any;
export declare class LoadbalancerTargetPoolsSessionPersistenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LoadbalancerTargetPoolsSessionPersistence | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerTargetPoolsSessionPersistence | cdktf.IResolvable | undefined);
    private _useSourceIpAddress?;
    get useSourceIpAddress(): boolean | cdktf.IResolvable;
    set useSourceIpAddress(value: boolean | cdktf.IResolvable);
    resetUseSourceIpAddress(): void;
    get useSourceIpAddressInput(): boolean | cdktf.IResolvable | undefined;
}
export interface LoadbalancerTargetPoolsTargets {
    /**
    * Target display name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#display_name Loadbalancer#display_name}
    */
    readonly displayName: string;
    /**
    * Target IP
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#ip Loadbalancer#ip}
    */
    readonly ip: string;
}
export declare function loadbalancerTargetPoolsTargetsToTerraform(struct?: LoadbalancerTargetPoolsTargets | cdktf.IResolvable): any;
export declare function loadbalancerTargetPoolsTargetsToHclTerraform(struct?: LoadbalancerTargetPoolsTargets | cdktf.IResolvable): any;
export declare class LoadbalancerTargetPoolsTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerTargetPoolsTargets | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerTargetPoolsTargets | cdktf.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
}
export declare class LoadbalancerTargetPoolsTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoadbalancerTargetPoolsTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerTargetPoolsTargetsOutputReference;
}
export interface LoadbalancerTargetPools {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#active_health_check Loadbalancer#active_health_check}
    */
    readonly activeHealthCheck?: LoadbalancerTargetPoolsActiveHealthCheck;
    /**
    * Target pool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#name Loadbalancer#name}
    */
    readonly name: string;
    /**
    * Here you can setup various session persistence options, so far only "`use_source_ip_address`" is supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#session_persistence Loadbalancer#session_persistence}
    */
    readonly sessionPersistence?: LoadbalancerTargetPoolsSessionPersistence;
    /**
    * Identical port number where each target listens for traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#target_port Loadbalancer#target_port}
    */
    readonly targetPort: number;
    /**
    * List of all targets which will be used in the pool. Limited to 1000.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#targets Loadbalancer#targets}
    */
    readonly targets: LoadbalancerTargetPoolsTargets[] | cdktf.IResolvable;
}
export declare function loadbalancerTargetPoolsToTerraform(struct?: LoadbalancerTargetPools | cdktf.IResolvable): any;
export declare function loadbalancerTargetPoolsToHclTerraform(struct?: LoadbalancerTargetPools | cdktf.IResolvable): any;
export declare class LoadbalancerTargetPoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): LoadbalancerTargetPools | cdktf.IResolvable | undefined;
    set internalValue(value: LoadbalancerTargetPools | cdktf.IResolvable | undefined);
    private _activeHealthCheck;
    get activeHealthCheck(): LoadbalancerTargetPoolsActiveHealthCheckOutputReference;
    putActiveHealthCheck(value: LoadbalancerTargetPoolsActiveHealthCheck): void;
    resetActiveHealthCheck(): void;
    get activeHealthCheckInput(): cdktf.IResolvable | LoadbalancerTargetPoolsActiveHealthCheck | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sessionPersistence;
    get sessionPersistence(): LoadbalancerTargetPoolsSessionPersistenceOutputReference;
    putSessionPersistence(value: LoadbalancerTargetPoolsSessionPersistence): void;
    resetSessionPersistence(): void;
    get sessionPersistenceInput(): cdktf.IResolvable | LoadbalancerTargetPoolsSessionPersistence | undefined;
    private _targetPort?;
    get targetPort(): number;
    set targetPort(value: number);
    get targetPortInput(): number | undefined;
    private _targets;
    get targets(): LoadbalancerTargetPoolsTargetsList;
    putTargets(value: LoadbalancerTargetPoolsTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | LoadbalancerTargetPoolsTargets[] | undefined;
}
export declare class LoadbalancerTargetPoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: LoadbalancerTargetPools[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): LoadbalancerTargetPoolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer stackit_loadbalancer}
*/
export declare class Loadbalancer extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_loadbalancer";
    /**
    * Generates CDKTF code for importing a Loadbalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Loadbalancer to import
    * @param importFromId The id of the existing Loadbalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Loadbalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/loadbalancer stackit_loadbalancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadbalancerConfig
    */
    constructor(scope: Construct, id: string, config: LoadbalancerConfig);
    private _disableSecurityGroupAssignment?;
    get disableSecurityGroupAssignment(): boolean | cdktf.IResolvable;
    set disableSecurityGroupAssignment(value: boolean | cdktf.IResolvable);
    resetDisableSecurityGroupAssignment(): void;
    get disableSecurityGroupAssignmentInput(): boolean | cdktf.IResolvable | undefined;
    private _externalAddress?;
    get externalAddress(): string;
    set externalAddress(value: string);
    resetExternalAddress(): void;
    get externalAddressInput(): string | undefined;
    get id(): string;
    private _listeners;
    get listeners(): LoadbalancerListenersList;
    putListeners(value: LoadbalancerListeners[] | cdktf.IResolvable): void;
    get listenersInput(): cdktf.IResolvable | LoadbalancerListeners[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networks;
    get networks(): LoadbalancerNetworksList;
    putNetworks(value: LoadbalancerNetworks[] | cdktf.IResolvable): void;
    get networksInput(): cdktf.IResolvable | LoadbalancerNetworks[] | undefined;
    private _options;
    get options(): LoadbalancerOptionsOutputReference;
    putOptions(value: LoadbalancerOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktf.IResolvable | LoadbalancerOptions | undefined;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    resetPlanId(): void;
    get planIdInput(): string | undefined;
    get privateAddress(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    private _targetPools;
    get targetPools(): LoadbalancerTargetPoolsList;
    putTargetPools(value: LoadbalancerTargetPools[] | cdktf.IResolvable): void;
    get targetPoolsInput(): cdktf.IResolvable | LoadbalancerTargetPools[] | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
