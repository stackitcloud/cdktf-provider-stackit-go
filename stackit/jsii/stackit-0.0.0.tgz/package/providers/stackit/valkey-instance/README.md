# `stackit_valkey_instance`

Refer to the Terraform Registry for docs: [`stackit_valkey_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/valkey_instance).
