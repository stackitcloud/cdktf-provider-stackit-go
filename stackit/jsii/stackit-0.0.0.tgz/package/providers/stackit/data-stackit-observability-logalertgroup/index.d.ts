import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObservabilityLogalertgroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability instance ID to which the log alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup#instance_id DataStackitObservabilityLogalertgroup#instance_id}
    */
    readonly instanceId: string;
    /**
    * The name of the log alert group. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup#name DataStackitObservabilityLogalertgroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the log alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup#project_id DataStackitObservabilityLogalertgroup#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitObservabilityLogalertgroupRules {
}
export declare function dataStackitObservabilityLogalertgroupRulesToTerraform(struct?: DataStackitObservabilityLogalertgroupRules): any;
export declare function dataStackitObservabilityLogalertgroupRulesToHclTerraform(struct?: DataStackitObservabilityLogalertgroupRules): any;
export declare class DataStackitObservabilityLogalertgroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityLogalertgroupRules | undefined;
    set internalValue(value: DataStackitObservabilityLogalertgroupRules | undefined);
    get alert(): string;
    private _annotations;
    get annotations(): cdktf.StringMap;
    get expression(): string;
    get for(): string;
    private _labels;
    get labels(): cdktf.StringMap;
}
export declare class DataStackitObservabilityLogalertgroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityLogalertgroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup stackit_observability_logalertgroup}
*/
export declare class DataStackitObservabilityLogalertgroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_observability_logalertgroup";
    /**
    * Generates CDKTF code for importing a DataStackitObservabilityLogalertgroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObservabilityLogalertgroup to import
    * @param importFromId The id of the existing DataStackitObservabilityLogalertgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObservabilityLogalertgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/observability_logalertgroup stackit_observability_logalertgroup} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObservabilityLogalertgroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObservabilityLogalertgroupConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get interval(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rules;
    get rules(): DataStackitObservabilityLogalertgroupRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
