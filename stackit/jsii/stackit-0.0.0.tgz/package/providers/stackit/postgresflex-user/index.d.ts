import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PostgresflexUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the PostgresFlex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#instance_id PostgresflexUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#project_id PostgresflexUser#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#region PostgresflexUser#region}
    */
    readonly region?: string;
    /**
    * Database access levels for the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#roles PostgresflexUser#roles}
    */
    readonly roles: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#username PostgresflexUser#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user stackit_postgresflex_user}
*/
export declare class PostgresflexUser extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_postgresflex_user";
    /**
    * Generates CDKTF code for importing a PostgresflexUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresflexUser to import
    * @param importFromId The id of the existing PostgresflexUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresflexUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/postgresflex_user stackit_postgresflex_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresflexUserConfig
    */
    constructor(scope: Construct, id: string, config: PostgresflexUserConfig);
    get host(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roles?;
    get roles(): string[];
    set roles(value: string[]);
    get rolesInput(): string[] | undefined;
    get uri(): string;
    get userId(): string;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
