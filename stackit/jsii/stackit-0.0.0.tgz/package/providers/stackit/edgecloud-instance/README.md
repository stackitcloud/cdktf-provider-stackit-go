# `stackit_edgecloud_instance`

Refer to the Terraform Registry for docs: [`stackit_edgecloud_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/edgecloud_instance).
