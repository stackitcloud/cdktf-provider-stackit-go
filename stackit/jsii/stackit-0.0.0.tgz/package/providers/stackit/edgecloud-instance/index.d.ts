import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EdgecloudInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Description for your STACKIT Edge Cloud instance. Max length is 256 characters
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#description EdgecloudInstance#description}
    */
    readonly description?: string;
    /**
    * Display name shown for the Edge Cloud instance. Has to be a valid hostname, with a length between 4 and 8 characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#display_name EdgecloudInstance#display_name}
    */
    readonly displayName: string;
    /**
    * STACKIT Edge Plan ID for the Edge Cloud instance, has to be the UUID of an existing plan.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#plan_id EdgecloudInstance#plan_id}
    */
    readonly planId: string;
    /**
    * STACKIT project ID to which the Edge Cloud instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#project_id EdgecloudInstance#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region to use for the instance, providers default_region will be used if unset.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#region EdgecloudInstance#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance stackit_edgecloud_instance}
*/
export declare class EdgecloudInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_edgecloud_instance";
    /**
    * Generates CDKTF code for importing a EdgecloudInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EdgecloudInstance to import
    * @param importFromId The id of the existing EdgecloudInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EdgecloudInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/edgecloud_instance stackit_edgecloud_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EdgecloudInstanceConfig
    */
    constructor(scope: Construct, id: string, config: EdgecloudInstanceConfig);
    get created(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get frontendUrl(): string;
    get id(): string;
    get instanceId(): string;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
