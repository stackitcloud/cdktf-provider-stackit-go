# `stackit_secretsmanager_user`

Refer to the Terraform Registry for docs: [`stackit_secretsmanager_user`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/secretsmanager_user).
