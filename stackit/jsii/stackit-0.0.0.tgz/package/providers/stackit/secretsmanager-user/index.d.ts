import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecretsmanagerUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * A user chosen description to differentiate between multiple users. Can't be changed after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user#description SecretsmanagerUser#description}
    */
    readonly description: string;
    /**
    * ID of the Secrets Manager instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user#instance_id SecretsmanagerUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user#project_id SecretsmanagerUser#project_id}
    */
    readonly projectId: string;
    /**
    * If true, the user has writeaccess to the secrets engine.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user#write_enabled SecretsmanagerUser#write_enabled}
    */
    readonly writeEnabled: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user stackit_secretsmanager_user}
*/
export declare class SecretsmanagerUser extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_secretsmanager_user";
    /**
    * Generates CDKTF code for importing a SecretsmanagerUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsmanagerUser to import
    * @param importFromId The id of the existing SecretsmanagerUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsmanagerUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_user stackit_secretsmanager_user} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsmanagerUserConfig
    */
    constructor(scope: Construct, id: string, config: SecretsmanagerUserConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get password(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get userId(): string;
    get username(): string;
    private _writeEnabled?;
    get writeEnabled(): boolean | cdktf.IResolvable;
    set writeEnabled(value: boolean | cdktf.IResolvable);
    get writeEnabledInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
