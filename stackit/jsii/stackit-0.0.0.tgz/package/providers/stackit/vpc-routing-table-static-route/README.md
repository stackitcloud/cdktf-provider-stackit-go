# `stackit_vpc_routing_table_static_route`

Refer to the Terraform Registry for docs: [`stackit_vpc_routing_table_static_route`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/vpc_routing_table_static_route).
