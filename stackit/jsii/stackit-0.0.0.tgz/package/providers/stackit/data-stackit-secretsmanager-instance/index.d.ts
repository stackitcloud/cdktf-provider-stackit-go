import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSecretsmanagerInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Secrets Manager instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/secretsmanager_instance#instance_id DataStackitSecretsmanagerInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/secretsmanager_instance#project_id DataStackitSecretsmanagerInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitSecretsmanagerInstanceKmsKey {
}
export declare function dataStackitSecretsmanagerInstanceKmsKeyToTerraform(struct?: DataStackitSecretsmanagerInstanceKmsKey): any;
export declare function dataStackitSecretsmanagerInstanceKmsKeyToHclTerraform(struct?: DataStackitSecretsmanagerInstanceKmsKey): any;
export declare class DataStackitSecretsmanagerInstanceKmsKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSecretsmanagerInstanceKmsKey | undefined;
    set internalValue(value: DataStackitSecretsmanagerInstanceKmsKey | undefined);
    get keyId(): string;
    get keyRingId(): string;
    get keyVersion(): number;
    get serviceAccountEmail(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/secretsmanager_instance stackit_secretsmanager_instance}
*/
export declare class DataStackitSecretsmanagerInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_secretsmanager_instance";
    /**
    * Generates CDKTF code for importing a DataStackitSecretsmanagerInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSecretsmanagerInstance to import
    * @param importFromId The id of the existing DataStackitSecretsmanagerInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/secretsmanager_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSecretsmanagerInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/secretsmanager_instance stackit_secretsmanager_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSecretsmanagerInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSecretsmanagerInstanceConfig);
    get acls(): string[];
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _kmsKey;
    get kmsKey(): DataStackitSecretsmanagerInstanceKmsKeyOutputReference;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
