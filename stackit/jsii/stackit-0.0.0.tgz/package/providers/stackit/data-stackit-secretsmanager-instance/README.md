# `data_stackit_secretsmanager_instance`

Refer to the Terraform Registry for docs: [`data_stackit_secretsmanager_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/data-sources/secretsmanager_instance).
