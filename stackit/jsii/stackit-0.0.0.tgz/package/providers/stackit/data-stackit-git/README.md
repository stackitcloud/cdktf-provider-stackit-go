# `data_stackit_git`

Refer to the Terraform Registry for docs: [`data_stackit_git`](https://registry.terraform.io/providers/stackitcloud/stackit/0.118.0/docs/data-sources/git).
