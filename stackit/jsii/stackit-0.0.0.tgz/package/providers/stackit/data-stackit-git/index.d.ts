import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitGitConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID linked to the git instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/git#instance_id DataStackitGit#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the git instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/git#project_id DataStackitGit#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/git stackit_git}
*/
export declare class DataStackitGit extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_git";
    /**
    * Generates CDKTF code for importing a DataStackitGit resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitGit to import
    * @param importFromId The id of the existing DataStackitGit that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/git#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitGit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/git stackit_git} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitGitConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitGitConfig);
    get acl(): string[];
    get consumedDisk(): string;
    get consumedObjectStorage(): string;
    get created(): string;
    get flavor(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get url(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
