import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitOpensearchInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the OpenSearch instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/opensearch_instance#instance_id DataStackitOpensearchInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/opensearch_instance#project_id DataStackitOpensearchInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitOpensearchInstanceParameters {
}
export declare function dataStackitOpensearchInstanceParametersToTerraform(struct?: DataStackitOpensearchInstanceParameters): any;
export declare function dataStackitOpensearchInstanceParametersToHclTerraform(struct?: DataStackitOpensearchInstanceParameters): any;
export declare class DataStackitOpensearchInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitOpensearchInstanceParameters | undefined;
    set internalValue(value: DataStackitOpensearchInstanceParameters | undefined);
    get enableMonitoring(): cdktf.IResolvable;
    get graphite(): string;
    get javaGarbageCollector(): string;
    get javaHeapspace(): number;
    get javaMaxmetaspace(): number;
    get maxDiskThreshold(): number;
    get metricsFrequency(): number;
    get metricsPrefix(): string;
    get monitoringInstanceId(): string;
    get plugins(): string[];
    get sgwAcl(): string;
    get syslog(): string[];
    get tlsCiphers(): string[];
    get tlsProtocols(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/opensearch_instance stackit_opensearch_instance}
*/
export declare class DataStackitOpensearchInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_opensearch_instance";
    /**
    * Generates CDKTF code for importing a DataStackitOpensearchInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitOpensearchInstance to import
    * @param importFromId The id of the existing DataStackitOpensearchInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/opensearch_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitOpensearchInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/opensearch_instance stackit_opensearch_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitOpensearchInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitOpensearchInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _parameters;
    get parameters(): DataStackitOpensearchInstanceParametersOutputReference;
    get planId(): string;
    get planName(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
