import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerVolumeAttachConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the volume attachment is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach#project_id ServerVolumeAttach#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach#region ServerVolumeAttach#region}
    */
    readonly region?: string;
    /**
    * The server ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach#server_id ServerVolumeAttach#server_id}
    */
    readonly serverId: string;
    /**
    * The volume ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach#volume_id ServerVolumeAttach#volume_id}
    */
    readonly volumeId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach stackit_server_volume_attach}
*/
export declare class ServerVolumeAttach extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_volume_attach";
    /**
    * Generates CDKTF code for importing a ServerVolumeAttach resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerVolumeAttach to import
    * @param importFromId The id of the existing ServerVolumeAttach that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerVolumeAttach to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server_volume_attach stackit_server_volume_attach} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerVolumeAttachConfig
    */
    constructor(scope: Construct, id: string, config: ServerVolumeAttachConfig);
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
