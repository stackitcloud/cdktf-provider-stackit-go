import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerUpdateEnableConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID to which the server update enable is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable#project_id ServerUpdateEnable#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable#region ServerUpdateEnable#region}
    */
    readonly region?: string;
    /**
    * Server ID to which the server update enable is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable#server_id ServerUpdateEnable#server_id}
    */
    readonly serverId: string;
    /**
    * The update policy ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable#update_policy_id ServerUpdateEnable#update_policy_id}
    */
    readonly updatePolicyId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable stackit_server_update_enable}
*/
export declare class ServerUpdateEnable extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_update_enable";
    /**
    * Generates CDKTF code for importing a ServerUpdateEnable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerUpdateEnable to import
    * @param importFromId The id of the existing ServerUpdateEnable that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerUpdateEnable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/server_update_enable stackit_server_update_enable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerUpdateEnableConfig
    */
    constructor(scope: Construct, id: string, config: ServerUpdateEnableConfig);
    get enabled(): cdktf.IResolvable;
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _updatePolicyId?;
    get updatePolicyId(): string;
    set updatePolicyId(value: string);
    resetUpdatePolicyId(): void;
    get updatePolicyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
