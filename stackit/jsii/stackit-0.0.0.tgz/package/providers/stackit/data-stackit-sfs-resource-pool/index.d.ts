import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsResourcePoolConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the resource pool is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool#project_id DataStackitSfsResourcePool#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. Read-only attribute that reflects the provider region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool#region DataStackitSfsResourcePool#region}
    */
    readonly region?: string;
    /**
    * Resourcepool ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool#resource_pool_id DataStackitSfsResourcePool#resource_pool_id}
    */
    readonly resourcePoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool stackit_sfs_resource_pool}
*/
export declare class DataStackitSfsResourcePool extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_resource_pool";
    /**
    * Generates CDKTF code for importing a DataStackitSfsResourcePool resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsResourcePool to import
    * @param importFromId The id of the existing DataStackitSfsResourcePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsResourcePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/sfs_resource_pool stackit_sfs_resource_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsResourcePoolConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsResourcePoolConfig);
    get availabilityZone(): string;
    get id(): string;
    get ipAcl(): string[];
    get name(): string;
    get performanceClass(): string;
    get performanceClassDowngradableAt(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcePoolId?;
    get resourcePoolId(): string;
    set resourcePoolId(value: string);
    get resourcePoolIdInput(): string | undefined;
    get sizeGigabytes(): number;
    get sizeReducibleAt(): string;
    get snapshotsAreVisible(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
