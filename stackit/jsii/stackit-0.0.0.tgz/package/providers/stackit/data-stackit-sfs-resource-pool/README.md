# `data_stackit_sfs_resource_pool`

Refer to the Terraform Registry for docs: [`data_stackit_sfs_resource_pool`](https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_resource_pool).
