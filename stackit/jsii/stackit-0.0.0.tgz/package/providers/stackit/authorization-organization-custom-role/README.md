# `stackit_authorization_organization_custom_role`

Refer to the Terraform Registry for docs: [`stackit_authorization_organization_custom_role`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/authorization_organization_custom_role).
