import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthorizationOrganizationCustomRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * A human readable description of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role#description AuthorizationOrganizationCustomRole#description}
    */
    readonly description: string;
    /**
    * Name of the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role#name AuthorizationOrganizationCustomRole#name}
    */
    readonly name: string;
    /**
    * Permissions for the role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role#permissions AuthorizationOrganizationCustomRole#permissions}
    */
    readonly permissions: string[];
    /**
    * Resource to add the custom role to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role#resource_id AuthorizationOrganizationCustomRole#resource_id}
    */
    readonly resourceId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role stackit_authorization_organization_custom_role}
*/
export declare class AuthorizationOrganizationCustomRole extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_authorization_organization_custom_role";
    /**
    * Generates CDKTF code for importing a AuthorizationOrganizationCustomRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthorizationOrganizationCustomRole to import
    * @param importFromId The id of the existing AuthorizationOrganizationCustomRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthorizationOrganizationCustomRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/authorization_organization_custom_role stackit_authorization_organization_custom_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthorizationOrganizationCustomRoleConfig
    */
    constructor(scope: Construct, id: string, config: AuthorizationOrganizationCustomRoleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    get permissionsInput(): string[] | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    get roleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
