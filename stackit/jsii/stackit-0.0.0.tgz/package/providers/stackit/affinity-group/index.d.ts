import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AffinityGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the affinity group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group#name AffinityGroup#name}
    */
    readonly name: string;
    /**
    * The policy of the affinity group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group#policy AffinityGroup#policy}
    */
    readonly policy: string;
    /**
    * STACKIT Project ID to which the affinity group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group#project_id AffinityGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group#region AffinityGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group stackit_affinity_group}
*/
export declare class AffinityGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_affinity_group";
    /**
    * Generates CDKTF code for importing a AffinityGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AffinityGroup to import
    * @param importFromId The id of the existing AffinityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AffinityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/affinity_group stackit_affinity_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AffinityGroupConfig
    */
    constructor(scope: Construct, id: string, config: AffinityGroupConfig);
    get affinityGroupId(): string;
    get id(): string;
    get members(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    get policyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
