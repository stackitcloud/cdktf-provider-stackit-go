# `stackit_affinity_group`

Refer to the Terraform Registry for docs: [`stackit_affinity_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/resources/affinity_group).
