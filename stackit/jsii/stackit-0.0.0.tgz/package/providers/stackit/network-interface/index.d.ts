import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkInterfaceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The list of CIDR (Classless Inter-Domain Routing) notations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#allowed_addresses NetworkInterface#allowed_addresses}
    */
    readonly allowedAddresses?: string[];
    /**
    * The IPv4 address.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#ipv4 NetworkInterface#ipv4}
    */
    readonly ipv4?: string;
    /**
    * Labels are key-value string pairs which can be attached to a network interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#labels NetworkInterface#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the network interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#name NetworkInterface#name}
    */
    readonly name?: string;
    /**
    * The network ID to which the network interface is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#network_id NetworkInterface#network_id}
    */
    readonly networkId: string;
    /**
    * STACKIT project ID to which the network is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#project_id NetworkInterface#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#region NetworkInterface#region}
    */
    readonly region?: string;
    /**
    * The Network Interface Security. If set to false, then no security groups will apply to this network interface.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#security NetworkInterface#security}
    */
    readonly security?: boolean | cdktf.IResolvable;
    /**
    * The list of security group UUIDs. If security is set to false, setting this field will lead to an error.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#security_group_ids NetworkInterface#security_group_ids}
    */
    readonly securityGroupIds?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface stackit_network_interface}
*/
export declare class NetworkInterface extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_network_interface";
    /**
    * Generates CDKTF code for importing a NetworkInterface resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkInterface to import
    * @param importFromId The id of the existing NetworkInterface that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkInterface to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_interface stackit_network_interface} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkInterfaceConfig
    */
    constructor(scope: Construct, id: string, config: NetworkInterfaceConfig);
    private _allowedAddresses?;
    get allowedAddresses(): string[];
    set allowedAddresses(value: string[]);
    resetAllowedAddresses(): void;
    get allowedAddressesInput(): string[] | undefined;
    get device(): string;
    get id(): string;
    private _ipv4?;
    get ipv4(): string;
    set ipv4(value: string);
    resetIpv4(): void;
    get ipv4Input(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get mac(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    get networkInterfaceId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _security?;
    get security(): boolean | cdktf.IResolvable;
    set security(value: boolean | cdktf.IResolvable);
    resetSecurity(): void;
    get securityInput(): boolean | cdktf.IResolvable | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
