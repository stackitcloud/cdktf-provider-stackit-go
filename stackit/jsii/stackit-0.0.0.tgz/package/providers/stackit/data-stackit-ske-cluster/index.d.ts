import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSkeClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * The cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster#name DataStackitSkeCluster#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the cluster is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster#project_id DataStackitSkeCluster#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster#region DataStackitSkeCluster#region}
    */
    readonly region?: string;
}
export interface DataStackitSkeClusterExtensionsAcl {
}
export declare function dataStackitSkeClusterExtensionsAclToTerraform(struct?: DataStackitSkeClusterExtensionsAcl): any;
export declare function dataStackitSkeClusterExtensionsAclToHclTerraform(struct?: DataStackitSkeClusterExtensionsAcl): any;
export declare class DataStackitSkeClusterExtensionsAclOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterExtensionsAcl | undefined;
    set internalValue(value: DataStackitSkeClusterExtensionsAcl | undefined);
    get allowedCidrs(): string[];
    get enabled(): cdktf.IResolvable;
}
export interface DataStackitSkeClusterExtensionsArgus {
}
export declare function dataStackitSkeClusterExtensionsArgusToTerraform(struct?: DataStackitSkeClusterExtensionsArgus): any;
export declare function dataStackitSkeClusterExtensionsArgusToHclTerraform(struct?: DataStackitSkeClusterExtensionsArgus): any;
export declare class DataStackitSkeClusterExtensionsArgusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterExtensionsArgus | undefined;
    set internalValue(value: DataStackitSkeClusterExtensionsArgus | undefined);
    get argusInstanceId(): string;
    get enabled(): cdktf.IResolvable;
}
export interface DataStackitSkeClusterExtensionsDns {
}
export declare function dataStackitSkeClusterExtensionsDnsToTerraform(struct?: DataStackitSkeClusterExtensionsDns): any;
export declare function dataStackitSkeClusterExtensionsDnsToHclTerraform(struct?: DataStackitSkeClusterExtensionsDns): any;
export declare class DataStackitSkeClusterExtensionsDnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterExtensionsDns | undefined;
    set internalValue(value: DataStackitSkeClusterExtensionsDns | undefined);
    get enabled(): cdktf.IResolvable;
    get zones(): string[];
}
export interface DataStackitSkeClusterExtensionsObservability {
}
export declare function dataStackitSkeClusterExtensionsObservabilityToTerraform(struct?: DataStackitSkeClusterExtensionsObservability): any;
export declare function dataStackitSkeClusterExtensionsObservabilityToHclTerraform(struct?: DataStackitSkeClusterExtensionsObservability): any;
export declare class DataStackitSkeClusterExtensionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterExtensionsObservability | undefined;
    set internalValue(value: DataStackitSkeClusterExtensionsObservability | undefined);
    get enabled(): cdktf.IResolvable;
    get instanceId(): string;
}
export interface DataStackitSkeClusterExtensions {
}
export declare function dataStackitSkeClusterExtensionsToTerraform(struct?: DataStackitSkeClusterExtensions): any;
export declare function dataStackitSkeClusterExtensionsToHclTerraform(struct?: DataStackitSkeClusterExtensions): any;
export declare class DataStackitSkeClusterExtensionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterExtensions | undefined;
    set internalValue(value: DataStackitSkeClusterExtensions | undefined);
    private _acl;
    get acl(): DataStackitSkeClusterExtensionsAclOutputReference;
    private _argus;
    get argus(): DataStackitSkeClusterExtensionsArgusOutputReference;
    private _dns;
    get dns(): DataStackitSkeClusterExtensionsDnsOutputReference;
    private _observability;
    get observability(): DataStackitSkeClusterExtensionsObservabilityOutputReference;
}
export interface DataStackitSkeClusterHibernations {
}
export declare function dataStackitSkeClusterHibernationsToTerraform(struct?: DataStackitSkeClusterHibernations): any;
export declare function dataStackitSkeClusterHibernationsToHclTerraform(struct?: DataStackitSkeClusterHibernations): any;
export declare class DataStackitSkeClusterHibernationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeClusterHibernations | undefined;
    set internalValue(value: DataStackitSkeClusterHibernations | undefined);
    get end(): string;
    get start(): string;
    get timezone(): string;
}
export declare class DataStackitSkeClusterHibernationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeClusterHibernationsOutputReference;
}
export interface DataStackitSkeClusterMaintenance {
}
export declare function dataStackitSkeClusterMaintenanceToTerraform(struct?: DataStackitSkeClusterMaintenance): any;
export declare function dataStackitSkeClusterMaintenanceToHclTerraform(struct?: DataStackitSkeClusterMaintenance): any;
export declare class DataStackitSkeClusterMaintenanceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterMaintenance | undefined;
    set internalValue(value: DataStackitSkeClusterMaintenance | undefined);
    get enableKubernetesVersionUpdates(): cdktf.IResolvable;
    get enableMachineImageVersionUpdates(): cdktf.IResolvable;
    get end(): string;
    get start(): string;
}
export interface DataStackitSkeClusterNetworkControlPlane {
}
export declare function dataStackitSkeClusterNetworkControlPlaneToTerraform(struct?: DataStackitSkeClusterNetworkControlPlane): any;
export declare function dataStackitSkeClusterNetworkControlPlaneToHclTerraform(struct?: DataStackitSkeClusterNetworkControlPlane): any;
export declare class DataStackitSkeClusterNetworkControlPlaneOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterNetworkControlPlane | undefined;
    set internalValue(value: DataStackitSkeClusterNetworkControlPlane | undefined);
    get accessScope(): string;
}
export interface DataStackitSkeClusterNetwork {
}
export declare function dataStackitSkeClusterNetworkToTerraform(struct?: DataStackitSkeClusterNetwork): any;
export declare function dataStackitSkeClusterNetworkToHclTerraform(struct?: DataStackitSkeClusterNetwork): any;
export declare class DataStackitSkeClusterNetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSkeClusterNetwork | undefined;
    set internalValue(value: DataStackitSkeClusterNetwork | undefined);
    private _controlPlane;
    get controlPlane(): DataStackitSkeClusterNetworkControlPlaneOutputReference;
    get id(): string;
}
export interface DataStackitSkeClusterNodePoolsTaints {
}
export declare function dataStackitSkeClusterNodePoolsTaintsToTerraform(struct?: DataStackitSkeClusterNodePoolsTaints): any;
export declare function dataStackitSkeClusterNodePoolsTaintsToHclTerraform(struct?: DataStackitSkeClusterNodePoolsTaints): any;
export declare class DataStackitSkeClusterNodePoolsTaintsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeClusterNodePoolsTaints | undefined;
    set internalValue(value: DataStackitSkeClusterNodePoolsTaints | undefined);
    get effect(): string;
    get key(): string;
    get value(): string;
}
export declare class DataStackitSkeClusterNodePoolsTaintsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeClusterNodePoolsTaintsOutputReference;
}
export interface DataStackitSkeClusterNodePools {
}
export declare function dataStackitSkeClusterNodePoolsToTerraform(struct?: DataStackitSkeClusterNodePools): any;
export declare function dataStackitSkeClusterNodePoolsToHclTerraform(struct?: DataStackitSkeClusterNodePools): any;
export declare class DataStackitSkeClusterNodePoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeClusterNodePools | undefined;
    set internalValue(value: DataStackitSkeClusterNodePools | undefined);
    get allowSystemComponents(): cdktf.IResolvable;
    get availabilityZones(): string[];
    get cri(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get machineType(): string;
    get maxSurge(): number;
    get maxUnavailable(): number;
    get maximum(): number;
    get minimum(): number;
    get name(): string;
    get osName(): string;
    get osVersion(): string;
    get osVersionMin(): string;
    get osVersionUsed(): string;
    private _taints;
    get taints(): DataStackitSkeClusterNodePoolsTaintsList;
    get volumeSize(): number;
    get volumeType(): string;
}
export declare class DataStackitSkeClusterNodePoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeClusterNodePoolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster stackit_ske_cluster}
*/
export declare class DataStackitSkeCluster extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_ske_cluster";
    /**
    * Generates CDKTF code for importing a DataStackitSkeCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSkeCluster to import
    * @param importFromId The id of the existing DataStackitSkeCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSkeCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/ske_cluster stackit_ske_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSkeClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSkeClusterConfig);
    get egressAddressRanges(): string[];
    private _extensions;
    get extensions(): DataStackitSkeClusterExtensionsOutputReference;
    private _hibernations;
    get hibernations(): DataStackitSkeClusterHibernationsList;
    get id(): string;
    get kubernetesVersionMin(): string;
    get kubernetesVersionUsed(): string;
    private _maintenance;
    get maintenance(): DataStackitSkeClusterMaintenanceOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network;
    get network(): DataStackitSkeClusterNetworkOutputReference;
    private _nodePools;
    get nodePools(): DataStackitSkeClusterNodePoolsList;
    get podAddressRanges(): string[];
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
