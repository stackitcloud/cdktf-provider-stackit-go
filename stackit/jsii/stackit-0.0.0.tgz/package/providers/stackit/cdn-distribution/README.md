# `stackit_cdn_distribution`

Refer to the Terraform Registry for docs: [`stackit_cdn_distribution`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/cdn_distribution).
