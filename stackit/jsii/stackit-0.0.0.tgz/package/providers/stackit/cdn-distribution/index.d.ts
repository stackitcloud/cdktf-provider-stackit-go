import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CdnDistributionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The distribution configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#config CdnDistribution#config}
    */
    readonly config: CdnDistributionConfigA;
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#project_id CdnDistribution#project_id}
    */
    readonly projectId: string;
}
export interface CdnDistributionConfigBackendCredentials {
    /**
    * The access key for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#access_key_id CdnDistribution#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * The access key for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#secret_access_key CdnDistribution#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function cdnDistributionConfigBackendCredentialsToTerraform(struct?: CdnDistributionConfigBackendCredentials | cdktf.IResolvable): any;
export declare function cdnDistributionConfigBackendCredentialsToHclTerraform(struct?: CdnDistributionConfigBackendCredentials | cdktf.IResolvable): any;
export declare class CdnDistributionConfigBackendCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigBackendCredentials | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigBackendCredentials | cdktf.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface CdnDistributionConfigBackend {
    /**
    * The URL of the bucket (e.g. https://s3.example.com). Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#bucket_url CdnDistribution#bucket_url}
    */
    readonly bucketUrl?: string;
    /**
    * The credentials for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#credentials CdnDistribution#credentials}
    */
    readonly credentials?: CdnDistributionConfigBackendCredentials;
    /**
    * The configured type http to configure countries where content is allowed. A map of URLs to a list of countries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#geofencing CdnDistribution#geofencing}
    */
    readonly geofencing?: {
        [key: string]: string[];
    } | cdktf.IResolvable;
    /**
    * The configured type http origin request headers for the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#origin_request_headers CdnDistribution#origin_request_headers}
    */
    readonly originRequestHeaders?: {
        [key: string]: string;
    };
    /**
    * The configured backend type http for the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#origin_url CdnDistribution#origin_url}
    */
    readonly originUrl?: string;
    /**
    * The region where the bucket is hosted. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#region CdnDistribution#region}
    */
    readonly region?: string;
    /**
    * The configured backend type. Possible values are: `http`, `bucket`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#type CdnDistribution#type}
    */
    readonly type: string;
}
export declare function cdnDistributionConfigBackendToTerraform(struct?: CdnDistributionConfigBackend | cdktf.IResolvable): any;
export declare function cdnDistributionConfigBackendToHclTerraform(struct?: CdnDistributionConfigBackend | cdktf.IResolvable): any;
export declare class CdnDistributionConfigBackendOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigBackend | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigBackend | cdktf.IResolvable | undefined);
    private _bucketUrl?;
    get bucketUrl(): string;
    set bucketUrl(value: string);
    resetBucketUrl(): void;
    get bucketUrlInput(): string | undefined;
    private _credentials;
    get credentials(): CdnDistributionConfigBackendCredentialsOutputReference;
    putCredentials(value: CdnDistributionConfigBackendCredentials): void;
    resetCredentials(): void;
    get credentialsInput(): cdktf.IResolvable | CdnDistributionConfigBackendCredentials | undefined;
    private _geofencing?;
    get geofencing(): {
        [key: string]: string[];
    } | cdktf.IResolvable;
    set geofencing(value: {
        [key: string]: string[];
    } | cdktf.IResolvable);
    resetGeofencing(): void;
    get geofencingInput(): cdktf.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _originRequestHeaders?;
    get originRequestHeaders(): {
        [key: string]: string;
    };
    set originRequestHeaders(value: {
        [key: string]: string;
    });
    resetOriginRequestHeaders(): void;
    get originRequestHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _originUrl?;
    get originUrl(): string;
    set originUrl(value: string);
    resetOriginUrl(): void;
    get originUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface CdnDistributionConfigCacheConfig {
    /**
    * HTTP request header names whose values participate in the cache key. Each entry multiplies the number of cache variants by the number of distinct values observed for that header.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#cache_key_headers CdnDistribution#cache_key_headers}
    */
    readonly cacheKeyHeaders?: string[];
    /**
    * When true, the CDN varies its cache by the request query string. If query_string_vary_parameters is empty, every unique query-string combination produces its own cache entry; if non-empty, only the listed parameters influence the cache key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#query_string_vary_enabled CdnDistribution#query_string_vary_enabled}
    */
    readonly queryStringVaryEnabled?: boolean | cdktf.IResolvable;
    /**
    * Allowlist of query-string parameter names that participate in the cache key when query_string_vary_enabled is true. Ignored while query_string_vary_enabled is false, but still stored so it can be re-activated without losing the list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#query_string_vary_parameters CdnDistribution#query_string_vary_parameters}
    */
    readonly queryStringVaryParameters?: string[];
}
export declare function cdnDistributionConfigCacheConfigToTerraform(struct?: CdnDistributionConfigCacheConfig | cdktf.IResolvable): any;
export declare function cdnDistributionConfigCacheConfigToHclTerraform(struct?: CdnDistributionConfigCacheConfig | cdktf.IResolvable): any;
export declare class CdnDistributionConfigCacheConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigCacheConfig | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigCacheConfig | cdktf.IResolvable | undefined);
    private _cacheKeyHeaders?;
    get cacheKeyHeaders(): string[];
    set cacheKeyHeaders(value: string[]);
    resetCacheKeyHeaders(): void;
    get cacheKeyHeadersInput(): string[] | undefined;
    private _queryStringVaryEnabled?;
    get queryStringVaryEnabled(): boolean | cdktf.IResolvable;
    set queryStringVaryEnabled(value: boolean | cdktf.IResolvable);
    resetQueryStringVaryEnabled(): void;
    get queryStringVaryEnabledInput(): boolean | cdktf.IResolvable | undefined;
    private _queryStringVaryParameters?;
    get queryStringVaryParameters(): string[];
    set queryStringVaryParameters(value: string[]);
    resetQueryStringVaryParameters(): void;
    get queryStringVaryParametersInput(): string[] | undefined;
}
export interface CdnDistributionConfigOptimizer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enabled CdnDistribution#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
}
export declare function cdnDistributionConfigOptimizerToTerraform(struct?: CdnDistributionConfigOptimizer | cdktf.IResolvable): any;
export declare function cdnDistributionConfigOptimizerToHclTerraform(struct?: CdnDistributionConfigOptimizer | cdktf.IResolvable): any;
export declare class CdnDistributionConfigOptimizerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigOptimizer | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigOptimizer | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface CdnDistributionConfigRedirectsRulesMatchers {
    /**
    * Defines how multiple matchers within this rule are combined (ALL, ANY, NONE). Defaults to ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#value_match_condition CdnDistribution#value_match_condition}
    */
    readonly valueMatchCondition?: string;
    /**
    * A list of glob patterns to match against the request path. At least one value is required. Examples: "/shop/*" or "* /img/*"
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#values CdnDistribution#values}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly values: string[];
}
export declare function cdnDistributionConfigRedirectsRulesMatchersToTerraform(struct?: CdnDistributionConfigRedirectsRulesMatchers | cdktf.IResolvable): any;
export declare function cdnDistributionConfigRedirectsRulesMatchersToHclTerraform(struct?: CdnDistributionConfigRedirectsRulesMatchers | cdktf.IResolvable): any;
export declare class CdnDistributionConfigRedirectsRulesMatchersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnDistributionConfigRedirectsRulesMatchers | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigRedirectsRulesMatchers | cdktf.IResolvable | undefined);
    private _valueMatchCondition?;
    get valueMatchCondition(): string;
    set valueMatchCondition(value: string);
    resetValueMatchCondition(): void;
    get valueMatchConditionInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnDistributionConfigRedirectsRulesMatchersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CdnDistributionConfigRedirectsRulesMatchers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnDistributionConfigRedirectsRulesMatchersOutputReference;
}
export interface CdnDistributionConfigRedirectsRules {
    /**
    * An optional description for the redirect rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#description CdnDistribution#description}
    */
    readonly description?: string;
    /**
    * A toggle to enable or disable the redirect rule. Default to true
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enabled CdnDistribution#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * A list of matchers that define when this rule should apply. At least one matcher is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#matchers CdnDistribution#matchers}
    */
    readonly matchers: CdnDistributionConfigRedirectsRulesMatchers[] | cdktf.IResolvable;
    /**
    * Defines how multiple matchers within this rule are combined (ALL, ANY, NONE). Defaults to ANY.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#rule_match_condition CdnDistribution#rule_match_condition}
    */
    readonly ruleMatchCondition?: string;
    /**
    * The HTTP status code for the redirect. Must be one of 301, 302, 303, 307, or 308.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#status_code CdnDistribution#status_code}
    */
    readonly statusCode: number;
    /**
    * The target URL to redirect to. Must be a valid URI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#target_url CdnDistribution#target_url}
    */
    readonly targetUrl: string;
}
export declare function cdnDistributionConfigRedirectsRulesToTerraform(struct?: CdnDistributionConfigRedirectsRules | cdktf.IResolvable): any;
export declare function cdnDistributionConfigRedirectsRulesToHclTerraform(struct?: CdnDistributionConfigRedirectsRules | cdktf.IResolvable): any;
export declare class CdnDistributionConfigRedirectsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnDistributionConfigRedirectsRules | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigRedirectsRules | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _matchers;
    get matchers(): CdnDistributionConfigRedirectsRulesMatchersList;
    putMatchers(value: CdnDistributionConfigRedirectsRulesMatchers[] | cdktf.IResolvable): void;
    get matchersInput(): cdktf.IResolvable | CdnDistributionConfigRedirectsRulesMatchers[] | undefined;
    private _ruleMatchCondition?;
    get ruleMatchCondition(): string;
    set ruleMatchCondition(value: string);
    resetRuleMatchCondition(): void;
    get ruleMatchConditionInput(): string | undefined;
    private _statusCode?;
    get statusCode(): number;
    set statusCode(value: number);
    get statusCodeInput(): number | undefined;
    private _targetUrl?;
    get targetUrl(): string;
    set targetUrl(value: string);
    get targetUrlInput(): string | undefined;
}
export declare class CdnDistributionConfigRedirectsRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: CdnDistributionConfigRedirectsRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnDistributionConfigRedirectsRulesOutputReference;
}
export interface CdnDistributionConfigRedirects {
    /**
    * A list of redirect rules. The order of rules matters for evaluation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#rules CdnDistribution#rules}
    */
    readonly rules: CdnDistributionConfigRedirectsRules[] | cdktf.IResolvable;
}
export declare function cdnDistributionConfigRedirectsToTerraform(struct?: CdnDistributionConfigRedirects | cdktf.IResolvable): any;
export declare function cdnDistributionConfigRedirectsToHclTerraform(struct?: CdnDistributionConfigRedirects | cdktf.IResolvable): any;
export declare class CdnDistributionConfigRedirectsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigRedirects | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigRedirects | cdktf.IResolvable | undefined);
    private _rules;
    get rules(): CdnDistributionConfigRedirectsRulesList;
    putRules(value: CdnDistributionConfigRedirectsRules[] | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | CdnDistributionConfigRedirectsRules[] | undefined;
}
export interface CdnDistributionConfigTls {
    /**
    * If set to true, the distribution will accept connections using TLS 1.1.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enable_tls_10 CdnDistribution#enable_tls_10}
    */
    readonly enableTls10?: boolean | cdktf.IResolvable;
    /**
    * If set to true, the distribution will accept connections using TLS 1.0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enable_tls_11 CdnDistribution#enable_tls_11}
    */
    readonly enableTls11?: boolean | cdktf.IResolvable;
}
export declare function cdnDistributionConfigTlsToTerraform(struct?: CdnDistributionConfigTls | cdktf.IResolvable): any;
export declare function cdnDistributionConfigTlsToHclTerraform(struct?: CdnDistributionConfigTls | cdktf.IResolvable): any;
export declare class CdnDistributionConfigTlsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigTls | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigTls | cdktf.IResolvable | undefined);
    private _enableTls10?;
    get enableTls10(): boolean | cdktf.IResolvable;
    set enableTls10(value: boolean | cdktf.IResolvable);
    resetEnableTls10(): void;
    get enableTls10Input(): boolean | cdktf.IResolvable | undefined;
    private _enableTls11?;
    get enableTls11(): boolean | cdktf.IResolvable;
    set enableTls11(value: boolean | cdktf.IResolvable);
    resetEnableTls11(): void;
    get enableTls11Input(): boolean | cdktf.IResolvable | undefined;
}
export interface CdnDistributionConfigWaf {
    /**
    * Restricts which HTTP methods the distribution accepts. If provided, the set must contain at least one item. Case you removed waf will retain the last known state and if omitted, the API applies the following defaults: `GET`, `HEAD`, `POST`, `PUT`, `DELETE`, `CONNECT`, `OPTIONS`, `TRACE`, `PATCH`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#allowed_http_methods CdnDistribution#allowed_http_methods}
    */
    readonly allowedHttpMethods?: string[];
    /**
    * Restricts which HTTP protocol versions are accepted. If provided, the set must contain at least one item. If omitted, the API applies the following defaults: `HTTP/1.0`, `HTTP/1.1`, `HTTP/2`, `HTTP/2.0`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#allowed_http_versions CdnDistribution#allowed_http_versions}
    */
    readonly allowedHttpVersions?: string[];
    /**
    * Restricts which Content-Type headers are accepted in request bodies. If provided, the set must contain at least one item. Case you removed waf will retain the last known state and if omitted, the API applies the following defaults: `application/x-www-form-urlencoded`, `multipart/form-data`, `multipart/related`, `text/xml`, `application/xml`, `application/soap+xml`, `application/x-amf`, `application/json`, `application/octet-stream`, `application/csp-report`, `application/xss-auditor-report`, `text/plain`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#allowed_request_content_types CdnDistribution#allowed_request_content_types}
    */
    readonly allowedRequestContentTypes?: string[];
    /**
    * Set of WAF Collection IDs explicitly disabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. To view available rule collections, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#disabled_rule_collection_ids CdnDistribution#disabled_rule_collection_ids}
    */
    readonly disabledRuleCollectionIds?: string[];
    /**
    * Set of WAF Rule Group IDs explicitly disabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Groups override Collections. To view available rule groups, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#disabled_rule_group_ids CdnDistribution#disabled_rule_group_ids}
    */
    readonly disabledRuleGroupIds?: string[];
    /**
    * Set of WAF rule IDs explicitly disabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Specific Rules override Groups. For example, an explicitly disabled Rule ID takes precedence over an enabled Group ID. To view available rules, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#disabled_rule_ids CdnDistribution#disabled_rule_ids}
    */
    readonly disabledRuleIds?: string[];
    /**
    * Set of WAF Collection IDs explicitly enabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. To view available rule collections, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enabled_rule_collection_ids CdnDistribution#enabled_rule_collection_ids}
    */
    readonly enabledRuleCollectionIds?: string[];
    /**
    * Set of WAF Rule Group IDs explicitly enabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Groups override Collections. To view available rule groups, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enabled_rule_group_ids CdnDistribution#enabled_rule_group_ids}
    */
    readonly enabledRuleGroupIds?: string[];
    /**
    * Set of WAF rule IDs explicitly enabled. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Specific Rules override Groups. For example, an explicitly enabled Rule ID takes precedence over a disabled Group ID. To view available rules, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#enabled_rule_ids CdnDistribution#enabled_rule_ids}
    */
    readonly enabledRuleIds?: string[];
    /**
    * Set of WAF Collection IDs explicitly marked as Log Only. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. To view available rule collections, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#log_only_rule_collection_ids CdnDistribution#log_only_rule_collection_ids}
    */
    readonly logOnlyRuleCollectionIds?: string[];
    /**
    * Set of WAF Rule Group IDs explicitly marked as Log Only. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Groups override Collections. To view available rule groups, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#log_only_rule_group_ids CdnDistribution#log_only_rule_group_ids}
    */
    readonly logOnlyRuleGroupIds?: string[];
    /**
    * Set of WAF rule IDs explicitly marked as Log Only. Can be set to an empty set to clear previously set rules. Case you removed waf will retain the last known state. Precedence hierarchy: Specific Rules override Groups. To view available rules, please consult the API documentation: https://docs.api.eu01.stackit.cloud/documentation/cdn/version/v1#tag/WAF/operation/ListWafCollections
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#log_only_rule_ids CdnDistribution#log_only_rule_ids}
    */
    readonly logOnlyRuleIds?: string[];
    /**
    * The operating mode of the WAF. 'ENABLED' actively blocks threats, 'LOG_ONLY' logs matches without blocking, and 'DISABLED' completely turns off inspection. Defaults to 'DISABLED'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#mode CdnDistribution#mode}
    */
    readonly mode?: string;
    /**
    * Defines how aggressively the WAF should act on requests. Valid values are 'L1' to 'L4'. Case you removed waf will retain the last known state and if omitted, The API applies the following default 'L1'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#paranoia_level CdnDistribution#paranoia_level}
    */
    readonly paranoiaLevel?: string;
    /**
    * The tier of the WAF. Valid values are 'FREE' or 'PREMIUM'. Defaults to 'FREE'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#type CdnDistribution#type}
    */
    readonly type?: string;
}
export declare function cdnDistributionConfigWafToTerraform(struct?: CdnDistributionConfigWaf | cdktf.IResolvable): any;
export declare function cdnDistributionConfigWafToHclTerraform(struct?: CdnDistributionConfigWaf | cdktf.IResolvable): any;
export declare class CdnDistributionConfigWafOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigWaf | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigWaf | cdktf.IResolvable | undefined);
    private _allowedHttpMethods?;
    get allowedHttpMethods(): string[];
    set allowedHttpMethods(value: string[]);
    resetAllowedHttpMethods(): void;
    get allowedHttpMethodsInput(): string[] | undefined;
    private _allowedHttpVersions?;
    get allowedHttpVersions(): string[];
    set allowedHttpVersions(value: string[]);
    resetAllowedHttpVersions(): void;
    get allowedHttpVersionsInput(): string[] | undefined;
    private _allowedRequestContentTypes?;
    get allowedRequestContentTypes(): string[];
    set allowedRequestContentTypes(value: string[]);
    resetAllowedRequestContentTypes(): void;
    get allowedRequestContentTypesInput(): string[] | undefined;
    private _disabledRuleCollectionIds?;
    get disabledRuleCollectionIds(): string[];
    set disabledRuleCollectionIds(value: string[]);
    resetDisabledRuleCollectionIds(): void;
    get disabledRuleCollectionIdsInput(): string[] | undefined;
    private _disabledRuleGroupIds?;
    get disabledRuleGroupIds(): string[];
    set disabledRuleGroupIds(value: string[]);
    resetDisabledRuleGroupIds(): void;
    get disabledRuleGroupIdsInput(): string[] | undefined;
    private _disabledRuleIds?;
    get disabledRuleIds(): string[];
    set disabledRuleIds(value: string[]);
    resetDisabledRuleIds(): void;
    get disabledRuleIdsInput(): string[] | undefined;
    private _enabledRuleCollectionIds?;
    get enabledRuleCollectionIds(): string[];
    set enabledRuleCollectionIds(value: string[]);
    resetEnabledRuleCollectionIds(): void;
    get enabledRuleCollectionIdsInput(): string[] | undefined;
    private _enabledRuleGroupIds?;
    get enabledRuleGroupIds(): string[];
    set enabledRuleGroupIds(value: string[]);
    resetEnabledRuleGroupIds(): void;
    get enabledRuleGroupIdsInput(): string[] | undefined;
    private _enabledRuleIds?;
    get enabledRuleIds(): string[];
    set enabledRuleIds(value: string[]);
    resetEnabledRuleIds(): void;
    get enabledRuleIdsInput(): string[] | undefined;
    private _logOnlyRuleCollectionIds?;
    get logOnlyRuleCollectionIds(): string[];
    set logOnlyRuleCollectionIds(value: string[]);
    resetLogOnlyRuleCollectionIds(): void;
    get logOnlyRuleCollectionIdsInput(): string[] | undefined;
    private _logOnlyRuleGroupIds?;
    get logOnlyRuleGroupIds(): string[];
    set logOnlyRuleGroupIds(value: string[]);
    resetLogOnlyRuleGroupIds(): void;
    get logOnlyRuleGroupIdsInput(): string[] | undefined;
    private _logOnlyRuleIds?;
    get logOnlyRuleIds(): string[];
    set logOnlyRuleIds(value: string[]);
    resetLogOnlyRuleIds(): void;
    get logOnlyRuleIdsInput(): string[] | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _paranoiaLevel?;
    get paranoiaLevel(): string;
    set paranoiaLevel(value: string);
    resetParanoiaLevel(): void;
    get paranoiaLevelInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export interface CdnDistributionConfigA {
    /**
    * The configured backend for the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#backend CdnDistribution#backend}
    */
    readonly backend: CdnDistributionConfigBackend;
    /**
    * The configured countries where distribution of content is blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#blocked_countries CdnDistribution#blocked_countries}
    */
    readonly blockedCountries?: string[];
    /**
    * Restricts access to your content by specifying a list of blocked IPv4 addresses. This feature enhances security and privacy by preventing these addresses from accessing your distribution. Note: once a value is set, removing the attribute from your configuration will retain the last known value in state; to clear it explicitly, set it to an empty list.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#blocked_ips CdnDistribution#blocked_ips}
    */
    readonly blockedIps?: string[];
    /**
    * Groups the cache options that influence how the CDN builds its cache key. Warning: enabling query-string vary produces one cache entry per unique query-string combination (unbounded when query_string_vary_parameters is empty). Each entry in cache_key_headers multiplies the number of cache variants by the number of distinct values observed for that header. Use these settings sparingly.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#cache_config CdnDistribution#cache_config}
    */
    readonly cacheConfig?: CdnDistributionConfigCacheConfig;
    /**
    * Sets the default cache duration for the distribution. The default cache duration is applied when a 'Cache-Control' header is not presented in the origin's response. We use ISO8601 duration format for cache duration (e.g. P1DT2H30M). Note: once a value is set, removing the attribute from your configuration will retain the last known value in state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#default_cache_duration CdnDistribution#default_cache_duration}
    */
    readonly defaultCacheDuration?: string;
    /**
    * Enable this allows the 'Host' header to be passed through to the origin.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#forward_host_header CdnDistribution#forward_host_header}
    */
    readonly forwardHostHeader?: boolean | cdktf.IResolvable;
    /**
    * Sets the monthly limit of bandwidth in bytes that the pullzone is allowed to use. Note: once a value is set, removing the attribute from your configuration will retain the last known value in state.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#monthly_limit_bytes CdnDistribution#monthly_limit_bytes}
    */
    readonly monthlyLimitBytes?: number;
    /**
    * Configuration for the Image Optimizer. This is a paid feature that automatically optimizes images to reduce their file size for faster delivery, leading to improved website performance and a better user experience.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#optimizer CdnDistribution#optimizer}
    */
    readonly optimizer?: CdnDistributionConfigOptimizer;
    /**
    * A wrapper for a list of redirect rules that allows for redirect settings on a distribution. Currently, this feature is only available for distributions of backend type HTTP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#redirects CdnDistribution#redirects}
    */
    readonly redirects?: CdnDistributionConfigRedirects;
    /**
    * The configured regions where content will be hosted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#regions CdnDistribution#regions}
    */
    readonly regions: string[];
    /**
    * Enable this to prevent origin-level cookies from being forwarded to the end user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#strip_response_cookies CdnDistribution#strip_response_cookies}
    */
    readonly stripResponseCookies?: boolean | cdktf.IResolvable;
    /**
    * Configuration for TLS protocol versions. Note: Enabling older TLS versions (1.0, 1.1) is generally discouraged for security reasons.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#tls CdnDistribution#tls}
    */
    readonly tls?: CdnDistributionConfigTls;
    /**
    * Configures the Web Application Firewall (WAF) for the distribution. If this block is undefined or removed from your configuration, the WAF mode will default to DISABLED and the type to FREE. All other WAF properties will retain their last known state in the API; if they were never defined, the API will apply its default settings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#waf CdnDistribution#waf}
    */
    readonly waf?: CdnDistributionConfigWaf;
}
export declare function cdnDistributionConfigAToTerraform(struct?: CdnDistributionConfigA | cdktf.IResolvable): any;
export declare function cdnDistributionConfigAToHclTerraform(struct?: CdnDistributionConfigA | cdktf.IResolvable): any;
export declare class CdnDistributionConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigA | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigA | cdktf.IResolvable | undefined);
    private _backend;
    get backend(): CdnDistributionConfigBackendOutputReference;
    putBackend(value: CdnDistributionConfigBackend): void;
    get backendInput(): cdktf.IResolvable | CdnDistributionConfigBackend | undefined;
    private _blockedCountries?;
    get blockedCountries(): string[];
    set blockedCountries(value: string[]);
    resetBlockedCountries(): void;
    get blockedCountriesInput(): string[] | undefined;
    private _blockedIps?;
    get blockedIps(): string[];
    set blockedIps(value: string[]);
    resetBlockedIps(): void;
    get blockedIpsInput(): string[] | undefined;
    private _cacheConfig;
    get cacheConfig(): CdnDistributionConfigCacheConfigOutputReference;
    putCacheConfig(value: CdnDistributionConfigCacheConfig): void;
    resetCacheConfig(): void;
    get cacheConfigInput(): cdktf.IResolvable | CdnDistributionConfigCacheConfig | undefined;
    private _defaultCacheDuration?;
    get defaultCacheDuration(): string;
    set defaultCacheDuration(value: string);
    resetDefaultCacheDuration(): void;
    get defaultCacheDurationInput(): string | undefined;
    private _forwardHostHeader?;
    get forwardHostHeader(): boolean | cdktf.IResolvable;
    set forwardHostHeader(value: boolean | cdktf.IResolvable);
    resetForwardHostHeader(): void;
    get forwardHostHeaderInput(): boolean | cdktf.IResolvable | undefined;
    private _monthlyLimitBytes?;
    get monthlyLimitBytes(): number;
    set monthlyLimitBytes(value: number);
    resetMonthlyLimitBytes(): void;
    get monthlyLimitBytesInput(): number | undefined;
    private _optimizer;
    get optimizer(): CdnDistributionConfigOptimizerOutputReference;
    putOptimizer(value: CdnDistributionConfigOptimizer): void;
    resetOptimizer(): void;
    get optimizerInput(): cdktf.IResolvable | CdnDistributionConfigOptimizer | undefined;
    private _redirects;
    get redirects(): CdnDistributionConfigRedirectsOutputReference;
    putRedirects(value: CdnDistributionConfigRedirects): void;
    resetRedirects(): void;
    get redirectsInput(): cdktf.IResolvable | CdnDistributionConfigRedirects | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
    private _stripResponseCookies?;
    get stripResponseCookies(): boolean | cdktf.IResolvable;
    set stripResponseCookies(value: boolean | cdktf.IResolvable);
    resetStripResponseCookies(): void;
    get stripResponseCookiesInput(): boolean | cdktf.IResolvable | undefined;
    private _tls;
    get tls(): CdnDistributionConfigTlsOutputReference;
    putTls(value: CdnDistributionConfigTls): void;
    resetTls(): void;
    get tlsInput(): cdktf.IResolvable | CdnDistributionConfigTls | undefined;
    private _waf;
    get waf(): CdnDistributionConfigWafOutputReference;
    putWaf(value: CdnDistributionConfigWaf): void;
    resetWaf(): void;
    get wafInput(): cdktf.IResolvable | CdnDistributionConfigWaf | undefined;
}
export interface CdnDistributionDomains {
}
export declare function cdnDistributionDomainsToTerraform(struct?: CdnDistributionDomains): any;
export declare function cdnDistributionDomainsToHclTerraform(struct?: CdnDistributionDomains): any;
export declare class CdnDistributionDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnDistributionDomains | undefined;
    set internalValue(value: CdnDistributionDomains | undefined);
    get errors(): string[];
    get name(): string;
    get status(): string;
    get type(): string;
}
export declare class CdnDistributionDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnDistributionDomainsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution stackit_cdn_distribution}
*/
export declare class CdnDistribution extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_cdn_distribution";
    /**
    * Generates CDKTF code for importing a CdnDistribution resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnDistribution to import
    * @param importFromId The id of the existing CdnDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/cdn_distribution stackit_cdn_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnDistributionConfig
    */
    constructor(scope: Construct, id: string, config: CdnDistributionConfig);
    private _config;
    get config(): CdnDistributionConfigAOutputReference;
    putConfig(value: CdnDistributionConfigA): void;
    get configInput(): cdktf.IResolvable | CdnDistributionConfigA | undefined;
    get createdAt(): string;
    get distributionId(): string;
    private _domains;
    get domains(): CdnDistributionDomainsList;
    get errors(): string[];
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
