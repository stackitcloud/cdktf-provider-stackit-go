import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CdnDistributionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The distribution configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#config CdnDistribution#config}
    */
    readonly config: CdnDistributionConfigA;
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#project_id CdnDistribution#project_id}
    */
    readonly projectId: string;
}
export interface CdnDistributionConfigBackendCredentials {
    /**
    * The access key for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#access_key_id CdnDistribution#access_key_id}
    */
    readonly accessKeyId: string;
    /**
    * The access key for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#secret_access_key CdnDistribution#secret_access_key}
    */
    readonly secretAccessKey: string;
}
export declare function cdnDistributionConfigBackendCredentialsToTerraform(struct?: CdnDistributionConfigBackendCredentials | cdktf.IResolvable): any;
export declare function cdnDistributionConfigBackendCredentialsToHclTerraform(struct?: CdnDistributionConfigBackendCredentials | cdktf.IResolvable): any;
export declare class CdnDistributionConfigBackendCredentialsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigBackendCredentials | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigBackendCredentials | cdktf.IResolvable | undefined);
    private _accessKeyId?;
    get accessKeyId(): string;
    set accessKeyId(value: string);
    get accessKeyIdInput(): string | undefined;
    private _secretAccessKey?;
    get secretAccessKey(): string;
    set secretAccessKey(value: string);
    get secretAccessKeyInput(): string | undefined;
}
export interface CdnDistributionConfigBackend {
    /**
    * The URL of the bucket (e.g. https://s3.example.com). Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#bucket_url CdnDistribution#bucket_url}
    */
    readonly bucketUrl?: string;
    /**
    * The credentials for the bucket. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#credentials CdnDistribution#credentials}
    */
    readonly credentials?: CdnDistributionConfigBackendCredentials;
    /**
    * The configured type http to configure countries where content is allowed. A map of URLs to a list of countries
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#geofencing CdnDistribution#geofencing}
    */
    readonly geofencing?: {
        [key: string]: string[];
    } | cdktf.IResolvable;
    /**
    * The configured type http origin request headers for the backend
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#origin_request_headers CdnDistribution#origin_request_headers}
    */
    readonly originRequestHeaders?: {
        [key: string]: string;
    };
    /**
    * The configured backend type http for the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#origin_url CdnDistribution#origin_url}
    */
    readonly originUrl?: string;
    /**
    * The region where the bucket is hosted. Required if type is 'bucket'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#region CdnDistribution#region}
    */
    readonly region?: string;
    /**
    * The configured backend type. Possible values are: `http`, `bucket`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#type CdnDistribution#type}
    */
    readonly type: string;
}
export declare function cdnDistributionConfigBackendToTerraform(struct?: CdnDistributionConfigBackend | cdktf.IResolvable): any;
export declare function cdnDistributionConfigBackendToHclTerraform(struct?: CdnDistributionConfigBackend | cdktf.IResolvable): any;
export declare class CdnDistributionConfigBackendOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigBackend | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigBackend | cdktf.IResolvable | undefined);
    private _bucketUrl?;
    get bucketUrl(): string;
    set bucketUrl(value: string);
    resetBucketUrl(): void;
    get bucketUrlInput(): string | undefined;
    private _credentials;
    get credentials(): CdnDistributionConfigBackendCredentialsOutputReference;
    putCredentials(value: CdnDistributionConfigBackendCredentials): void;
    resetCredentials(): void;
    get credentialsInput(): cdktf.IResolvable | CdnDistributionConfigBackendCredentials | undefined;
    private _geofencing?;
    get geofencing(): {
        [key: string]: string[];
    } | cdktf.IResolvable;
    set geofencing(value: {
        [key: string]: string[];
    } | cdktf.IResolvable);
    resetGeofencing(): void;
    get geofencingInput(): cdktf.IResolvable | {
        [key: string]: string[];
    } | undefined;
    private _originRequestHeaders?;
    get originRequestHeaders(): {
        [key: string]: string;
    };
    set originRequestHeaders(value: {
        [key: string]: string;
    });
    resetOriginRequestHeaders(): void;
    get originRequestHeadersInput(): {
        [key: string]: string;
    } | undefined;
    private _originUrl?;
    get originUrl(): string;
    set originUrl(value: string);
    resetOriginUrl(): void;
    get originUrlInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface CdnDistributionConfigOptimizer {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#enabled CdnDistribution#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
}
export declare function cdnDistributionConfigOptimizerToTerraform(struct?: CdnDistributionConfigOptimizer | cdktf.IResolvable): any;
export declare function cdnDistributionConfigOptimizerToHclTerraform(struct?: CdnDistributionConfigOptimizer | cdktf.IResolvable): any;
export declare class CdnDistributionConfigOptimizerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigOptimizer | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigOptimizer | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface CdnDistributionConfigA {
    /**
    * The configured backend for the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#backend CdnDistribution#backend}
    */
    readonly backend: CdnDistributionConfigBackend;
    /**
    * The configured countries where distribution of content is blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#blocked_countries CdnDistribution#blocked_countries}
    */
    readonly blockedCountries?: string[];
    /**
    * Configuration for the Image Optimizer. This is a paid feature that automatically optimizes images to reduce their file size for faster delivery, leading to improved website performance and a better user experience.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#optimizer CdnDistribution#optimizer}
    */
    readonly optimizer?: CdnDistributionConfigOptimizer;
    /**
    * The configured regions where content will be hosted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#regions CdnDistribution#regions}
    */
    readonly regions: string[];
}
export declare function cdnDistributionConfigAToTerraform(struct?: CdnDistributionConfigA | cdktf.IResolvable): any;
export declare function cdnDistributionConfigAToHclTerraform(struct?: CdnDistributionConfigA | cdktf.IResolvable): any;
export declare class CdnDistributionConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnDistributionConfigA | cdktf.IResolvable | undefined;
    set internalValue(value: CdnDistributionConfigA | cdktf.IResolvable | undefined);
    private _backend;
    get backend(): CdnDistributionConfigBackendOutputReference;
    putBackend(value: CdnDistributionConfigBackend): void;
    get backendInput(): cdktf.IResolvable | CdnDistributionConfigBackend | undefined;
    private _blockedCountries?;
    get blockedCountries(): string[];
    set blockedCountries(value: string[]);
    resetBlockedCountries(): void;
    get blockedCountriesInput(): string[] | undefined;
    private _optimizer;
    get optimizer(): CdnDistributionConfigOptimizerOutputReference;
    putOptimizer(value: CdnDistributionConfigOptimizer): void;
    resetOptimizer(): void;
    get optimizerInput(): cdktf.IResolvable | CdnDistributionConfigOptimizer | undefined;
    private _regions?;
    get regions(): string[];
    set regions(value: string[]);
    get regionsInput(): string[] | undefined;
}
export interface CdnDistributionDomains {
}
export declare function cdnDistributionDomainsToTerraform(struct?: CdnDistributionDomains): any;
export declare function cdnDistributionDomainsToHclTerraform(struct?: CdnDistributionDomains): any;
export declare class CdnDistributionDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnDistributionDomains | undefined;
    set internalValue(value: CdnDistributionDomains | undefined);
    get errors(): string[];
    get name(): string;
    get status(): string;
    get type(): string;
}
export declare class CdnDistributionDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnDistributionDomainsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution stackit_cdn_distribution}
*/
export declare class CdnDistribution extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_cdn_distribution";
    /**
    * Generates CDKTF code for importing a CdnDistribution resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnDistribution to import
    * @param importFromId The id of the existing CdnDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/cdn_distribution stackit_cdn_distribution} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnDistributionConfig
    */
    constructor(scope: Construct, id: string, config: CdnDistributionConfig);
    private _config;
    get config(): CdnDistributionConfigAOutputReference;
    putConfig(value: CdnDistributionConfigA): void;
    get configInput(): cdktf.IResolvable | CdnDistributionConfigA | undefined;
    get createdAt(): string;
    get distributionId(): string;
    private _domains;
    get domains(): CdnDistributionDomainsList;
    get errors(): string[];
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
