# `data_stackit_telemetryrouter_access_token`

Refer to the Terraform Registry for docs: [`data_stackit_telemetryrouter_access_token`](https://registry.terraform.io/providers/stackitcloud/stackit/0.116.0/docs/data-sources/telemetryrouter_access_token).
