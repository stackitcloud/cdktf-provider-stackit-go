import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitTelemetryrouterAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access token ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token#access_token_id DataStackitTelemetryrouterAccessToken#access_token_id}
    */
    readonly accessTokenId: string;
    /**
    * The TelemetryRouter instance ID associated with the access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token#instance_id DataStackitTelemetryrouterAccessToken#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID associated with the TelemetryRouter access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token#project_id DataStackitTelemetryrouterAccessToken#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token#region DataStackitTelemetryrouterAccessToken#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token stackit_telemetryrouter_access_token}
*/
export declare class DataStackitTelemetryrouterAccessToken extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_telemetryrouter_access_token";
    /**
    * Generates CDKTF code for importing a DataStackitTelemetryrouterAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitTelemetryrouterAccessToken to import
    * @param importFromId The id of the existing DataStackitTelemetryrouterAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitTelemetryrouterAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_access_token stackit_telemetryrouter_access_token} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitTelemetryrouterAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitTelemetryrouterAccessTokenConfig);
    private _accessTokenId?;
    get accessTokenId(): string;
    set accessTokenId(value: string);
    get accessTokenIdInput(): string | undefined;
    get creatorId(): string;
    get description(): string;
    get displayName(): string;
    get expirationTime(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
