import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitMariadbInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the MariaDB instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance#instance_id DataStackitMariadbInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance#project_id DataStackitMariadbInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitMariadbInstanceParameters {
}
export declare function dataStackitMariadbInstanceParametersToTerraform(struct?: DataStackitMariadbInstanceParameters): any;
export declare function dataStackitMariadbInstanceParametersToHclTerraform(struct?: DataStackitMariadbInstanceParameters): any;
export declare class DataStackitMariadbInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitMariadbInstanceParameters | undefined;
    set internalValue(value: DataStackitMariadbInstanceParameters | undefined);
    get enableMonitoring(): cdktf.IResolvable;
    get graphite(): string;
    get maxDiskThreshold(): number;
    get metricsFrequency(): number;
    get metricsPrefix(): string;
    get monitoringInstanceId(): string;
    get sgwAcl(): string;
    get syslog(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance stackit_mariadb_instance}
*/
export declare class DataStackitMariadbInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_mariadb_instance";
    /**
    * Generates CDKTF code for importing a DataStackitMariadbInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitMariadbInstance to import
    * @param importFromId The id of the existing DataStackitMariadbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitMariadbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance stackit_mariadb_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitMariadbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitMariadbInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _parameters;
    get parameters(): DataStackitMariadbInstanceParametersOutputReference;
    get planId(): string;
    get planName(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
