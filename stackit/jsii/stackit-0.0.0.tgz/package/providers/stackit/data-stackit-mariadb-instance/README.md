# `data_stackit_mariadb_instance`

Refer to the Terraform Registry for docs: [`data_stackit_mariadb_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/mariadb_instance).
