import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MariadbInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#name MariadbInstance#name}
    */
    readonly name: string;
    /**
    * Configuration parameters. Please note that removing a previously configured field from your Terraform configuration won't replace its value in the API. To update a previously configured field, explicitly set a new value for it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#parameters MariadbInstance#parameters}
    */
    readonly parameters?: MariadbInstanceParameters;
    /**
    * The selected plan name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#plan_name MariadbInstance#plan_name}
    */
    readonly planName: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#project_id MariadbInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The service version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#version MariadbInstance#version}
    */
    readonly version: string;
}
export interface MariadbInstanceParameters {
    /**
    * Enable monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#enable_monitoring MariadbInstance#enable_monitoring}
    */
    readonly enableMonitoring?: boolean | cdktf.IResolvable;
    /**
    * Graphite server URL (host and port). If set, monitoring with Graphite will be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#graphite MariadbInstance#graphite}
    */
    readonly graphite?: string;
    /**
    * The maximum disk threshold in MB. If the disk usage exceeds this threshold, the instance will be stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#max_disk_threshold MariadbInstance#max_disk_threshold}
    */
    readonly maxDiskThreshold?: number;
    /**
    * The frequency in seconds at which metrics are emitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#metrics_frequency MariadbInstance#metrics_frequency}
    */
    readonly metricsFrequency?: number;
    /**
    * The prefix for the metrics. Could be useful when using Graphite monitoring to prefix the metrics with a certain value, like an API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#metrics_prefix MariadbInstance#metrics_prefix}
    */
    readonly metricsPrefix?: string;
    /**
    * The ID of the STACKIT monitoring instance. Monitoring instances with the plan "Observability-Monitoring-Starter" are not supported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#monitoring_instance_id MariadbInstance#monitoring_instance_id}
    */
    readonly monitoringInstanceId?: string;
    /**
    * Comma separated list of IP networks in CIDR notation which are allowed to access this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#sgw_acl MariadbInstance#sgw_acl}
    */
    readonly sgwAcl?: string;
    /**
    * List of syslog servers to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#syslog MariadbInstance#syslog}
    */
    readonly syslog?: string[];
}
export declare function mariadbInstanceParametersToTerraform(struct?: MariadbInstanceParameters | cdktf.IResolvable): any;
export declare function mariadbInstanceParametersToHclTerraform(struct?: MariadbInstanceParameters | cdktf.IResolvable): any;
export declare class MariadbInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MariadbInstanceParameters | cdktf.IResolvable | undefined;
    set internalValue(value: MariadbInstanceParameters | cdktf.IResolvable | undefined);
    private _enableMonitoring?;
    get enableMonitoring(): boolean | cdktf.IResolvable;
    set enableMonitoring(value: boolean | cdktf.IResolvable);
    resetEnableMonitoring(): void;
    get enableMonitoringInput(): boolean | cdktf.IResolvable | undefined;
    private _graphite?;
    get graphite(): string;
    set graphite(value: string);
    resetGraphite(): void;
    get graphiteInput(): string | undefined;
    private _maxDiskThreshold?;
    get maxDiskThreshold(): number;
    set maxDiskThreshold(value: number);
    resetMaxDiskThreshold(): void;
    get maxDiskThresholdInput(): number | undefined;
    private _metricsFrequency?;
    get metricsFrequency(): number;
    set metricsFrequency(value: number);
    resetMetricsFrequency(): void;
    get metricsFrequencyInput(): number | undefined;
    private _metricsPrefix?;
    get metricsPrefix(): string;
    set metricsPrefix(value: string);
    resetMetricsPrefix(): void;
    get metricsPrefixInput(): string | undefined;
    private _monitoringInstanceId?;
    get monitoringInstanceId(): string;
    set monitoringInstanceId(value: string);
    resetMonitoringInstanceId(): void;
    get monitoringInstanceIdInput(): string | undefined;
    private _sgwAcl?;
    get sgwAcl(): string;
    set sgwAcl(value: string);
    resetSgwAcl(): void;
    get sgwAclInput(): string | undefined;
    private _syslog?;
    get syslog(): string[];
    set syslog(value: string[]);
    resetSyslog(): void;
    get syslogInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance stackit_mariadb_instance}
*/
export declare class MariadbInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_mariadb_instance";
    /**
    * Generates CDKTF code for importing a MariadbInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MariadbInstance to import
    * @param importFromId The id of the existing MariadbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MariadbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/mariadb_instance stackit_mariadb_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MariadbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: MariadbInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): MariadbInstanceParametersOutputReference;
    putParameters(value: MariadbInstanceParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | MariadbInstanceParameters | undefined;
    get planId(): string;
    private _planName?;
    get planName(): string;
    set planName(value: string);
    get planNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
