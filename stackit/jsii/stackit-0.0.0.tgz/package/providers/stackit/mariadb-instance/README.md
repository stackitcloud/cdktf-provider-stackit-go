# `stackit_mariadb_instance`

Refer to the Terraform Registry for docs: [`stackit_mariadb_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/mariadb_instance).
