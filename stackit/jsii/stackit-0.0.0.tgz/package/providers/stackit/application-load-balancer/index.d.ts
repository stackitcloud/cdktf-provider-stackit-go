import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ApplicationLoadBalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Disable target security group assignemt to allow targets outside of the given network. Connectivity to targets need to be ensured by the customer, including routing and Security Groups (targetSecurityGroup can be assigned). Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#disable_target_security_group_assignment ApplicationLoadBalancer#disable_target_security_group_assignment}
    */
    readonly disableTargetSecurityGroupAssignment?: boolean | cdktf.IResolvable;
    /**
    * The external IP address where this Application Load Balancer is exposed. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#external_address ApplicationLoadBalancer#external_address}
    */
    readonly externalAddress?: string;
    /**
    * Labels represent user-defined metadata as key-value pairs. Label count cannot exceed 64 per ALB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#labels ApplicationLoadBalancer#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * List of all listeners which will accept traffic. Limited to 20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#listeners ApplicationLoadBalancer#listeners}
    */
    readonly listeners: ApplicationLoadBalancerListeners[] | cdktf.IResolvable;
    /**
    * Application Load balancer name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
    /**
    * List of networks that listeners and targets reside in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#networks ApplicationLoadBalancer#networks}
    */
    readonly networks: ApplicationLoadBalancerNetworks[] | cdktf.IResolvable;
    /**
    * Defines any optional functionality you want to have enabled on your Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#options ApplicationLoadBalancer#options}
    */
    readonly options?: ApplicationLoadBalancerOptions;
    /**
    * Service Plan configures the size of the Application Load Balancer e.g. 'p10'. See available plans via STACKIT CLI 'stackit beta alb plans' or API https://docs.api.stackit.cloud/documentation/alb/version/v2#tag/Project/operation/APIService_ListPlans
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#plan_id ApplicationLoadBalancer#plan_id}
    */
    readonly planId: string;
    /**
    * STACKIT project ID to which the Application Load Balancer is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#project_id ApplicationLoadBalancer#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region (e.g. eu01). If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#region ApplicationLoadBalancer#region}
    */
    readonly region?: string;
    /**
    * List of all target pools which will be used in the Application Load Balancer. Limited to 20.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#target_pools ApplicationLoadBalancer#target_pools}
    */
    readonly targetPools: ApplicationLoadBalancerTargetPools[] | cdktf.IResolvable;
}
export interface ApplicationLoadBalancerErrors {
}
export declare function applicationLoadBalancerErrorsToTerraform(struct?: ApplicationLoadBalancerErrors): any;
export declare function applicationLoadBalancerErrorsToHclTerraform(struct?: ApplicationLoadBalancerErrors): any;
export declare class ApplicationLoadBalancerErrorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerErrors | undefined;
    set internalValue(value: ApplicationLoadBalancerErrors | undefined);
    get description(): string;
    get type(): string;
}
export declare class ApplicationLoadBalancerErrorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerErrorsOutputReference;
}
export interface ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence {
    /**
    * The name of the cookie to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
    /**
    * TTL specifies the time-to-live for the cookie. The default value is 0s, and it acts as a session cookie, expiring when the client session ends.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#ttl ApplicationLoadBalancer#ttl}
    */
    readonly ttl: string;
}
export declare function applicationLoadBalancerListenersHttpHostsRulesCookiePersistenceToTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsRulesCookiePersistenceToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ttl?;
    get ttl(): string;
    set ttl(value: string);
    get ttlInput(): string | undefined;
}
export interface ApplicationLoadBalancerListenersHttpHostsRulesHeaders {
    /**
    * Exact match for the header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#exact_match ApplicationLoadBalancer#exact_match}
    */
    readonly exactMatch?: string;
    /**
    * Header name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
}
export declare function applicationLoadBalancerListenersHttpHostsRulesHeadersToTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesHeaders | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsRulesHeadersToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesHeaders | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsRulesHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerListenersHttpHostsRulesHeaders | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHostsRulesHeaders | cdktf.IResolvable | undefined);
    private _exactMatch?;
    get exactMatch(): string;
    set exactMatch(value: string);
    resetExactMatch(): void;
    get exactMatchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApplicationLoadBalancerListenersHttpHostsRulesHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerListenersHttpHostsRulesHeaders[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerListenersHttpHostsRulesHeadersOutputReference;
}
export interface ApplicationLoadBalancerListenersHttpHostsRulesPath {
    /**
    * Exact path match. Only a request path exactly equal to the value will match, e.g. '/foo' matches only '/foo', not '/foo/bar' or '/foobar'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#exact_match ApplicationLoadBalancer#exact_match}
    */
    readonly exactMatch?: string;
    /**
    * Prefix path match. Only matches on full segment boundaries, e.g. '/foo' matches '/foo' and '/foo/bar' but NOT '/foobar'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#prefix ApplicationLoadBalancer#prefix}
    */
    readonly prefix?: string;
}
export declare function applicationLoadBalancerListenersHttpHostsRulesPathToTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesPath | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsRulesPathToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesPath | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsRulesPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerListenersHttpHostsRulesPath | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHostsRulesPath | cdktf.IResolvable | undefined);
    private _exactMatch?;
    get exactMatch(): string;
    set exactMatch(value: string);
    resetExactMatch(): void;
    get exactMatchInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
}
export interface ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters {
    /**
    * Exact match for the query parameters value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#exact_match ApplicationLoadBalancer#exact_match}
    */
    readonly exactMatch?: string;
    /**
    * Query parameter name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
}
export declare function applicationLoadBalancerListenersHttpHostsRulesQueryParametersToTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsRulesQueryParametersToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsRulesQueryParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | cdktf.IResolvable | undefined);
    private _exactMatch?;
    get exactMatch(): string;
    set exactMatch(value: string);
    resetExactMatch(): void;
    get exactMatchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApplicationLoadBalancerListenersHttpHostsRulesQueryParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerListenersHttpHostsRulesQueryParametersOutputReference;
}
export interface ApplicationLoadBalancerListenersHttpHostsRules {
    /**
    * Routing persistence via cookies.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#cookie_persistence ApplicationLoadBalancer#cookie_persistence}
    */
    readonly cookiePersistence?: ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence;
    /**
    * Headers for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#headers ApplicationLoadBalancer#headers}
    */
    readonly headers?: ApplicationLoadBalancerListenersHttpHostsRulesHeaders[] | cdktf.IResolvable;
    /**
    * Routing via path.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#path ApplicationLoadBalancer#path}
    */
    readonly path?: ApplicationLoadBalancerListenersHttpHostsRulesPath;
    /**
    * Query parameters for the rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#query_parameters ApplicationLoadBalancer#query_parameters}
    */
    readonly queryParameters?: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters[] | cdktf.IResolvable;
    /**
    * Reference target pool by target pool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#target_pool ApplicationLoadBalancer#target_pool}
    */
    readonly targetPool: string;
    /**
    * If enabled, when client sends an HTTP request with and Upgrade header, indicating the desire to establish a Websocket connection, if backend server supports WebSocket, it responds with HTTP 101 status code, switching protocols from HTTP to WebSocket. Hence the client and the server can exchange data in real-time using one long-lived TCP connection.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#web_socket ApplicationLoadBalancer#web_socket}
    */
    readonly webSocket?: boolean | cdktf.IResolvable;
}
export declare function applicationLoadBalancerListenersHttpHostsRulesToTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRules | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsRulesToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHostsRules | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerListenersHttpHostsRules | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHostsRules | cdktf.IResolvable | undefined);
    private _cookiePersistence;
    get cookiePersistence(): ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceOutputReference;
    putCookiePersistence(value: ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence): void;
    resetCookiePersistence(): void;
    get cookiePersistenceInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | undefined;
    private _headers;
    get headers(): ApplicationLoadBalancerListenersHttpHostsRulesHeadersList;
    putHeaders(value: ApplicationLoadBalancerListenersHttpHostsRulesHeaders[] | cdktf.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHostsRulesHeaders[] | undefined;
    private _path;
    get path(): ApplicationLoadBalancerListenersHttpHostsRulesPathOutputReference;
    putPath(value: ApplicationLoadBalancerListenersHttpHostsRulesPath): void;
    resetPath(): void;
    get pathInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHostsRulesPath | undefined;
    private _queryParameters;
    get queryParameters(): ApplicationLoadBalancerListenersHttpHostsRulesQueryParametersList;
    putQueryParameters(value: ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters[] | cdktf.IResolvable): void;
    resetQueryParameters(): void;
    get queryParametersInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHostsRulesQueryParameters[] | undefined;
    private _targetPool?;
    get targetPool(): string;
    set targetPool(value: string);
    get targetPoolInput(): string | undefined;
    private _webSocket?;
    get webSocket(): boolean | cdktf.IResolvable;
    set webSocket(value: boolean | cdktf.IResolvable);
    resetWebSocket(): void;
    get webSocketInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class ApplicationLoadBalancerListenersHttpHostsRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerListenersHttpHostsRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerListenersHttpHostsRulesOutputReference;
}
export interface ApplicationLoadBalancerListenersHttpHosts {
    /**
    * Hostname to match. Supports wildcards (e.g. *.example.com).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#host ApplicationLoadBalancer#host}
    */
    readonly host: string;
    /**
    * Routing rules under the specified host, matched by path prefix.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#rules ApplicationLoadBalancer#rules}
    */
    readonly rules: ApplicationLoadBalancerListenersHttpHostsRules[] | cdktf.IResolvable;
}
export declare function applicationLoadBalancerListenersHttpHostsToTerraform(struct?: ApplicationLoadBalancerListenersHttpHosts | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpHostsToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpHosts | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpHostsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerListenersHttpHosts | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpHosts | cdktf.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    get hostInput(): string | undefined;
    private _rules;
    get rules(): ApplicationLoadBalancerListenersHttpHostsRulesList;
    putRules(value: ApplicationLoadBalancerListenersHttpHostsRules[] | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHostsRules[] | undefined;
}
export declare class ApplicationLoadBalancerListenersHttpHostsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerListenersHttpHosts[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerListenersHttpHostsOutputReference;
}
export interface ApplicationLoadBalancerListenersHttp {
    /**
    * Defines routing rules grouped by hostname.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#hosts ApplicationLoadBalancer#hosts}
    */
    readonly hosts: ApplicationLoadBalancerListenersHttpHosts[] | cdktf.IResolvable;
}
export declare function applicationLoadBalancerListenersHttpToTerraform(struct?: ApplicationLoadBalancerListenersHttp | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpToHclTerraform(struct?: ApplicationLoadBalancerListenersHttp | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerListenersHttp | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttp | cdktf.IResolvable | undefined);
    private _hosts;
    get hosts(): ApplicationLoadBalancerListenersHttpHostsList;
    putHosts(value: ApplicationLoadBalancerListenersHttpHosts[] | cdktf.IResolvable): void;
    get hostsInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpHosts[] | undefined;
}
export interface ApplicationLoadBalancerListenersHttpsCertificateConfig {
    /**
    * Certificate IDs for TLS termination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#certificate_ids ApplicationLoadBalancer#certificate_ids}
    */
    readonly certificateIds: string[];
}
export declare function applicationLoadBalancerListenersHttpsCertificateConfigToTerraform(struct?: ApplicationLoadBalancerListenersHttpsCertificateConfig | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpsCertificateConfigToHclTerraform(struct?: ApplicationLoadBalancerListenersHttpsCertificateConfig | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpsCertificateConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerListenersHttpsCertificateConfig | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttpsCertificateConfig | cdktf.IResolvable | undefined);
    private _certificateIds?;
    get certificateIds(): string[];
    set certificateIds(value: string[]);
    get certificateIdsInput(): string[] | undefined;
}
export interface ApplicationLoadBalancerListenersHttps {
    /**
    * TLS termination certificate configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#certificate_config ApplicationLoadBalancer#certificate_config}
    */
    readonly certificateConfig: ApplicationLoadBalancerListenersHttpsCertificateConfig;
}
export declare function applicationLoadBalancerListenersHttpsToTerraform(struct?: ApplicationLoadBalancerListenersHttps | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersHttpsToHclTerraform(struct?: ApplicationLoadBalancerListenersHttps | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersHttpsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerListenersHttps | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListenersHttps | cdktf.IResolvable | undefined);
    private _certificateConfig;
    get certificateConfig(): ApplicationLoadBalancerListenersHttpsCertificateConfigOutputReference;
    putCertificateConfig(value: ApplicationLoadBalancerListenersHttpsCertificateConfig): void;
    get certificateConfigInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttpsCertificateConfig | undefined;
}
export interface ApplicationLoadBalancerListeners {
    /**
    * Configuration for HTTP traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#http ApplicationLoadBalancer#http}
    */
    readonly http: ApplicationLoadBalancerListenersHttp;
    /**
    * Configuration for handling HTTPS traffic on this listener.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#https ApplicationLoadBalancer#https}
    */
    readonly https?: ApplicationLoadBalancerListenersHttps;
    /**
    * Unique name for the listener
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
    /**
    * Port number on which the listener receives incoming traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#port ApplicationLoadBalancer#port}
    */
    readonly port: number;
    /**
    * Protocol is the highest network protocol we understand to load balance. Possible values are: `PROTOCOL_UNSPECIFIED`, `PROTOCOL_HTTP`, `PROTOCOL_HTTPS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#protocol ApplicationLoadBalancer#protocol}
    */
    readonly protocol: string;
    /**
    * Enable Web Application Firewall (WAF), referenced by name. See "Application Load Balancer - Web Application Firewall API" for more information.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#waf_config_name ApplicationLoadBalancer#waf_config_name}
    */
    readonly wafConfigName?: string;
}
export declare function applicationLoadBalancerListenersToTerraform(struct?: ApplicationLoadBalancerListeners | cdktf.IResolvable): any;
export declare function applicationLoadBalancerListenersToHclTerraform(struct?: ApplicationLoadBalancerListeners | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerListenersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerListeners | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerListeners | cdktf.IResolvable | undefined);
    private _http;
    get http(): ApplicationLoadBalancerListenersHttpOutputReference;
    putHttp(value: ApplicationLoadBalancerListenersHttp): void;
    get httpInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttp | undefined;
    private _https;
    get https(): ApplicationLoadBalancerListenersHttpsOutputReference;
    putHttps(value: ApplicationLoadBalancerListenersHttps): void;
    resetHttps(): void;
    get httpsInput(): cdktf.IResolvable | ApplicationLoadBalancerListenersHttps | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _wafConfigName?;
    get wafConfigName(): string;
    set wafConfigName(value: string);
    resetWafConfigName(): void;
    get wafConfigNameInput(): string | undefined;
}
export declare class ApplicationLoadBalancerListenersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerListeners[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerListenersOutputReference;
}
export interface ApplicationLoadBalancerLoadBalancerSecurityGroup {
}
export declare function applicationLoadBalancerLoadBalancerSecurityGroupToTerraform(struct?: ApplicationLoadBalancerLoadBalancerSecurityGroup): any;
export declare function applicationLoadBalancerLoadBalancerSecurityGroupToHclTerraform(struct?: ApplicationLoadBalancerLoadBalancerSecurityGroup): any;
export declare class ApplicationLoadBalancerLoadBalancerSecurityGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerLoadBalancerSecurityGroup | undefined;
    set internalValue(value: ApplicationLoadBalancerLoadBalancerSecurityGroup | undefined);
    get id(): string;
    get name(): string;
}
export interface ApplicationLoadBalancerNetworks {
    /**
    * STACKIT network ID the Application Load Balancer and/or targets are in.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#network_id ApplicationLoadBalancer#network_id}
    */
    readonly networkId: string;
    /**
    * The role defines how the Application Load Balancer is using the network. Possible values are: `ROLE_UNSPECIFIED`, `ROLE_LISTENERS_AND_TARGETS`, `ROLE_LISTENERS`, `ROLE_TARGETS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#role ApplicationLoadBalancer#role}
    */
    readonly role: string;
}
export declare function applicationLoadBalancerNetworksToTerraform(struct?: ApplicationLoadBalancerNetworks | cdktf.IResolvable): any;
export declare function applicationLoadBalancerNetworksToHclTerraform(struct?: ApplicationLoadBalancerNetworks | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerNetworksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerNetworks | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerNetworks | cdktf.IResolvable | undefined);
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
}
export declare class ApplicationLoadBalancerNetworksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerNetworks[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerNetworksOutputReference;
}
export interface ApplicationLoadBalancerOptionsAccessControl {
    /**
    * Application Load Balancer is accessible only from an IP address in this range.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#allowed_source_ranges ApplicationLoadBalancer#allowed_source_ranges}
    */
    readonly allowedSourceRanges: string[];
}
export declare function applicationLoadBalancerOptionsAccessControlToTerraform(struct?: ApplicationLoadBalancerOptionsAccessControl | cdktf.IResolvable): any;
export declare function applicationLoadBalancerOptionsAccessControlToHclTerraform(struct?: ApplicationLoadBalancerOptionsAccessControl | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerOptionsAccessControlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerOptionsAccessControl | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerOptionsAccessControl | cdktf.IResolvable | undefined);
    private _allowedSourceRanges?;
    get allowedSourceRanges(): string[];
    set allowedSourceRanges(value: string[]);
    get allowedSourceRangesInput(): string[] | undefined;
}
export interface ApplicationLoadBalancerOptionsObservabilityLogs {
    /**
    * Credentials reference for logging. This reference is created via the observability create endpoint and the credential needs to contain the basic auth username and password for the logging solution the push URL points to. Then this enables monitoring via remote write for the Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#credentials_ref ApplicationLoadBalancer#credentials_ref}
    */
    readonly credentialsRef: string;
    /**
    * Credentials reference for logging. This reference is created via the observability create endpoint and the credential needs to contain the basic auth username and password for the logging solution the push URL points to. Then this enables monitoring via remote write for the Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#push_url ApplicationLoadBalancer#push_url}
    */
    readonly pushUrl: string;
}
export declare function applicationLoadBalancerOptionsObservabilityLogsToTerraform(struct?: ApplicationLoadBalancerOptionsObservabilityLogs | cdktf.IResolvable): any;
export declare function applicationLoadBalancerOptionsObservabilityLogsToHclTerraform(struct?: ApplicationLoadBalancerOptionsObservabilityLogs | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerOptionsObservabilityLogsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerOptionsObservabilityLogs | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerOptionsObservabilityLogs | cdktf.IResolvable | undefined);
    private _credentialsRef?;
    get credentialsRef(): string;
    set credentialsRef(value: string);
    get credentialsRefInput(): string | undefined;
    private _pushUrl?;
    get pushUrl(): string;
    set pushUrl(value: string);
    get pushUrlInput(): string | undefined;
}
export interface ApplicationLoadBalancerOptionsObservabilityMetrics {
    /**
    * Credentials reference for metrics. This reference is created via the observability create endpoint and the credential needs to contain the basic auth username and password for the metrics solution the push URL points to. Then this enables monitoring via remote write for the Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#credentials_ref ApplicationLoadBalancer#credentials_ref}
    */
    readonly credentialsRef: string;
    /**
    * Credentials reference for metrics. This reference is created via the observability create endpoint and the credential needs to contain the basic auth username and password for the metrics solution the push URL points to. Then this enables monitoring via remote write for the Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#push_url ApplicationLoadBalancer#push_url}
    */
    readonly pushUrl: string;
}
export declare function applicationLoadBalancerOptionsObservabilityMetricsToTerraform(struct?: ApplicationLoadBalancerOptionsObservabilityMetrics | cdktf.IResolvable): any;
export declare function applicationLoadBalancerOptionsObservabilityMetricsToHclTerraform(struct?: ApplicationLoadBalancerOptionsObservabilityMetrics | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerOptionsObservabilityMetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerOptionsObservabilityMetrics | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerOptionsObservabilityMetrics | cdktf.IResolvable | undefined);
    private _credentialsRef?;
    get credentialsRef(): string;
    set credentialsRef(value: string);
    get credentialsRefInput(): string | undefined;
    private _pushUrl?;
    get pushUrl(): string;
    set pushUrl(value: string);
    get pushUrlInput(): string | undefined;
}
export interface ApplicationLoadBalancerOptionsObservability {
    /**
    * Observability logs configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#logs ApplicationLoadBalancer#logs}
    */
    readonly logs?: ApplicationLoadBalancerOptionsObservabilityLogs;
    /**
    * Observability metrics configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#metrics ApplicationLoadBalancer#metrics}
    */
    readonly metrics?: ApplicationLoadBalancerOptionsObservabilityMetrics;
}
export declare function applicationLoadBalancerOptionsObservabilityToTerraform(struct?: ApplicationLoadBalancerOptionsObservability | cdktf.IResolvable): any;
export declare function applicationLoadBalancerOptionsObservabilityToHclTerraform(struct?: ApplicationLoadBalancerOptionsObservability | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerOptionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerOptionsObservability | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerOptionsObservability | cdktf.IResolvable | undefined);
    private _logs;
    get logs(): ApplicationLoadBalancerOptionsObservabilityLogsOutputReference;
    putLogs(value: ApplicationLoadBalancerOptionsObservabilityLogs): void;
    resetLogs(): void;
    get logsInput(): cdktf.IResolvable | ApplicationLoadBalancerOptionsObservabilityLogs | undefined;
    private _metrics;
    get metrics(): ApplicationLoadBalancerOptionsObservabilityMetricsOutputReference;
    putMetrics(value: ApplicationLoadBalancerOptionsObservabilityMetrics): void;
    resetMetrics(): void;
    get metricsInput(): cdktf.IResolvable | ApplicationLoadBalancerOptionsObservabilityMetrics | undefined;
}
export interface ApplicationLoadBalancerOptions {
    /**
    * Use this option to limit the IP ranges that can use the Application Load Balancer.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#access_control ApplicationLoadBalancer#access_control}
    */
    readonly accessControl?: ApplicationLoadBalancerOptionsAccessControl;
    /**
    * This option automates the handling of the external IP address for an Application Load Balancer. If set to true a new IP address will be automatically created. It will also be automatically deleted when the Load Balancer is deleted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#ephemeral_address ApplicationLoadBalancer#ephemeral_address}
    */
    readonly ephemeralAddress?: boolean | cdktf.IResolvable;
    /**
    * We offer Load Balancer observability via STACKIT Observability or external solutions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#observability ApplicationLoadBalancer#observability}
    */
    readonly observability?: ApplicationLoadBalancerOptionsObservability;
    /**
    * Application Load Balancer is accessible only via a private network ip address. Not changeable after creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#private_network_only ApplicationLoadBalancer#private_network_only}
    */
    readonly privateNetworkOnly?: boolean | cdktf.IResolvable;
}
export declare function applicationLoadBalancerOptionsToTerraform(struct?: ApplicationLoadBalancerOptions | cdktf.IResolvable): any;
export declare function applicationLoadBalancerOptionsToHclTerraform(struct?: ApplicationLoadBalancerOptions | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerOptions | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerOptions | cdktf.IResolvable | undefined);
    private _accessControl;
    get accessControl(): ApplicationLoadBalancerOptionsAccessControlOutputReference;
    putAccessControl(value: ApplicationLoadBalancerOptionsAccessControl): void;
    resetAccessControl(): void;
    get accessControlInput(): cdktf.IResolvable | ApplicationLoadBalancerOptionsAccessControl | undefined;
    private _ephemeralAddress?;
    get ephemeralAddress(): boolean | cdktf.IResolvable;
    set ephemeralAddress(value: boolean | cdktf.IResolvable);
    resetEphemeralAddress(): void;
    get ephemeralAddressInput(): boolean | cdktf.IResolvable | undefined;
    private _observability;
    get observability(): ApplicationLoadBalancerOptionsObservabilityOutputReference;
    putObservability(value: ApplicationLoadBalancerOptionsObservability): void;
    resetObservability(): void;
    get observabilityInput(): cdktf.IResolvable | ApplicationLoadBalancerOptionsObservability | undefined;
    private _privateNetworkOnly?;
    get privateNetworkOnly(): boolean | cdktf.IResolvable;
    set privateNetworkOnly(value: boolean | cdktf.IResolvable);
    resetPrivateNetworkOnly(): void;
    get privateNetworkOnlyInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks {
    /**
    * List of HTTP status codes that indicate a healthy response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#ok_status ApplicationLoadBalancer#ok_status}
    */
    readonly okStatus: string[];
    /**
    * Path to send the health check request to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#path ApplicationLoadBalancer#path}
    */
    readonly path: string;
}
export declare function applicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksToTerraform(struct?: ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | cdktf.IResolvable): any;
export declare function applicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksToHclTerraform(struct?: ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | cdktf.IResolvable | undefined);
    private _okStatus?;
    get okStatus(): string[];
    set okStatus(value: string[]);
    get okStatusInput(): string[] | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export interface ApplicationLoadBalancerTargetPoolsActiveHealthCheck {
    /**
    * Healthy threshold of the health checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#healthy_threshold ApplicationLoadBalancer#healthy_threshold}
    */
    readonly healthyThreshold: number;
    /**
    * Options for the HTTP health checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#http_health_checks ApplicationLoadBalancer#http_health_checks}
    */
    readonly httpHealthChecks?: ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks;
    /**
    * Interval duration of health checking in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#interval ApplicationLoadBalancer#interval}
    */
    readonly interval: string;
    /**
    * Interval duration threshold of the health checking in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#interval_jitter ApplicationLoadBalancer#interval_jitter}
    */
    readonly intervalJitter: string;
    /**
    * Active health checking timeout duration in seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#timeout ApplicationLoadBalancer#timeout}
    */
    readonly timeout: string;
    /**
    * Unhealthy threshold of the health checking.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#unhealthy_threshold ApplicationLoadBalancer#unhealthy_threshold}
    */
    readonly unhealthyThreshold: number;
}
export declare function applicationLoadBalancerTargetPoolsActiveHealthCheckToTerraform(struct?: ApplicationLoadBalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable): any;
export declare function applicationLoadBalancerTargetPoolsActiveHealthCheckToHclTerraform(struct?: ApplicationLoadBalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerTargetPoolsActiveHealthCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetPoolsActiveHealthCheck | cdktf.IResolvable | undefined);
    private _healthyThreshold?;
    get healthyThreshold(): number;
    set healthyThreshold(value: number);
    get healthyThresholdInput(): number | undefined;
    private _httpHealthChecks;
    get httpHealthChecks(): ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksOutputReference;
    putHttpHealthChecks(value: ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks): void;
    resetHttpHealthChecks(): void;
    get httpHealthChecksInput(): cdktf.IResolvable | ApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    get intervalInput(): string | undefined;
    private _intervalJitter?;
    get intervalJitter(): string;
    set intervalJitter(value: string);
    get intervalJitterInput(): string | undefined;
    private _timeout?;
    get timeout(): string;
    set timeout(value: string);
    get timeoutInput(): string | undefined;
    private _unhealthyThreshold?;
    get unhealthyThreshold(): number;
    set unhealthyThreshold(value: number);
    get unhealthyThresholdInput(): number | undefined;
}
export interface ApplicationLoadBalancerTargetPoolsTargets {
    /**
    * Target display name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#display_name ApplicationLoadBalancer#display_name}
    */
    readonly displayName?: string;
    /**
    * Private target IP, which must by unique within a target pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#ip ApplicationLoadBalancer#ip}
    */
    readonly ip: string;
}
export declare function applicationLoadBalancerTargetPoolsTargetsToTerraform(struct?: ApplicationLoadBalancerTargetPoolsTargets | cdktf.IResolvable): any;
export declare function applicationLoadBalancerTargetPoolsTargetsToHclTerraform(struct?: ApplicationLoadBalancerTargetPoolsTargets | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerTargetPoolsTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerTargetPoolsTargets | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetPoolsTargets | cdktf.IResolvable | undefined);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _ip?;
    get ip(): string;
    set ip(value: string);
    get ipInput(): string | undefined;
}
export declare class ApplicationLoadBalancerTargetPoolsTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerTargetPoolsTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerTargetPoolsTargetsOutputReference;
}
export interface ApplicationLoadBalancerTargetPoolsTlsConfig {
    /**
    * Specifies a custom Certificate Authority (CA). When provided, the target pool will trust certificates signed by this CA, in addition to any system-trusted CAs. This is useful for scenarios where the target pool needs to communicate with servers using self-signed or internally-issued certificates. Enabled needs to be set to true and skip validation to false for this option.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#custom_ca ApplicationLoadBalancer#custom_ca}
    */
    readonly customCa?: string;
    /**
    * Enable TLS (Transport Layer Security) bridging for the connection between Application Load Balancer and targets in this pool. When enabled, public CAs are trusted. Can be used in tandem with the options either custom CA or skip validation or alone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#enabled ApplicationLoadBalancer#enabled}
    */
    readonly enabled?: boolean | cdktf.IResolvable;
    /**
    * Bypass certificate validation for TLS bridging in this target pool. This option is insecure and can only be used with public CAs by setting enabled true. Meant to be used for testing purposes only!
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#skip_certificate_validation ApplicationLoadBalancer#skip_certificate_validation}
    */
    readonly skipCertificateValidation?: boolean | cdktf.IResolvable;
}
export declare function applicationLoadBalancerTargetPoolsTlsConfigToTerraform(struct?: ApplicationLoadBalancerTargetPoolsTlsConfig | cdktf.IResolvable): any;
export declare function applicationLoadBalancerTargetPoolsTlsConfigToHclTerraform(struct?: ApplicationLoadBalancerTargetPoolsTlsConfig | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerTargetPoolsTlsConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerTargetPoolsTlsConfig | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetPoolsTlsConfig | cdktf.IResolvable | undefined);
    private _customCa?;
    get customCa(): string;
    set customCa(value: string);
    resetCustomCa(): void;
    get customCaInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _skipCertificateValidation?;
    get skipCertificateValidation(): boolean | cdktf.IResolvable;
    set skipCertificateValidation(value: boolean | cdktf.IResolvable);
    resetSkipCertificateValidation(): void;
    get skipCertificateValidationInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ApplicationLoadBalancerTargetPools {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#active_health_check ApplicationLoadBalancer#active_health_check}
    */
    readonly activeHealthCheck?: ApplicationLoadBalancerTargetPoolsActiveHealthCheck;
    /**
    * Target pool name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#name ApplicationLoadBalancer#name}
    */
    readonly name: string;
    /**
    * The number identifying the port where each target listens for traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#target_port ApplicationLoadBalancer#target_port}
    */
    readonly targetPort: number;
    /**
    * List of all targets which will be used in the pool. Limited to 250.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#targets ApplicationLoadBalancer#targets}
    */
    readonly targets: ApplicationLoadBalancerTargetPoolsTargets[] | cdktf.IResolvable;
    /**
    * Configuration for TLS bridging.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#tls_config ApplicationLoadBalancer#tls_config}
    */
    readonly tlsConfig?: ApplicationLoadBalancerTargetPoolsTlsConfig;
}
export declare function applicationLoadBalancerTargetPoolsToTerraform(struct?: ApplicationLoadBalancerTargetPools | cdktf.IResolvable): any;
export declare function applicationLoadBalancerTargetPoolsToHclTerraform(struct?: ApplicationLoadBalancerTargetPools | cdktf.IResolvable): any;
export declare class ApplicationLoadBalancerTargetPoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationLoadBalancerTargetPools | cdktf.IResolvable | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetPools | cdktf.IResolvable | undefined);
    private _activeHealthCheck;
    get activeHealthCheck(): ApplicationLoadBalancerTargetPoolsActiveHealthCheckOutputReference;
    putActiveHealthCheck(value: ApplicationLoadBalancerTargetPoolsActiveHealthCheck): void;
    resetActiveHealthCheck(): void;
    get activeHealthCheckInput(): cdktf.IResolvable | ApplicationLoadBalancerTargetPoolsActiveHealthCheck | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _targetPort?;
    get targetPort(): number;
    set targetPort(value: number);
    get targetPortInput(): number | undefined;
    private _targets;
    get targets(): ApplicationLoadBalancerTargetPoolsTargetsList;
    putTargets(value: ApplicationLoadBalancerTargetPoolsTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | ApplicationLoadBalancerTargetPoolsTargets[] | undefined;
    private _tlsConfig;
    get tlsConfig(): ApplicationLoadBalancerTargetPoolsTlsConfigOutputReference;
    putTlsConfig(value: ApplicationLoadBalancerTargetPoolsTlsConfig): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): cdktf.IResolvable | ApplicationLoadBalancerTargetPoolsTlsConfig | undefined;
}
export declare class ApplicationLoadBalancerTargetPoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ApplicationLoadBalancerTargetPools[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationLoadBalancerTargetPoolsOutputReference;
}
export interface ApplicationLoadBalancerTargetSecurityGroup {
}
export declare function applicationLoadBalancerTargetSecurityGroupToTerraform(struct?: ApplicationLoadBalancerTargetSecurityGroup): any;
export declare function applicationLoadBalancerTargetSecurityGroupToHclTerraform(struct?: ApplicationLoadBalancerTargetSecurityGroup): any;
export declare class ApplicationLoadBalancerTargetSecurityGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationLoadBalancerTargetSecurityGroup | undefined;
    set internalValue(value: ApplicationLoadBalancerTargetSecurityGroup | undefined);
    get id(): string;
    get name(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer stackit_application_load_balancer}
*/
export declare class ApplicationLoadBalancer extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_application_load_balancer";
    /**
    * Generates CDKTF code for importing a ApplicationLoadBalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationLoadBalancer to import
    * @param importFromId The id of the existing ApplicationLoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationLoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/resources/application_load_balancer stackit_application_load_balancer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationLoadBalancerConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationLoadBalancerConfig);
    private _disableTargetSecurityGroupAssignment?;
    get disableTargetSecurityGroupAssignment(): boolean | cdktf.IResolvable;
    set disableTargetSecurityGroupAssignment(value: boolean | cdktf.IResolvable);
    resetDisableTargetSecurityGroupAssignment(): void;
    get disableTargetSecurityGroupAssignmentInput(): boolean | cdktf.IResolvable | undefined;
    private _errors;
    get errors(): ApplicationLoadBalancerErrorsList;
    private _externalAddress?;
    get externalAddress(): string;
    set externalAddress(value: string);
    resetExternalAddress(): void;
    get externalAddressInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _listeners;
    get listeners(): ApplicationLoadBalancerListenersList;
    putListeners(value: ApplicationLoadBalancerListeners[] | cdktf.IResolvable): void;
    get listenersInput(): cdktf.IResolvable | ApplicationLoadBalancerListeners[] | undefined;
    private _loadBalancerSecurityGroup;
    get loadBalancerSecurityGroup(): ApplicationLoadBalancerLoadBalancerSecurityGroupOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networks;
    get networks(): ApplicationLoadBalancerNetworksList;
    putNetworks(value: ApplicationLoadBalancerNetworks[] | cdktf.IResolvable): void;
    get networksInput(): cdktf.IResolvable | ApplicationLoadBalancerNetworks[] | undefined;
    private _options;
    get options(): ApplicationLoadBalancerOptionsOutputReference;
    putOptions(value: ApplicationLoadBalancerOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktf.IResolvable | ApplicationLoadBalancerOptions | undefined;
    private _planId?;
    get planId(): string;
    set planId(value: string);
    get planIdInput(): string | undefined;
    get privateAddress(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _targetPools;
    get targetPools(): ApplicationLoadBalancerTargetPoolsList;
    putTargetPools(value: ApplicationLoadBalancerTargetPools[] | cdktf.IResolvable): void;
    get targetPoolsInput(): cdktf.IResolvable | ApplicationLoadBalancerTargetPools[] | undefined;
    private _targetSecurityGroup;
    get targetSecurityGroup(): ApplicationLoadBalancerTargetSecurityGroupOutputReference;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
