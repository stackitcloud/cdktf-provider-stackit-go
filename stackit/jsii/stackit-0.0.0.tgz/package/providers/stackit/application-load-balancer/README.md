# `stackit_application_load_balancer`

Refer to the Terraform Registry for docs: [`stackit_application_load_balancer`](https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/application_load_balancer).
