# `stackit_application_load_balancer`

Refer to the Terraform Registry for docs: [`stackit_application_load_balancer`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/application_load_balancer).
