# `stackit_objectstorage_default_retention`

Refer to the Terraform Registry for docs: [`stackit_objectstorage_default_retention`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/objectstorage_default_retention).
