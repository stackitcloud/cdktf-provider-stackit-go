import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServerUpdateSchedulesConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID (UUID) to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules#project_id DataStackitServerUpdateSchedules#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules#region DataStackitServerUpdateSchedules#region}
    */
    readonly region?: string;
    /**
    * Server ID (UUID) to which the update schedule is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules#server_id DataStackitServerUpdateSchedules#server_id}
    */
    readonly serverId: string;
}
export interface DataStackitServerUpdateSchedulesItems {
}
export declare function dataStackitServerUpdateSchedulesItemsToTerraform(struct?: DataStackitServerUpdateSchedulesItems): any;
export declare function dataStackitServerUpdateSchedulesItemsToHclTerraform(struct?: DataStackitServerUpdateSchedulesItems): any;
export declare class DataStackitServerUpdateSchedulesItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitServerUpdateSchedulesItems | undefined;
    set internalValue(value: DataStackitServerUpdateSchedulesItems | undefined);
    get enabled(): cdktf.IResolvable;
    get maintenanceWindow(): number;
    get name(): string;
    get rrule(): string;
    get updateScheduleId(): number;
}
export declare class DataStackitServerUpdateSchedulesItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitServerUpdateSchedulesItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules stackit_server_update_schedules}
*/
export declare class DataStackitServerUpdateSchedules extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_server_update_schedules";
    /**
    * Generates CDKTF code for importing a DataStackitServerUpdateSchedules resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServerUpdateSchedules to import
    * @param importFromId The id of the existing DataStackitServerUpdateSchedules that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServerUpdateSchedules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_update_schedules stackit_server_update_schedules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServerUpdateSchedulesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServerUpdateSchedulesConfig);
    get id(): string;
    private _items;
    get items(): DataStackitServerUpdateSchedulesItemsList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
