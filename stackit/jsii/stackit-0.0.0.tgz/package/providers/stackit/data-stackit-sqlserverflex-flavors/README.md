# `data_stackit_sqlserverflex_flavors`

Refer to the Terraform Registry for docs: [`data_stackit_sqlserverflex_flavors`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/data-sources/sqlserverflex_flavors).
