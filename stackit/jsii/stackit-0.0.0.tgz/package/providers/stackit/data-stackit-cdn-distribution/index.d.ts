import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitCdnDistributionConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution#distribution_id DataStackitCdnDistribution#distribution_id}
    */
    readonly distributionId: string;
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution#project_id DataStackitCdnDistribution#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitCdnDistributionConfigBackend {
}
export declare function dataStackitCdnDistributionConfigBackendToTerraform(struct?: DataStackitCdnDistributionConfigBackend): any;
export declare function dataStackitCdnDistributionConfigBackendToHclTerraform(struct?: DataStackitCdnDistributionConfigBackend): any;
export declare class DataStackitCdnDistributionConfigBackendOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitCdnDistributionConfigBackend | undefined;
    set internalValue(value: DataStackitCdnDistributionConfigBackend | undefined);
    get bucketUrl(): string;
    private _geofencing;
    get geofencing(): cdktf.StringListMap;
    private _originRequestHeaders;
    get originRequestHeaders(): cdktf.StringMap;
    get originUrl(): string;
    get region(): string;
    get type(): string;
}
export interface DataStackitCdnDistributionConfigOptimizer {
}
export declare function dataStackitCdnDistributionConfigOptimizerToTerraform(struct?: DataStackitCdnDistributionConfigOptimizer): any;
export declare function dataStackitCdnDistributionConfigOptimizerToHclTerraform(struct?: DataStackitCdnDistributionConfigOptimizer): any;
export declare class DataStackitCdnDistributionConfigOptimizerOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitCdnDistributionConfigOptimizer | undefined;
    set internalValue(value: DataStackitCdnDistributionConfigOptimizer | undefined);
    get enabled(): cdktf.IResolvable;
}
export interface DataStackitCdnDistributionConfigA {
    /**
    * The configured countries where distribution of content is blocked
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution#blocked_countries DataStackitCdnDistribution#blocked_countries}
    */
    readonly blockedCountries?: string[];
}
export declare function dataStackitCdnDistributionConfigAToTerraform(struct?: DataStackitCdnDistributionConfigA): any;
export declare function dataStackitCdnDistributionConfigAToHclTerraform(struct?: DataStackitCdnDistributionConfigA): any;
export declare class DataStackitCdnDistributionConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitCdnDistributionConfigA | undefined;
    set internalValue(value: DataStackitCdnDistributionConfigA | undefined);
    private _backend;
    get backend(): DataStackitCdnDistributionConfigBackendOutputReference;
    private _blockedCountries?;
    get blockedCountries(): string[];
    set blockedCountries(value: string[]);
    resetBlockedCountries(): void;
    get blockedCountriesInput(): string[] | undefined;
    private _optimizer;
    get optimizer(): DataStackitCdnDistributionConfigOptimizerOutputReference;
    get regions(): string[];
}
export interface DataStackitCdnDistributionDomains {
}
export declare function dataStackitCdnDistributionDomainsToTerraform(struct?: DataStackitCdnDistributionDomains): any;
export declare function dataStackitCdnDistributionDomainsToHclTerraform(struct?: DataStackitCdnDistributionDomains): any;
export declare class DataStackitCdnDistributionDomainsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitCdnDistributionDomains | undefined;
    set internalValue(value: DataStackitCdnDistributionDomains | undefined);
    get errors(): string[];
    get name(): string;
    get status(): string;
    get type(): string;
}
export declare class DataStackitCdnDistributionDomainsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitCdnDistributionDomainsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution stackit_cdn_distribution}
*/
export declare class DataStackitCdnDistribution extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_cdn_distribution";
    /**
    * Generates CDKTF code for importing a DataStackitCdnDistribution resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitCdnDistribution to import
    * @param importFromId The id of the existing DataStackitCdnDistribution that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitCdnDistribution to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/cdn_distribution stackit_cdn_distribution} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitCdnDistributionConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitCdnDistributionConfig);
    private _config;
    get config(): DataStackitCdnDistributionConfigAOutputReference;
    get createdAt(): string;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    private _domains;
    get domains(): DataStackitCdnDistributionDomainsList;
    get errors(): string[];
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
