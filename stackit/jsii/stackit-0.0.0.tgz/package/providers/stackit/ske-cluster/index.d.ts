import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SkeClusterConfig extends cdktf.TerraformMetaArguments {
    /**
    * A single extensions block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#extensions SkeCluster#extensions}
    */
    readonly extensions?: SkeClusterExtensions;
    /**
    * One or more hibernation block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#hibernations SkeCluster#hibernations}
    */
    readonly hibernations?: SkeClusterHibernations[] | cdktf.IResolvable;
    /**
    * The minimum Kubernetes version. This field will be used to set the minimum kubernetes version on creation/update of the cluster. If unset, the latest supported Kubernetes version will be used. SKE automatically updates the cluster Kubernetes version if you have set `maintenance.enable_kubernetes_version_updates` to true or if there is a mandatory update, as described in [General information for Kubernetes & OS updates](https://docs.stackit.cloud/products/runtime/kubernetes-engine/basics/version-updates/). To get the current kubernetes version being used for your cluster, use the read-only `kubernetes_version_used` field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#kubernetes_version_min SkeCluster#kubernetes_version_min}
    */
    readonly kubernetesVersionMin?: string;
    /**
    * A single maintenance block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#maintenance SkeCluster#maintenance}
    */
    readonly maintenance?: SkeClusterMaintenance;
    /**
    * The cluster name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#name SkeCluster#name}
    */
    readonly name: string;
    /**
    * Network block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#network SkeCluster#network}
    */
    readonly network?: SkeClusterNetwork;
    /**
    * One or more `node_pool` block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#node_pools SkeCluster#node_pools}
    */
    readonly nodePools: SkeClusterNodePools[] | cdktf.IResolvable;
    /**
    * STACKIT project ID to which the cluster is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#project_id SkeCluster#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#region SkeCluster#region}
    */
    readonly region?: string;
}
export interface SkeClusterExtensionsAcl {
    /**
    * Specify a list of CIDRs to whitelist.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#allowed_cidrs SkeCluster#allowed_cidrs}
    */
    readonly allowedCidrs: string[];
    /**
    * Is ACL enabled?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enabled SkeCluster#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
}
export declare function skeClusterExtensionsAclToTerraform(struct?: SkeClusterExtensionsAcl | cdktf.IResolvable): any;
export declare function skeClusterExtensionsAclToHclTerraform(struct?: SkeClusterExtensionsAcl | cdktf.IResolvable): any;
export declare class SkeClusterExtensionsAclOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterExtensionsAcl | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterExtensionsAcl | cdktf.IResolvable | undefined);
    private _allowedCidrs?;
    get allowedCidrs(): string[];
    set allowedCidrs(value: string[]);
    get allowedCidrsInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface SkeClusterExtensionsArgus {
    /**
    * Argus instance ID to choose which Argus instance is used. Required when enabled is set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#argus_instance_id SkeCluster#argus_instance_id}
    */
    readonly argusInstanceId?: string;
    /**
    * Flag to enable/disable Argus extensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enabled SkeCluster#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
}
export declare function skeClusterExtensionsArgusToTerraform(struct?: SkeClusterExtensionsArgus | cdktf.IResolvable): any;
export declare function skeClusterExtensionsArgusToHclTerraform(struct?: SkeClusterExtensionsArgus | cdktf.IResolvable): any;
export declare class SkeClusterExtensionsArgusOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterExtensionsArgus | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterExtensionsArgus | cdktf.IResolvable | undefined);
    private _argusInstanceId?;
    get argusInstanceId(): string;
    set argusInstanceId(value: string);
    resetArgusInstanceId(): void;
    get argusInstanceIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
}
export interface SkeClusterExtensionsDns {
    /**
    * Flag to enable/disable DNS extensions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enabled SkeCluster#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Specify a list of domain filters for externalDNS (e.g., `foo.runs.onstackit.cloud`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#zones SkeCluster#zones}
    */
    readonly zones?: string[];
}
export declare function skeClusterExtensionsDnsToTerraform(struct?: SkeClusterExtensionsDns | cdktf.IResolvable): any;
export declare function skeClusterExtensionsDnsToHclTerraform(struct?: SkeClusterExtensionsDns | cdktf.IResolvable): any;
export declare class SkeClusterExtensionsDnsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterExtensionsDns | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterExtensionsDns | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    resetZones(): void;
    get zonesInput(): string[] | undefined;
}
export interface SkeClusterExtensionsObservability {
    /**
    * Flag to enable/disable Observability extensions.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enabled SkeCluster#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Observability instance ID to choose which Observability instance is used. Required when enabled is set to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#instance_id SkeCluster#instance_id}
    */
    readonly instanceId?: string;
}
export declare function skeClusterExtensionsObservabilityToTerraform(struct?: SkeClusterExtensionsObservability | cdktf.IResolvable): any;
export declare function skeClusterExtensionsObservabilityToHclTerraform(struct?: SkeClusterExtensionsObservability | cdktf.IResolvable): any;
export declare class SkeClusterExtensionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterExtensionsObservability | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterExtensionsObservability | cdktf.IResolvable | undefined);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
}
export interface SkeClusterExtensions {
    /**
    * Cluster access control configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#acl SkeCluster#acl}
    */
    readonly acl?: SkeClusterExtensionsAcl;
    /**
    * A single argus block as defined below. This field is deprecated and will be removed 06 January 2026.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#argus SkeCluster#argus}
    */
    readonly argus?: SkeClusterExtensionsArgus;
    /**
    * DNS extension configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#dns SkeCluster#dns}
    */
    readonly dns?: SkeClusterExtensionsDns;
    /**
    * A single observability block as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#observability SkeCluster#observability}
    */
    readonly observability?: SkeClusterExtensionsObservability;
}
export declare function skeClusterExtensionsToTerraform(struct?: SkeClusterExtensions | cdktf.IResolvable): any;
export declare function skeClusterExtensionsToHclTerraform(struct?: SkeClusterExtensions | cdktf.IResolvable): any;
export declare class SkeClusterExtensionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterExtensions | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterExtensions | cdktf.IResolvable | undefined);
    private _acl;
    get acl(): SkeClusterExtensionsAclOutputReference;
    putAcl(value: SkeClusterExtensionsAcl): void;
    resetAcl(): void;
    get aclInput(): cdktf.IResolvable | SkeClusterExtensionsAcl | undefined;
    private _argus;
    get argus(): SkeClusterExtensionsArgusOutputReference;
    putArgus(value: SkeClusterExtensionsArgus): void;
    resetArgus(): void;
    get argusInput(): cdktf.IResolvable | SkeClusterExtensionsArgus | undefined;
    private _dns;
    get dns(): SkeClusterExtensionsDnsOutputReference;
    putDns(value: SkeClusterExtensionsDns): void;
    resetDns(): void;
    get dnsInput(): cdktf.IResolvable | SkeClusterExtensionsDns | undefined;
    private _observability;
    get observability(): SkeClusterExtensionsObservabilityOutputReference;
    putObservability(value: SkeClusterExtensionsObservability): void;
    resetObservability(): void;
    get observabilityInput(): cdktf.IResolvable | SkeClusterExtensionsObservability | undefined;
}
export interface SkeClusterHibernations {
    /**
    * End time of hibernation in crontab syntax. E.g. `0 8 * * *` for waking up the cluster at 8am.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#end SkeCluster#end}
    */
    readonly end: string;
    /**
    * Start time of cluster hibernation in crontab syntax. E.g. `0 18 * * *` for starting everyday at 6pm.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#start SkeCluster#start}
    */
    readonly start: string;
    /**
    * Timezone name corresponding to a file in the IANA Time Zone database. i.e. `Europe/Berlin`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#timezone SkeCluster#timezone}
    */
    readonly timezone?: string;
}
export declare function skeClusterHibernationsToTerraform(struct?: SkeClusterHibernations | cdktf.IResolvable): any;
export declare function skeClusterHibernationsToHclTerraform(struct?: SkeClusterHibernations | cdktf.IResolvable): any;
export declare class SkeClusterHibernationsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SkeClusterHibernations | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterHibernations | cdktf.IResolvable | undefined);
    private _end?;
    get end(): string;
    set end(value: string);
    get endInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    get startInput(): string | undefined;
    private _timezone?;
    get timezone(): string;
    set timezone(value: string);
    resetTimezone(): void;
    get timezoneInput(): string | undefined;
}
export declare class SkeClusterHibernationsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SkeClusterHibernations[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SkeClusterHibernationsOutputReference;
}
export interface SkeClusterMaintenance {
    /**
    * Flag to enable/disable auto-updates of the Kubernetes version. Defaults to `true`. SKE automatically updates the cluster Kubernetes version if you have set `maintenance.enable_kubernetes_version_updates` to true or if there is a mandatory update, as described in [General information for Kubernetes & OS updates](https://docs.stackit.cloud/products/runtime/kubernetes-engine/basics/version-updates/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enable_kubernetes_version_updates SkeCluster#enable_kubernetes_version_updates}
    */
    readonly enableKubernetesVersionUpdates?: boolean | cdktf.IResolvable;
    /**
    * Flag to enable/disable auto-updates of the OS image version. Defaults to `true`. SKE automatically updates the cluster Kubernetes version if you have set `maintenance.enable_kubernetes_version_updates` to true or if there is a mandatory update, as described in [General information for Kubernetes & OS updates](https://docs.stackit.cloud/products/runtime/kubernetes-engine/basics/version-updates/).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#enable_machine_image_version_updates SkeCluster#enable_machine_image_version_updates}
    */
    readonly enableMachineImageVersionUpdates?: boolean | cdktf.IResolvable;
    /**
    * Time for maintenance window end. E.g. `01:23:45Z`, `05:00:00+02:00`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#end SkeCluster#end}
    */
    readonly end: string;
    /**
    * Time for maintenance window start. E.g. `01:23:45Z`, `05:00:00+02:00`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#start SkeCluster#start}
    */
    readonly start: string;
}
export declare function skeClusterMaintenanceToTerraform(struct?: SkeClusterMaintenance | cdktf.IResolvable): any;
export declare function skeClusterMaintenanceToHclTerraform(struct?: SkeClusterMaintenance | cdktf.IResolvable): any;
export declare class SkeClusterMaintenanceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterMaintenance | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterMaintenance | cdktf.IResolvable | undefined);
    private _enableKubernetesVersionUpdates?;
    get enableKubernetesVersionUpdates(): boolean | cdktf.IResolvable;
    set enableKubernetesVersionUpdates(value: boolean | cdktf.IResolvable);
    resetEnableKubernetesVersionUpdates(): void;
    get enableKubernetesVersionUpdatesInput(): boolean | cdktf.IResolvable | undefined;
    private _enableMachineImageVersionUpdates?;
    get enableMachineImageVersionUpdates(): boolean | cdktf.IResolvable;
    set enableMachineImageVersionUpdates(value: boolean | cdktf.IResolvable);
    resetEnableMachineImageVersionUpdates(): void;
    get enableMachineImageVersionUpdatesInput(): boolean | cdktf.IResolvable | undefined;
    private _end?;
    get end(): string;
    set end(value: string);
    get endInput(): string | undefined;
    private _start?;
    get start(): string;
    set start(value: string);
    get startInput(): string | undefined;
}
export interface SkeClusterNetwork {
    /**
    * ID of the STACKIT Network Area (SNA) network into which the cluster will be deployed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#id SkeCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export declare function skeClusterNetworkToTerraform(struct?: SkeClusterNetwork | cdktf.IResolvable): any;
export declare function skeClusterNetworkToHclTerraform(struct?: SkeClusterNetwork | cdktf.IResolvable): any;
export declare class SkeClusterNetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SkeClusterNetwork | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterNetwork | cdktf.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
}
export interface SkeClusterNodePoolsTaints {
    /**
    * The taint effect. E.g `PreferNoSchedule`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#effect SkeCluster#effect}
    */
    readonly effect: string;
    /**
    * Taint key to be applied to a node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#key SkeCluster#key}
    */
    readonly key: string;
    /**
    * Taint value corresponding to the taint key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#value SkeCluster#value}
    */
    readonly value?: string;
}
export declare function skeClusterNodePoolsTaintsToTerraform(struct?: SkeClusterNodePoolsTaints | cdktf.IResolvable): any;
export declare function skeClusterNodePoolsTaintsToHclTerraform(struct?: SkeClusterNodePoolsTaints | cdktf.IResolvable): any;
export declare class SkeClusterNodePoolsTaintsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SkeClusterNodePoolsTaints | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterNodePoolsTaints | cdktf.IResolvable | undefined);
    private _effect?;
    get effect(): string;
    set effect(value: string);
    get effectInput(): string | undefined;
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class SkeClusterNodePoolsTaintsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SkeClusterNodePoolsTaints[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SkeClusterNodePoolsTaintsOutputReference;
}
export interface SkeClusterNodePools {
    /**
    * Allow system components to run on this node pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#allow_system_components SkeCluster#allow_system_components}
    */
    readonly allowSystemComponents?: boolean | cdktf.IResolvable;
    /**
    * Specify a list of availability zones. E.g. `eu01-m`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#availability_zones SkeCluster#availability_zones}
    */
    readonly availabilityZones: string[];
    /**
    * Specifies the container runtime. Defaults to `containerd`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#cri SkeCluster#cri}
    */
    readonly cri?: string;
    /**
    * Labels to add to each node.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#labels SkeCluster#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The machine type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#machine_type SkeCluster#machine_type}
    */
    readonly machineType: string;
    /**
    * Maximum number of additional VMs that are created during an update. If set (larger than 0), then it must be at least the amount of zones configured for the nodepool. The `max_surge` and `max_unavailable` fields cannot both be unset at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#max_surge SkeCluster#max_surge}
    */
    readonly maxSurge?: number;
    /**
    * Maximum number of VMs that that can be unavailable during an update. If set (larger than 0), then it must be at least the amount of zones configured for the nodepool. The `max_surge` and `max_unavailable` fields cannot both be unset at the same time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#max_unavailable SkeCluster#max_unavailable}
    */
    readonly maxUnavailable?: number;
    /**
    * Maximum number of nodes in the pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#maximum SkeCluster#maximum}
    */
    readonly maximum: number;
    /**
    * Minimum number of nodes in the pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#minimum SkeCluster#minimum}
    */
    readonly minimum: number;
    /**
    * Specifies the name of the node pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#name SkeCluster#name}
    */
    readonly name: string;
    /**
    * The name of the OS image. Defaults to `flatcar`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#os_name SkeCluster#os_name}
    */
    readonly osName?: string;
    /**
    * This field is deprecated, use `os_version_min` to configure the version and `os_version_used` to get the currently used version instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#os_version SkeCluster#os_version}
    */
    readonly osVersion?: string;
    /**
    * The minimum OS image version. This field will be used to set the minimum OS image version on creation/update of the cluster. If unset, the latest supported OS image version will be used. SKE automatically updates the cluster Kubernetes version if you have set `maintenance.enable_kubernetes_version_updates` to true or if there is a mandatory update, as described in [General information for Kubernetes & OS updates](https://docs.stackit.cloud/products/runtime/kubernetes-engine/basics/version-updates/). To get the current OS image version being used for the node pool, use the read-only `os_version_used` field.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#os_version_min SkeCluster#os_version_min}
    */
    readonly osVersionMin?: string;
    /**
    * Specifies a taint list as defined below.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#taints SkeCluster#taints}
    */
    readonly taints?: SkeClusterNodePoolsTaints[] | cdktf.IResolvable;
    /**
    * The volume size in GB. Defaults to `20`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#volume_size SkeCluster#volume_size}
    */
    readonly volumeSize?: number;
    /**
    * Specifies the volume type. Defaults to `storage_premium_perf1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#volume_type SkeCluster#volume_type}
    */
    readonly volumeType?: string;
}
export declare function skeClusterNodePoolsToTerraform(struct?: SkeClusterNodePools | cdktf.IResolvable): any;
export declare function skeClusterNodePoolsToHclTerraform(struct?: SkeClusterNodePools | cdktf.IResolvable): any;
export declare class SkeClusterNodePoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SkeClusterNodePools | cdktf.IResolvable | undefined;
    set internalValue(value: SkeClusterNodePools | cdktf.IResolvable | undefined);
    private _allowSystemComponents?;
    get allowSystemComponents(): boolean | cdktf.IResolvable;
    set allowSystemComponents(value: boolean | cdktf.IResolvable);
    resetAllowSystemComponents(): void;
    get allowSystemComponentsInput(): boolean | cdktf.IResolvable | undefined;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    get availabilityZonesInput(): string[] | undefined;
    private _cri?;
    get cri(): string;
    set cri(value: string);
    resetCri(): void;
    get criInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    get machineTypeInput(): string | undefined;
    private _maxSurge?;
    get maxSurge(): number;
    set maxSurge(value: number);
    resetMaxSurge(): void;
    get maxSurgeInput(): number | undefined;
    private _maxUnavailable?;
    get maxUnavailable(): number;
    set maxUnavailable(value: number);
    resetMaxUnavailable(): void;
    get maxUnavailableInput(): number | undefined;
    private _maximum?;
    get maximum(): number;
    set maximum(value: number);
    get maximumInput(): number | undefined;
    private _minimum?;
    get minimum(): number;
    set minimum(value: number);
    get minimumInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _osName?;
    get osName(): string;
    set osName(value: string);
    resetOsName(): void;
    get osNameInput(): string | undefined;
    private _osVersion?;
    get osVersion(): string;
    set osVersion(value: string);
    resetOsVersion(): void;
    get osVersionInput(): string | undefined;
    private _osVersionMin?;
    get osVersionMin(): string;
    set osVersionMin(value: string);
    resetOsVersionMin(): void;
    get osVersionMinInput(): string | undefined;
    get osVersionUsed(): string;
    private _taints;
    get taints(): SkeClusterNodePoolsTaintsList;
    putTaints(value: SkeClusterNodePoolsTaints[] | cdktf.IResolvable): void;
    resetTaints(): void;
    get taintsInput(): cdktf.IResolvable | SkeClusterNodePoolsTaints[] | undefined;
    private _volumeSize?;
    get volumeSize(): number;
    set volumeSize(value: number);
    resetVolumeSize(): void;
    get volumeSizeInput(): number | undefined;
    private _volumeType?;
    get volumeType(): string;
    set volumeType(value: string);
    resetVolumeType(): void;
    get volumeTypeInput(): string | undefined;
}
export declare class SkeClusterNodePoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SkeClusterNodePools[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SkeClusterNodePoolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster stackit_ske_cluster}
*/
export declare class SkeCluster extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_ske_cluster";
    /**
    * Generates CDKTF code for importing a SkeCluster resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SkeCluster to import
    * @param importFromId The id of the existing SkeCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SkeCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_cluster stackit_ske_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SkeClusterConfig
    */
    constructor(scope: Construct, id: string, config: SkeClusterConfig);
    get egressAddressRanges(): string[];
    private _extensions;
    get extensions(): SkeClusterExtensionsOutputReference;
    putExtensions(value: SkeClusterExtensions): void;
    resetExtensions(): void;
    get extensionsInput(): cdktf.IResolvable | SkeClusterExtensions | undefined;
    private _hibernations;
    get hibernations(): SkeClusterHibernationsList;
    putHibernations(value: SkeClusterHibernations[] | cdktf.IResolvable): void;
    resetHibernations(): void;
    get hibernationsInput(): cdktf.IResolvable | SkeClusterHibernations[] | undefined;
    get id(): string;
    private _kubernetesVersionMin?;
    get kubernetesVersionMin(): string;
    set kubernetesVersionMin(value: string);
    resetKubernetesVersionMin(): void;
    get kubernetesVersionMinInput(): string | undefined;
    get kubernetesVersionUsed(): string;
    private _maintenance;
    get maintenance(): SkeClusterMaintenanceOutputReference;
    putMaintenance(value: SkeClusterMaintenance): void;
    resetMaintenance(): void;
    get maintenanceInput(): cdktf.IResolvable | SkeClusterMaintenance | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _network;
    get network(): SkeClusterNetworkOutputReference;
    putNetwork(value: SkeClusterNetwork): void;
    resetNetwork(): void;
    get networkInput(): cdktf.IResolvable | SkeClusterNetwork | undefined;
    private _nodePools;
    get nodePools(): SkeClusterNodePoolsList;
    putNodePools(value: SkeClusterNodePools[] | cdktf.IResolvable): void;
    get nodePoolsInput(): cdktf.IResolvable | SkeClusterNodePools[] | undefined;
    get podAddressRanges(): string[];
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
