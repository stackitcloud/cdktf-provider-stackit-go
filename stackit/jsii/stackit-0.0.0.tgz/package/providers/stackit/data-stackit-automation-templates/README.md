# `data_stackit_automation_templates`

Refer to the Terraform Registry for docs: [`data_stackit_automation_templates`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/automation_templates).
