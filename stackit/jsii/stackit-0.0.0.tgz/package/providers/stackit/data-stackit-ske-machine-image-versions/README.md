# `data_stackit_ske_machine_image_versions`

Refer to the Terraform Registry for docs: [`data_stackit_ske_machine_image_versions`](https://registry.terraform.io/providers/stackitcloud/stackit/0.118.0/docs/data-sources/ske_machine_image_versions).
