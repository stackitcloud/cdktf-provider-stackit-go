import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSkeMachineImageVersionsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Region override. If omitted, the provider’s region will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/data-sources/ske_machine_image_versions#region DataStackitSkeMachineImageVersions#region}
    */
    readonly region?: string;
    /**
    * Filter returned machine image versions by their state. Possible values are: `SUPPORTED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/data-sources/ske_machine_image_versions#version_state DataStackitSkeMachineImageVersions#version_state}
    */
    readonly versionState?: string;
}
export interface DataStackitSkeMachineImageVersionsMachineImagesVersions {
}
export declare function dataStackitSkeMachineImageVersionsMachineImagesVersionsToTerraform(struct?: DataStackitSkeMachineImageVersionsMachineImagesVersions): any;
export declare function dataStackitSkeMachineImageVersionsMachineImagesVersionsToHclTerraform(struct?: DataStackitSkeMachineImageVersionsMachineImagesVersions): any;
export declare class DataStackitSkeMachineImageVersionsMachineImagesVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeMachineImageVersionsMachineImagesVersions | undefined;
    set internalValue(value: DataStackitSkeMachineImageVersionsMachineImagesVersions | undefined);
    get cri(): string[];
    get expirationDate(): string;
    get state(): string;
    get version(): string;
}
export declare class DataStackitSkeMachineImageVersionsMachineImagesVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeMachineImageVersionsMachineImagesVersionsOutputReference;
}
export interface DataStackitSkeMachineImageVersionsMachineImages {
}
export declare function dataStackitSkeMachineImageVersionsMachineImagesToTerraform(struct?: DataStackitSkeMachineImageVersionsMachineImages): any;
export declare function dataStackitSkeMachineImageVersionsMachineImagesToHclTerraform(struct?: DataStackitSkeMachineImageVersionsMachineImages): any;
export declare class DataStackitSkeMachineImageVersionsMachineImagesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeMachineImageVersionsMachineImages | undefined;
    set internalValue(value: DataStackitSkeMachineImageVersionsMachineImages | undefined);
    get name(): string;
    private _versions;
    get versions(): DataStackitSkeMachineImageVersionsMachineImagesVersionsList;
}
export declare class DataStackitSkeMachineImageVersionsMachineImagesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeMachineImageVersionsMachineImagesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/data-sources/ske_machine_image_versions stackit_ske_machine_image_versions}
*/
export declare class DataStackitSkeMachineImageVersions extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_ske_machine_image_versions";
    /**
    * Generates CDKTF code for importing a DataStackitSkeMachineImageVersions resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSkeMachineImageVersions to import
    * @param importFromId The id of the existing DataStackitSkeMachineImageVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/data-sources/ske_machine_image_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSkeMachineImageVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/data-sources/ske_machine_image_versions stackit_ske_machine_image_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSkeMachineImageVersionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataStackitSkeMachineImageVersionsConfig);
    private _machineImages;
    get machineImages(): DataStackitSkeMachineImageVersionsMachineImagesList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _versionState?;
    get versionState(): string;
    set versionState(value: string);
    resetVersionState(): void;
    get versionStateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
