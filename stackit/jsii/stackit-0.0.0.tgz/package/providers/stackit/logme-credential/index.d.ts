import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LogmeCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the LogMe instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/logme_credential#instance_id LogmeCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/logme_credential#project_id LogmeCredential#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/logme_credential stackit_logme_credential}
*/
export declare class LogmeCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_logme_credential";
    /**
    * Generates CDKTF code for importing a LogmeCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogmeCredential to import
    * @param importFromId The id of the existing LogmeCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/logme_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogmeCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/logme_credential stackit_logme_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogmeCredentialConfig
    */
    constructor(scope: Construct, id: string, config: LogmeCredentialConfig);
    get credentialId(): string;
    get host(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get uri(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
