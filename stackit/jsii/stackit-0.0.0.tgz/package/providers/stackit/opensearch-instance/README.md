# `stackit_opensearch_instance`

Refer to the Terraform Registry for docs: [`stackit_opensearch_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/opensearch_instance).
