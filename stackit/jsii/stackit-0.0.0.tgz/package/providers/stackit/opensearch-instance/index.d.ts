import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface OpensearchInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#name OpensearchInstance#name}
    */
    readonly name: string;
    /**
    * Configuration parameters. Please note that removing a previously configured field from your Terraform configuration won't replace its value in the API. To update a previously configured field, explicitly set a new value for it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#parameters OpensearchInstance#parameters}
    */
    readonly parameters?: OpensearchInstanceParameters;
    /**
    * The selected plan name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#plan_name OpensearchInstance#plan_name}
    */
    readonly planName: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#project_id OpensearchInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The service version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#version OpensearchInstance#version}
    */
    readonly version: string;
}
export interface OpensearchInstanceParameters {
    /**
    * Enable monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#enable_monitoring OpensearchInstance#enable_monitoring}
    */
    readonly enableMonitoring?: boolean | cdktf.IResolvable;
    /**
    * If set, monitoring with Graphite will be enabled. Expects the host and port where the Graphite metrics should be sent to (host:port).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#graphite OpensearchInstance#graphite}
    */
    readonly graphite?: string;
    /**
    * The garbage collector to use for OpenSearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#java_garbage_collector OpensearchInstance#java_garbage_collector}
    */
    readonly javaGarbageCollector?: string;
    /**
    * The amount of memory (in MB) allocated as heap by the JVM for OpenSearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#java_heapspace OpensearchInstance#java_heapspace}
    */
    readonly javaHeapspace?: number;
    /**
    * The amount of memory (in MB) used by the JVM to store metadata for OpenSearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#java_maxmetaspace OpensearchInstance#java_maxmetaspace}
    */
    readonly javaMaxmetaspace?: number;
    /**
    * The maximum disk threshold in MB. If the disk usage exceeds this threshold, the instance will be stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#max_disk_threshold OpensearchInstance#max_disk_threshold}
    */
    readonly maxDiskThreshold?: number;
    /**
    * The frequency in seconds at which metrics are emitted (in seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#metrics_frequency OpensearchInstance#metrics_frequency}
    */
    readonly metricsFrequency?: number;
    /**
    * The prefix for the metrics. Could be useful when using Graphite monitoring to prefix the metrics with a certain value, like an API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#metrics_prefix OpensearchInstance#metrics_prefix}
    */
    readonly metricsPrefix?: string;
    /**
    * The ID of the STACKIT monitoring instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#monitoring_instance_id OpensearchInstance#monitoring_instance_id}
    */
    readonly monitoringInstanceId?: string;
    /**
    * List of plugins to install. Must be a supported plugin name. The plugins `repository-s3` and `repository-azure` are enabled by default and cannot be disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#plugins OpensearchInstance#plugins}
    */
    readonly plugins?: string[];
    /**
    * Comma separated list of IP networks in CIDR notation which are allowed to access this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#sgw_acl OpensearchInstance#sgw_acl}
    */
    readonly sgwAcl?: string;
    /**
    * List of syslog servers to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#syslog OpensearchInstance#syslog}
    */
    readonly syslog?: string[];
    /**
    * List of TLS ciphers to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#tls_ciphers OpensearchInstance#tls_ciphers}
    */
    readonly tlsCiphers?: string[];
    /**
    * The TLS protocol to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#tls_protocols OpensearchInstance#tls_protocols}
    */
    readonly tlsProtocols?: string[];
}
export declare function opensearchInstanceParametersToTerraform(struct?: OpensearchInstanceParameters | cdktf.IResolvable): any;
export declare function opensearchInstanceParametersToHclTerraform(struct?: OpensearchInstanceParameters | cdktf.IResolvable): any;
export declare class OpensearchInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): OpensearchInstanceParameters | cdktf.IResolvable | undefined;
    set internalValue(value: OpensearchInstanceParameters | cdktf.IResolvable | undefined);
    private _enableMonitoring?;
    get enableMonitoring(): boolean | cdktf.IResolvable;
    set enableMonitoring(value: boolean | cdktf.IResolvable);
    resetEnableMonitoring(): void;
    get enableMonitoringInput(): boolean | cdktf.IResolvable | undefined;
    private _graphite?;
    get graphite(): string;
    set graphite(value: string);
    resetGraphite(): void;
    get graphiteInput(): string | undefined;
    private _javaGarbageCollector?;
    get javaGarbageCollector(): string;
    set javaGarbageCollector(value: string);
    resetJavaGarbageCollector(): void;
    get javaGarbageCollectorInput(): string | undefined;
    private _javaHeapspace?;
    get javaHeapspace(): number;
    set javaHeapspace(value: number);
    resetJavaHeapspace(): void;
    get javaHeapspaceInput(): number | undefined;
    private _javaMaxmetaspace?;
    get javaMaxmetaspace(): number;
    set javaMaxmetaspace(value: number);
    resetJavaMaxmetaspace(): void;
    get javaMaxmetaspaceInput(): number | undefined;
    private _maxDiskThreshold?;
    get maxDiskThreshold(): number;
    set maxDiskThreshold(value: number);
    resetMaxDiskThreshold(): void;
    get maxDiskThresholdInput(): number | undefined;
    private _metricsFrequency?;
    get metricsFrequency(): number;
    set metricsFrequency(value: number);
    resetMetricsFrequency(): void;
    get metricsFrequencyInput(): number | undefined;
    private _metricsPrefix?;
    get metricsPrefix(): string;
    set metricsPrefix(value: string);
    resetMetricsPrefix(): void;
    get metricsPrefixInput(): string | undefined;
    private _monitoringInstanceId?;
    get monitoringInstanceId(): string;
    set monitoringInstanceId(value: string);
    resetMonitoringInstanceId(): void;
    get monitoringInstanceIdInput(): string | undefined;
    private _plugins?;
    get plugins(): string[];
    set plugins(value: string[]);
    resetPlugins(): void;
    get pluginsInput(): string[] | undefined;
    private _sgwAcl?;
    get sgwAcl(): string;
    set sgwAcl(value: string);
    resetSgwAcl(): void;
    get sgwAclInput(): string | undefined;
    private _syslog?;
    get syslog(): string[];
    set syslog(value: string[]);
    resetSyslog(): void;
    get syslogInput(): string[] | undefined;
    private _tlsCiphers?;
    get tlsCiphers(): string[];
    set tlsCiphers(value: string[]);
    resetTlsCiphers(): void;
    get tlsCiphersInput(): string[] | undefined;
    private _tlsProtocols?;
    get tlsProtocols(): string[];
    set tlsProtocols(value: string[]);
    resetTlsProtocols(): void;
    get tlsProtocolsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance stackit_opensearch_instance}
*/
export declare class OpensearchInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_opensearch_instance";
    /**
    * Generates CDKTF code for importing a OpensearchInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OpensearchInstance to import
    * @param importFromId The id of the existing OpensearchInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OpensearchInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/opensearch_instance stackit_opensearch_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OpensearchInstanceConfig
    */
    constructor(scope: Construct, id: string, config: OpensearchInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): OpensearchInstanceParametersOutputReference;
    putParameters(value: OpensearchInstanceParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | OpensearchInstanceParameters | undefined;
    get planId(): string;
    private _planName?;
    get planName(): string;
    set planName(value: string);
    get planNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
