import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitCdnCustomDomainConfig extends cdktf.TerraformMetaArguments {
    /**
    * The TLS certificate for the custom domain. If omitted, a managed certificate will be used. If the block is specified, a custom certificate is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain#certificate DataStackitCdnCustomDomain#certificate}
    */
    readonly certificate?: DataStackitCdnCustomDomainCertificate;
    /**
    * CDN distribution ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain#distribution_id DataStackitCdnCustomDomain#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain#name DataStackitCdnCustomDomain#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain#project_id DataStackitCdnCustomDomain#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitCdnCustomDomainCertificate {
}
export declare function dataStackitCdnCustomDomainCertificateToTerraform(struct?: DataStackitCdnCustomDomainCertificate | cdktf.IResolvable): any;
export declare function dataStackitCdnCustomDomainCertificateToHclTerraform(struct?: DataStackitCdnCustomDomainCertificate | cdktf.IResolvable): any;
export declare class DataStackitCdnCustomDomainCertificateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitCdnCustomDomainCertificate | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitCdnCustomDomainCertificate | cdktf.IResolvable | undefined);
    get version(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain stackit_cdn_custom_domain}
*/
export declare class DataStackitCdnCustomDomain extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_cdn_custom_domain";
    /**
    * Generates CDKTF code for importing a DataStackitCdnCustomDomain resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitCdnCustomDomain to import
    * @param importFromId The id of the existing DataStackitCdnCustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitCdnCustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/cdn_custom_domain stackit_cdn_custom_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitCdnCustomDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitCdnCustomDomainConfig);
    private _certificate;
    get certificate(): DataStackitCdnCustomDomainCertificateOutputReference;
    putCertificate(value: DataStackitCdnCustomDomainCertificate): void;
    resetCertificate(): void;
    get certificateInput(): cdktf.IResolvable | DataStackitCdnCustomDomainCertificate | undefined;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    get errors(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
