# `data_stackit_cdn_custom_domain`

Refer to the Terraform Registry for docs: [`data_stackit_cdn_custom_domain`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/data-sources/cdn_custom_domain).
