import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitDremioInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description is a longer text chosen by the user to provide more context for the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#description DataStackitDremioInstance#description}
    */
    readonly description?: string;
    /**
    * The Dremio instance ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#instance_id DataStackitDremioInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the resource is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#project_id DataStackitDremioInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#region DataStackitDremioInstance#region}
    */
    readonly region?: string;
}
export interface DataStackitDremioInstanceAuthenticationAzuread {
}
export declare function dataStackitDremioInstanceAuthenticationAzureadToTerraform(struct?: DataStackitDremioInstanceAuthenticationAzuread | cdktf.IResolvable): any;
export declare function dataStackitDremioInstanceAuthenticationAzureadToHclTerraform(struct?: DataStackitDremioInstanceAuthenticationAzuread | cdktf.IResolvable): any;
export declare class DataStackitDremioInstanceAuthenticationAzureadOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDremioInstanceAuthenticationAzuread | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitDremioInstanceAuthenticationAzuread | cdktf.IResolvable | undefined);
    get authorityUrl(): string;
    get clientId(): string;
    get clientSecret(): string;
    get redirectUrl(): string;
}
export interface DataStackitDremioInstanceAuthenticationOauthJwtClaims {
}
export declare function dataStackitDremioInstanceAuthenticationOauthJwtClaimsToTerraform(struct?: DataStackitDremioInstanceAuthenticationOauthJwtClaims): any;
export declare function dataStackitDremioInstanceAuthenticationOauthJwtClaimsToHclTerraform(struct?: DataStackitDremioInstanceAuthenticationOauthJwtClaims): any;
export declare class DataStackitDremioInstanceAuthenticationOauthJwtClaimsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDremioInstanceAuthenticationOauthJwtClaims | undefined;
    set internalValue(value: DataStackitDremioInstanceAuthenticationOauthJwtClaims | undefined);
    get userName(): string;
}
export interface DataStackitDremioInstanceAuthenticationOauthParameters {
}
export declare function dataStackitDremioInstanceAuthenticationOauthParametersToTerraform(struct?: DataStackitDremioInstanceAuthenticationOauthParameters | cdktf.IResolvable): any;
export declare function dataStackitDremioInstanceAuthenticationOauthParametersToHclTerraform(struct?: DataStackitDremioInstanceAuthenticationOauthParameters | cdktf.IResolvable): any;
export declare class DataStackitDremioInstanceAuthenticationOauthParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitDremioInstanceAuthenticationOauthParameters | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitDremioInstanceAuthenticationOauthParameters | cdktf.IResolvable | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataStackitDremioInstanceAuthenticationOauthParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataStackitDremioInstanceAuthenticationOauthParameters[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitDremioInstanceAuthenticationOauthParametersOutputReference;
}
export interface DataStackitDremioInstanceAuthenticationOauth {
    /**
    * Any additional parameters the Identity Provider requires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#parameters DataStackitDremioInstance#parameters}
    */
    readonly parameters?: DataStackitDremioInstanceAuthenticationOauthParameters[] | cdktf.IResolvable;
    /**
    * A list of space-separated scopes. The `openid` scope is always required; other scopes can vary by provider.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#scope DataStackitDremioInstance#scope}
    */
    readonly scope?: string;
}
export declare function dataStackitDremioInstanceAuthenticationOauthToTerraform(struct?: DataStackitDremioInstanceAuthenticationOauth | cdktf.IResolvable): any;
export declare function dataStackitDremioInstanceAuthenticationOauthToHclTerraform(struct?: DataStackitDremioInstanceAuthenticationOauth | cdktf.IResolvable): any;
export declare class DataStackitDremioInstanceAuthenticationOauthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDremioInstanceAuthenticationOauth | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitDremioInstanceAuthenticationOauth | cdktf.IResolvable | undefined);
    get authorityUrl(): string;
    get clientId(): string;
    get clientSecret(): string;
    private _jwtClaims;
    get jwtClaims(): DataStackitDremioInstanceAuthenticationOauthJwtClaimsOutputReference;
    private _parameters;
    get parameters(): DataStackitDremioInstanceAuthenticationOauthParametersList;
    putParameters(value: DataStackitDremioInstanceAuthenticationOauthParameters[] | cdktf.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | DataStackitDremioInstanceAuthenticationOauthParameters[] | undefined;
    get redirectUrl(): string;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
}
export interface DataStackitDremioInstanceAuthentication {
    /**
    * Azure Active Directory authentication configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#azuread DataStackitDremioInstance#azuread}
    */
    readonly azuread?: DataStackitDremioInstanceAuthenticationAzuread;
    /**
    * OIDC authentication configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#oauth DataStackitDremioInstance#oauth}
    */
    readonly oauth?: DataStackitDremioInstanceAuthenticationOauth;
}
export declare function dataStackitDremioInstanceAuthenticationToTerraform(struct?: DataStackitDremioInstanceAuthentication): any;
export declare function dataStackitDremioInstanceAuthenticationToHclTerraform(struct?: DataStackitDremioInstanceAuthentication): any;
export declare class DataStackitDremioInstanceAuthenticationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDremioInstanceAuthentication | undefined;
    set internalValue(value: DataStackitDremioInstanceAuthentication | undefined);
    private _azuread;
    get azuread(): DataStackitDremioInstanceAuthenticationAzureadOutputReference;
    putAzuread(value: DataStackitDremioInstanceAuthenticationAzuread): void;
    resetAzuread(): void;
    get azureadInput(): cdktf.IResolvable | DataStackitDremioInstanceAuthenticationAzuread | undefined;
    private _oauth;
    get oauth(): DataStackitDremioInstanceAuthenticationOauthOutputReference;
    putOauth(value: DataStackitDremioInstanceAuthenticationOauth): void;
    resetOauth(): void;
    get oauthInput(): cdktf.IResolvable | DataStackitDremioInstanceAuthenticationOauth | undefined;
    get type(): string;
}
export interface DataStackitDremioInstanceEndpoints {
}
export declare function dataStackitDremioInstanceEndpointsToTerraform(struct?: DataStackitDremioInstanceEndpoints): any;
export declare function dataStackitDremioInstanceEndpointsToHclTerraform(struct?: DataStackitDremioInstanceEndpoints): any;
export declare class DataStackitDremioInstanceEndpointsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDremioInstanceEndpoints | undefined;
    set internalValue(value: DataStackitDremioInstanceEndpoints | undefined);
    get arrowFlight(): string;
    get catalog(): string;
    get ui(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance stackit_dremio_instance}
*/
export declare class DataStackitDremioInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_dremio_instance";
    /**
    * Generates CDKTF code for importing a DataStackitDremioInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitDremioInstance to import
    * @param importFromId The id of the existing DataStackitDremioInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitDremioInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/dremio_instance stackit_dremio_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitDremioInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitDremioInstanceConfig);
    private _authentication;
    get authentication(): DataStackitDremioInstanceAuthenticationOutputReference;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get displayName(): string;
    private _endpoints;
    get endpoints(): DataStackitDremioInstanceEndpointsOutputReference;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
