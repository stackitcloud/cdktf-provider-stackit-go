import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LogsInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list entries for the Logs instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#acl LogsInstance#acl}
    */
    readonly acl?: string[];
    /**
    * The description of the Logs instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#description LogsInstance#description}
    */
    readonly description?: string;
    /**
    * The displayed name of the Logs instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#display_name LogsInstance#display_name}
    */
    readonly displayName: string;
    /**
    * STACKIT project ID associated with the Logs instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#project_id LogsInstance#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#region LogsInstance#region}
    */
    readonly region?: string;
    /**
    * The log retention time in days
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#retention_days LogsInstance#retention_days}
    */
    readonly retentionDays: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance stackit_logs_instance}
*/
export declare class LogsInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_logs_instance";
    /**
    * Generates CDKTF code for importing a LogsInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsInstance to import
    * @param importFromId The id of the existing LogsInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/logs_instance stackit_logs_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsInstanceConfig
    */
    constructor(scope: Construct, id: string, config: LogsInstanceConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    resetAcl(): void;
    get aclInput(): string[] | undefined;
    get created(): string;
    get datasourceUrl(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get ingestOtlpUrl(): string;
    get ingestUrl(): string;
    get instanceId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get queryRangeUrl(): string;
    get queryUrl(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    get retentionDaysInput(): number | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
