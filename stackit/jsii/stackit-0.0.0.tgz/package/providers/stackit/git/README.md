# `stackit_git`

Refer to the Terraform Registry for docs: [`stackit_git`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/git).
