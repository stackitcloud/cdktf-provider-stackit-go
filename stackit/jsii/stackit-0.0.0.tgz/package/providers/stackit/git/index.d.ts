import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface GitConfig extends cdktf.TerraformMetaArguments {
    /**
    * Restricted ACL for instance access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git#acl Git#acl}
    */
    readonly acl?: string[];
    /**
    * Instance flavor. If not provided, defaults to git-100. For a list of available flavors, refer to our API documentation: `https://docs.api.stackit.cloud/documentation/git/version/v1beta`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git#flavor Git#flavor}
    */
    readonly flavor?: string;
    /**
    * Unique name linked to the git instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git#name Git#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the git instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git#project_id Git#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git stackit_git}
*/
export declare class Git extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_git";
    /**
    * Generates CDKTF code for importing a Git resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Git to import
    * @param importFromId The id of the existing Git that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Git to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/git stackit_git} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GitConfig
    */
    constructor(scope: Construct, id: string, config: GitConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    resetAcl(): void;
    get aclInput(): string[] | undefined;
    get consumedDisk(): string;
    get consumedObjectStorage(): string;
    get created(): string;
    private _flavor?;
    get flavor(): string;
    set flavor(value: string);
    resetFlavor(): void;
    get flavorInput(): string | undefined;
    get id(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get url(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
