# `stackit_volume`

Refer to the Terraform Registry for docs: [`stackit_volume`](https://registry.terraform.io/providers/stackitcloud/stackit/0.118.0/docs/resources/volume).
