import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObjectstorageCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credential ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential#credential_id DataStackitObjectstorageCredential#credential_id}
    */
    readonly credentialId: string;
    /**
    * The credential group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential#credentials_group_id DataStackitObjectstorageCredential#credentials_group_id}
    */
    readonly credentialsGroupId: string;
    /**
    * STACKIT Project ID to which the credential group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential#project_id DataStackitObjectstorageCredential#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential#region DataStackitObjectstorageCredential#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential stackit_objectstorage_credential}
*/
export declare class DataStackitObjectstorageCredential extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_objectstorage_credential";
    /**
    * Generates CDKTF code for importing a DataStackitObjectstorageCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObjectstorageCredential to import
    * @param importFromId The id of the existing DataStackitObjectstorageCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObjectstorageCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credential stackit_objectstorage_credential} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObjectstorageCredentialConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObjectstorageCredentialConfig);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    get credentialIdInput(): string | undefined;
    private _credentialsGroupId?;
    get credentialsGroupId(): string;
    set credentialsGroupId(value: string);
    get credentialsGroupIdInput(): string | undefined;
    get expirationTimestamp(): string;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
