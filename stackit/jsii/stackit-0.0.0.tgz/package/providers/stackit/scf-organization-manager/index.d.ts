import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ScfOrganizationManagerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Cloud Foundry Organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager#org_id ScfOrganizationManager#org_id}
    */
    readonly orgId: string;
    /**
    * The ID of the project associated with the organization of the organization manager
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager#project_id ScfOrganizationManager#project_id}
    */
    readonly projectId: string;
    /**
    * The region where the organization of the organization manager is located. If not defined, the provider region is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager#region ScfOrganizationManager#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager stackit_scf_organization_manager}
*/
export declare class ScfOrganizationManager extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_scf_organization_manager";
    /**
    * Generates CDKTF code for importing a ScfOrganizationManager resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ScfOrganizationManager to import
    * @param importFromId The id of the existing ScfOrganizationManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ScfOrganizationManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization_manager stackit_scf_organization_manager} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScfOrganizationManagerConfig
    */
    constructor(scope: Construct, id: string, config: ScfOrganizationManagerConfig);
    get createdAt(): string;
    get id(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get password(): string;
    get platformId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get updatedAt(): string;
    get userId(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
