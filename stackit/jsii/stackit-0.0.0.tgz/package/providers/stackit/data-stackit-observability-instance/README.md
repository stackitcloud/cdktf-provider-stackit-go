# `data_stackit_observability_instance`

Refer to the Terraform Registry for docs: [`data_stackit_observability_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/observability_instance).
