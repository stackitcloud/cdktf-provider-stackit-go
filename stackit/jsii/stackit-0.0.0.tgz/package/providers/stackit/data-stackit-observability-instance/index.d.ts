import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObservabilityInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Observability instance ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/observability_instance#instance_id DataStackitObservabilityInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/observability_instance#project_id DataStackitObservabilityInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitObservabilityInstanceAlertConfigGlobal {
}
export declare function dataStackitObservabilityInstanceAlertConfigGlobalToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigGlobal): any;
export declare function dataStackitObservabilityInstanceAlertConfigGlobalToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigGlobal): any;
export declare class DataStackitObservabilityInstanceAlertConfigGlobalOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigGlobal | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigGlobal | undefined);
    get opsgenieApiKey(): string;
    get opsgenieApiUrl(): string;
    get resolveTimeout(): string;
    get smtpAuthIdentity(): string;
    get smtpAuthPassword(): string;
    get smtpAuthUsername(): string;
    get smtpFrom(): string;
    get smtpSmartHost(): string;
}
export interface DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigs {
}
export declare function dataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigs): any;
export declare function dataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigs): any;
export declare class DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigs | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigs | undefined);
    get authIdentity(): string;
    get authPassword(): string;
    get authUsername(): string;
    get from(): string;
    get sendResolved(): cdktf.IResolvable;
    get smartHost(): string;
    get to(): string;
}
export declare class DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsOutputReference;
}
export interface DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigs {
}
export declare function dataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigs): any;
export declare function dataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigs): any;
export declare class DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | undefined);
    get apiKey(): string;
    get apiUrl(): string;
    get priority(): string;
    get sendResolved(): cdktf.IResolvable;
    get tags(): string;
}
export declare class DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsOutputReference;
}
export interface DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigs {
}
export declare function dataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigs): any;
export declare function dataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigs): any;
export declare class DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigs | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigs | undefined);
    get googleChat(): cdktf.IResolvable;
    get msTeams(): cdktf.IResolvable;
    get sendResolved(): cdktf.IResolvable;
    get url(): string;
}
export declare class DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsOutputReference;
}
export interface DataStackitObservabilityInstanceAlertConfigReceivers {
}
export declare function dataStackitObservabilityInstanceAlertConfigReceiversToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceivers): any;
export declare function dataStackitObservabilityInstanceAlertConfigReceiversToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigReceivers): any;
export declare class DataStackitObservabilityInstanceAlertConfigReceiversOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigReceivers | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigReceivers | undefined);
    private _emailConfigs;
    get emailConfigs(): DataStackitObservabilityInstanceAlertConfigReceiversEmailConfigsList;
    get name(): string;
    private _opsgenieConfigs;
    get opsgenieConfigs(): DataStackitObservabilityInstanceAlertConfigReceiversOpsgenieConfigsList;
    private _webhooksConfigs;
    get webhooksConfigs(): DataStackitObservabilityInstanceAlertConfigReceiversWebhooksConfigsList;
}
export declare class DataStackitObservabilityInstanceAlertConfigReceiversList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityInstanceAlertConfigReceiversOutputReference;
}
export interface DataStackitObservabilityInstanceAlertConfigRouteRoutes {
}
export declare function dataStackitObservabilityInstanceAlertConfigRouteRoutesToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigRouteRoutes): any;
export declare function dataStackitObservabilityInstanceAlertConfigRouteRoutesToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigRouteRoutes): any;
export declare class DataStackitObservabilityInstanceAlertConfigRouteRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigRouteRoutes | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigRouteRoutes | undefined);
    get continue(): cdktf.IResolvable;
    get groupBy(): string[];
    get groupInterval(): string;
    get groupWait(): string;
    private _match;
    get match(): cdktf.StringMap;
    private _matchRegex;
    get matchRegex(): cdktf.StringMap;
    get matchers(): string[];
    get receiver(): string;
    get repeatInterval(): string;
}
export declare class DataStackitObservabilityInstanceAlertConfigRouteRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityInstanceAlertConfigRouteRoutesOutputReference;
}
export interface DataStackitObservabilityInstanceAlertConfigRoute {
}
export declare function dataStackitObservabilityInstanceAlertConfigRouteToTerraform(struct?: DataStackitObservabilityInstanceAlertConfigRoute): any;
export declare function dataStackitObservabilityInstanceAlertConfigRouteToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfigRoute): any;
export declare class DataStackitObservabilityInstanceAlertConfigRouteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitObservabilityInstanceAlertConfigRoute | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfigRoute | undefined);
    get continue(): cdktf.IResolvable;
    get groupBy(): string[];
    get groupInterval(): string;
    get groupWait(): string;
    get receiver(): string;
    get repeatInterval(): string;
    private _routes;
    get routes(): DataStackitObservabilityInstanceAlertConfigRouteRoutesList;
}
export interface DataStackitObservabilityInstanceAlertConfig {
}
export declare function dataStackitObservabilityInstanceAlertConfigToTerraform(struct?: DataStackitObservabilityInstanceAlertConfig): any;
export declare function dataStackitObservabilityInstanceAlertConfigToHclTerraform(struct?: DataStackitObservabilityInstanceAlertConfig): any;
export declare class DataStackitObservabilityInstanceAlertConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitObservabilityInstanceAlertConfig | undefined;
    set internalValue(value: DataStackitObservabilityInstanceAlertConfig | undefined);
    private _global;
    get global(): DataStackitObservabilityInstanceAlertConfigGlobalOutputReference;
    private _receivers;
    get receivers(): DataStackitObservabilityInstanceAlertConfigReceiversList;
    private _route;
    get route(): DataStackitObservabilityInstanceAlertConfigRouteOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/observability_instance stackit_observability_instance}
*/
export declare class DataStackitObservabilityInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_observability_instance";
    /**
    * Generates CDKTF code for importing a DataStackitObservabilityInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObservabilityInstance to import
    * @param importFromId The id of the existing DataStackitObservabilityInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/observability_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObservabilityInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/observability_instance stackit_observability_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObservabilityInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObservabilityInstanceConfig);
    get acl(): string[];
    private _alertConfig;
    get alertConfig(): DataStackitObservabilityInstanceAlertConfigOutputReference;
    get alertingUrl(): string;
    get dashboardUrl(): string;
    get grafanaAdminEnabled(): cdktf.IResolvable;
    get grafanaInitialAdminPassword(): string;
    get grafanaInitialAdminUser(): string;
    get grafanaPublicReadAccess(): cdktf.IResolvable;
    get grafanaUrl(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get isUpdatable(): cdktf.IResolvable;
    get jaegerTracesUrl(): string;
    get jaegerUiUrl(): string;
    get logsPushUrl(): string;
    get logsRetentionDays(): number;
    get logsUrl(): string;
    get metricsPushUrl(): string;
    get metricsRetentionDays(): number;
    get metricsRetentionDays1HDownsampling(): number;
    get metricsRetentionDays5MDownsampling(): number;
    get metricsUrl(): string;
    get name(): string;
    get otlpGrpcTracesUrl(): string;
    get otlpHttpLogsUrl(): string;
    get otlpHttpTracesUrl(): string;
    get otlpTracesUrl(): string;
    private _parameters;
    get parameters(): cdktf.StringMap;
    get planId(): string;
    get planName(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get targetsUrl(): string;
    get tracesRetentionDays(): number;
    get zipkinSpansUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
