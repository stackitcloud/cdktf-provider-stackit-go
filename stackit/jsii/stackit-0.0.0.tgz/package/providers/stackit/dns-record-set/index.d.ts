import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DnsRecordSetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Specifies if the record set is active or not. Defaults to `true`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#active DnsRecordSet#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * Comment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#comment DnsRecordSet#comment}
    */
    readonly comment?: string;
    /**
    * Name of the record which should be a valid domain according to rfc1035 Section 2.3.4. E.g. `example.com`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#name DnsRecordSet#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the dns record set is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#project_id DnsRecordSet#project_id}
    */
    readonly projectId: string;
    /**
    * Records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#records DnsRecordSet#records}
    */
    readonly records: string[];
    /**
    * Time to live. E.g. 3600
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#ttl DnsRecordSet#ttl}
    */
    readonly ttl?: number;
    /**
    * The record set type. E.g. `A` or `CNAME`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#type DnsRecordSet#type}
    */
    readonly type: string;
    /**
    * The zone ID to which is dns record set is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#zone_id DnsRecordSet#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set stackit_dns_record_set}
*/
export declare class DnsRecordSet extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_dns_record_set";
    /**
    * Generates CDKTF code for importing a DnsRecordSet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsRecordSet to import
    * @param importFromId The id of the existing DnsRecordSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsRecordSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/dns_record_set stackit_dns_record_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsRecordSetConfig
    */
    constructor(scope: Construct, id: string, config: DnsRecordSetConfig);
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _comment?;
    get comment(): string;
    set comment(value: string);
    resetComment(): void;
    get commentInput(): string | undefined;
    get error(): string;
    get fqdn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get recordSetId(): string;
    private _records?;
    get records(): string[];
    set records(value: string[]);
    get recordsInput(): string[] | undefined;
    get state(): string;
    private _ttl?;
    get ttl(): number;
    set ttl(value: number);
    resetTtl(): void;
    get ttlInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
