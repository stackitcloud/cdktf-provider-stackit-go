import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitDremioUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the user.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#description DataStackitDremioUser#description}
    */
    readonly description?: string;
    /**
    * The Dremio instance ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#instance_id DataStackitDremioUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the resource is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#project_id DataStackitDremioUser#project_id}
    */
    readonly projectId: string;
    /**
    * The STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#region DataStackitDremioUser#region}
    */
    readonly region?: string;
    /**
    * The Dremio user ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#user_id DataStackitDremioUser#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user stackit_dremio_user}
*/
export declare class DataStackitDremioUser extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_dremio_user";
    /**
    * Generates CDKTF code for importing a DataStackitDremioUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitDremioUser to import
    * @param importFromId The id of the existing DataStackitDremioUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitDremioUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/dremio_user stackit_dremio_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitDremioUserConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitDremioUserConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get email(): string;
    get firstName(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get lastName(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
