import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSkeKubernetesVersionsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Region override. If omitted, the provider’s region will be used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/ske_kubernetes_versions#region DataStackitSkeKubernetesVersions#region}
    */
    readonly region?: string;
    /**
    * If specified, only returns Kubernetes versions with this version state. Possible values are: `SUPPORTED`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/ske_kubernetes_versions#version_state DataStackitSkeKubernetesVersions#version_state}
    */
    readonly versionState?: string;
}
export interface DataStackitSkeKubernetesVersionsKubernetesVersions {
}
export declare function dataStackitSkeKubernetesVersionsKubernetesVersionsToTerraform(struct?: DataStackitSkeKubernetesVersionsKubernetesVersions): any;
export declare function dataStackitSkeKubernetesVersionsKubernetesVersionsToHclTerraform(struct?: DataStackitSkeKubernetesVersionsKubernetesVersions): any;
export declare class DataStackitSkeKubernetesVersionsKubernetesVersionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSkeKubernetesVersionsKubernetesVersions | undefined;
    set internalValue(value: DataStackitSkeKubernetesVersionsKubernetesVersions | undefined);
    get expirationDate(): string;
    private _featureGates;
    get featureGates(): cdktf.StringMap;
    get state(): string;
    get version(): string;
}
export declare class DataStackitSkeKubernetesVersionsKubernetesVersionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSkeKubernetesVersionsKubernetesVersionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/ske_kubernetes_versions stackit_ske_kubernetes_versions}
*/
export declare class DataStackitSkeKubernetesVersions extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_ske_kubernetes_versions";
    /**
    * Generates CDKTF code for importing a DataStackitSkeKubernetesVersions resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSkeKubernetesVersions to import
    * @param importFromId The id of the existing DataStackitSkeKubernetesVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/ske_kubernetes_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSkeKubernetesVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/ske_kubernetes_versions stackit_ske_kubernetes_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSkeKubernetesVersionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataStackitSkeKubernetesVersionsConfig);
    private _kubernetesVersions;
    get kubernetesVersions(): DataStackitSkeKubernetesVersionsKubernetesVersionsList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _versionState?;
    get versionState(): string;
    set versionState(value: string);
    resetVersionState(): void;
    get versionStateInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
