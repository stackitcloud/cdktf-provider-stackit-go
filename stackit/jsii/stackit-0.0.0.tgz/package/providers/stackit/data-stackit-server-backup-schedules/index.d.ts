import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServerBackupSchedulesConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID (UUID) to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules#project_id DataStackitServerBackupSchedules#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules#region DataStackitServerBackupSchedules#region}
    */
    readonly region?: string;
    /**
    * Server ID (UUID) to which the backup schedule is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules#server_id DataStackitServerBackupSchedules#server_id}
    */
    readonly serverId: string;
}
export interface DataStackitServerBackupSchedulesItemsBackupProperties {
}
export declare function dataStackitServerBackupSchedulesItemsBackupPropertiesToTerraform(struct?: DataStackitServerBackupSchedulesItemsBackupProperties): any;
export declare function dataStackitServerBackupSchedulesItemsBackupPropertiesToHclTerraform(struct?: DataStackitServerBackupSchedulesItemsBackupProperties): any;
export declare class DataStackitServerBackupSchedulesItemsBackupPropertiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitServerBackupSchedulesItemsBackupProperties | undefined;
    set internalValue(value: DataStackitServerBackupSchedulesItemsBackupProperties | undefined);
    get name(): string;
    get retentionPeriod(): number;
    get volumeIds(): string[];
}
export interface DataStackitServerBackupSchedulesItems {
}
export declare function dataStackitServerBackupSchedulesItemsToTerraform(struct?: DataStackitServerBackupSchedulesItems): any;
export declare function dataStackitServerBackupSchedulesItemsToHclTerraform(struct?: DataStackitServerBackupSchedulesItems): any;
export declare class DataStackitServerBackupSchedulesItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitServerBackupSchedulesItems | undefined;
    set internalValue(value: DataStackitServerBackupSchedulesItems | undefined);
    private _backupProperties;
    get backupProperties(): DataStackitServerBackupSchedulesItemsBackupPropertiesOutputReference;
    get backupScheduleId(): number;
    get enabled(): cdktf.IResolvable;
    get name(): string;
    get rrule(): string;
}
export declare class DataStackitServerBackupSchedulesItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitServerBackupSchedulesItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules stackit_server_backup_schedules}
*/
export declare class DataStackitServerBackupSchedules extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_server_backup_schedules";
    /**
    * Generates CDKTF code for importing a DataStackitServerBackupSchedules resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServerBackupSchedules to import
    * @param importFromId The id of the existing DataStackitServerBackupSchedules that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServerBackupSchedules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/server_backup_schedules stackit_server_backup_schedules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServerBackupSchedulesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServerBackupSchedulesConfig);
    get id(): string;
    private _items;
    get items(): DataStackitServerBackupSchedulesItemsList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
