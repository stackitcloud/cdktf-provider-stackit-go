# `stackit_logme_instance`

Refer to the Terraform Registry for docs: [`stackit_logme_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/resources/logme_instance).
