import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LogmeInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#name LogmeInstance#name}
    */
    readonly name: string;
    /**
    * Configuration parameters. Please note that removing a previously configured field from your Terraform configuration won't replace its value in the API. To update a previously configured field, explicitly set a new value for it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#parameters LogmeInstance#parameters}
    */
    readonly parameters?: LogmeInstanceParameters;
    /**
    * The selected plan name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#plan_name LogmeInstance#plan_name}
    */
    readonly planName: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#project_id LogmeInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The service version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#version LogmeInstance#version}
    */
    readonly version: string;
}
export interface LogmeInstanceParameters {
    /**
    * Enable monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#enable_monitoring LogmeInstance#enable_monitoring}
    */
    readonly enableMonitoring?: boolean | cdktf.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tcp LogmeInstance#fluentd_tcp}
    */
    readonly fluentdTcp?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tls LogmeInstance#fluentd_tls}
    */
    readonly fluentdTls?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tls_ciphers LogmeInstance#fluentd_tls_ciphers}
    */
    readonly fluentdTlsCiphers?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tls_max_version LogmeInstance#fluentd_tls_max_version}
    */
    readonly fluentdTlsMaxVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tls_min_version LogmeInstance#fluentd_tls_min_version}
    */
    readonly fluentdTlsMinVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_tls_version LogmeInstance#fluentd_tls_version}
    */
    readonly fluentdTlsVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#fluentd_udp LogmeInstance#fluentd_udp}
    */
    readonly fluentdUdp?: number;
    /**
    * If set, monitoring with Graphite will be enabled. Expects the host and port where the Graphite metrics should be sent to (host:port).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#graphite LogmeInstance#graphite}
    */
    readonly graphite?: string;
    /**
    * Combination of an integer and a timerange when an index will be considered "old" and can be deleted. Possible values for the timerange are `s`, `m`, `h` and `d`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#ism_deletion_after LogmeInstance#ism_deletion_after}
    */
    readonly ismDeletionAfter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#ism_jitter LogmeInstance#ism_jitter}
    */
    readonly ismJitter?: number;
    /**
    * Jitter of the execution time.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#ism_job_interval LogmeInstance#ism_job_interval}
    */
    readonly ismJobInterval?: number;
    /**
    * The amount of memory (in MB) allocated as heap by the JVM for OpenSearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#java_heapspace LogmeInstance#java_heapspace}
    */
    readonly javaHeapspace?: number;
    /**
    * The amount of memory (in MB) used by the JVM to store metadata for OpenSearch.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#java_maxmetaspace LogmeInstance#java_maxmetaspace}
    */
    readonly javaMaxmetaspace?: number;
    /**
    * The maximum disk threshold in MB. If the disk usage exceeds this threshold, the instance will be stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#max_disk_threshold LogmeInstance#max_disk_threshold}
    */
    readonly maxDiskThreshold?: number;
    /**
    * The frequency in seconds at which metrics are emitted (in seconds).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#metrics_frequency LogmeInstance#metrics_frequency}
    */
    readonly metricsFrequency?: number;
    /**
    * The prefix for the metrics. Could be useful when using Graphite monitoring to prefix the metrics with a certain value, like an API key.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#metrics_prefix LogmeInstance#metrics_prefix}
    */
    readonly metricsPrefix?: string;
    /**
    * The ID of the STACKIT monitoring instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#monitoring_instance_id LogmeInstance#monitoring_instance_id}
    */
    readonly monitoringInstanceId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#opensearch_tls_ciphers LogmeInstance#opensearch_tls_ciphers}
    */
    readonly opensearchTlsCiphers?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#opensearch_tls_protocols LogmeInstance#opensearch_tls_protocols}
    */
    readonly opensearchTlsProtocols?: string[];
    /**
    * Comma separated list of IP networks in CIDR notation which are allowed to access this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#sgw_acl LogmeInstance#sgw_acl}
    */
    readonly sgwAcl?: string;
    /**
    * List of syslog servers to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#syslog LogmeInstance#syslog}
    */
    readonly syslog?: string[];
}
export declare function logmeInstanceParametersToTerraform(struct?: LogmeInstanceParameters | cdktf.IResolvable): any;
export declare function logmeInstanceParametersToHclTerraform(struct?: LogmeInstanceParameters | cdktf.IResolvable): any;
export declare class LogmeInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): LogmeInstanceParameters | cdktf.IResolvable | undefined;
    set internalValue(value: LogmeInstanceParameters | cdktf.IResolvable | undefined);
    private _enableMonitoring?;
    get enableMonitoring(): boolean | cdktf.IResolvable;
    set enableMonitoring(value: boolean | cdktf.IResolvable);
    resetEnableMonitoring(): void;
    get enableMonitoringInput(): boolean | cdktf.IResolvable | undefined;
    private _fluentdTcp?;
    get fluentdTcp(): number;
    set fluentdTcp(value: number);
    resetFluentdTcp(): void;
    get fluentdTcpInput(): number | undefined;
    private _fluentdTls?;
    get fluentdTls(): number;
    set fluentdTls(value: number);
    resetFluentdTls(): void;
    get fluentdTlsInput(): number | undefined;
    private _fluentdTlsCiphers?;
    get fluentdTlsCiphers(): string;
    set fluentdTlsCiphers(value: string);
    resetFluentdTlsCiphers(): void;
    get fluentdTlsCiphersInput(): string | undefined;
    private _fluentdTlsMaxVersion?;
    get fluentdTlsMaxVersion(): string;
    set fluentdTlsMaxVersion(value: string);
    resetFluentdTlsMaxVersion(): void;
    get fluentdTlsMaxVersionInput(): string | undefined;
    private _fluentdTlsMinVersion?;
    get fluentdTlsMinVersion(): string;
    set fluentdTlsMinVersion(value: string);
    resetFluentdTlsMinVersion(): void;
    get fluentdTlsMinVersionInput(): string | undefined;
    private _fluentdTlsVersion?;
    get fluentdTlsVersion(): string;
    set fluentdTlsVersion(value: string);
    resetFluentdTlsVersion(): void;
    get fluentdTlsVersionInput(): string | undefined;
    private _fluentdUdp?;
    get fluentdUdp(): number;
    set fluentdUdp(value: number);
    resetFluentdUdp(): void;
    get fluentdUdpInput(): number | undefined;
    private _graphite?;
    get graphite(): string;
    set graphite(value: string);
    resetGraphite(): void;
    get graphiteInput(): string | undefined;
    private _ismDeletionAfter?;
    get ismDeletionAfter(): string;
    set ismDeletionAfter(value: string);
    resetIsmDeletionAfter(): void;
    get ismDeletionAfterInput(): string | undefined;
    private _ismJitter?;
    get ismJitter(): number;
    set ismJitter(value: number);
    resetIsmJitter(): void;
    get ismJitterInput(): number | undefined;
    private _ismJobInterval?;
    get ismJobInterval(): number;
    set ismJobInterval(value: number);
    resetIsmJobInterval(): void;
    get ismJobIntervalInput(): number | undefined;
    private _javaHeapspace?;
    get javaHeapspace(): number;
    set javaHeapspace(value: number);
    resetJavaHeapspace(): void;
    get javaHeapspaceInput(): number | undefined;
    private _javaMaxmetaspace?;
    get javaMaxmetaspace(): number;
    set javaMaxmetaspace(value: number);
    resetJavaMaxmetaspace(): void;
    get javaMaxmetaspaceInput(): number | undefined;
    private _maxDiskThreshold?;
    get maxDiskThreshold(): number;
    set maxDiskThreshold(value: number);
    resetMaxDiskThreshold(): void;
    get maxDiskThresholdInput(): number | undefined;
    private _metricsFrequency?;
    get metricsFrequency(): number;
    set metricsFrequency(value: number);
    resetMetricsFrequency(): void;
    get metricsFrequencyInput(): number | undefined;
    private _metricsPrefix?;
    get metricsPrefix(): string;
    set metricsPrefix(value: string);
    resetMetricsPrefix(): void;
    get metricsPrefixInput(): string | undefined;
    private _monitoringInstanceId?;
    get monitoringInstanceId(): string;
    set monitoringInstanceId(value: string);
    resetMonitoringInstanceId(): void;
    get monitoringInstanceIdInput(): string | undefined;
    private _opensearchTlsCiphers?;
    get opensearchTlsCiphers(): string[];
    set opensearchTlsCiphers(value: string[]);
    resetOpensearchTlsCiphers(): void;
    get opensearchTlsCiphersInput(): string[] | undefined;
    private _opensearchTlsProtocols?;
    get opensearchTlsProtocols(): string[];
    set opensearchTlsProtocols(value: string[]);
    resetOpensearchTlsProtocols(): void;
    get opensearchTlsProtocolsInput(): string[] | undefined;
    private _sgwAcl?;
    get sgwAcl(): string;
    set sgwAcl(value: string);
    resetSgwAcl(): void;
    get sgwAclInput(): string | undefined;
    private _syslog?;
    get syslog(): string[];
    set syslog(value: string[]);
    resetSyslog(): void;
    get syslogInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance stackit_logme_instance}
*/
export declare class LogmeInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_logme_instance";
    /**
    * Generates CDKTF code for importing a LogmeInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogmeInstance to import
    * @param importFromId The id of the existing LogmeInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogmeInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/logme_instance stackit_logme_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogmeInstanceConfig
    */
    constructor(scope: Construct, id: string, config: LogmeInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): LogmeInstanceParametersOutputReference;
    putParameters(value: LogmeInstanceParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | LogmeInstanceParameters | undefined;
    get planId(): string;
    private _planName?;
    get planName(): string;
    set planName(value: string);
    get planNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
