import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObjectstorageBucketConfig extends cdktf.TerraformMetaArguments {
    /**
    * The bucket name. It must be DNS conform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket#name ObjectstorageBucket#name}
    */
    readonly name: string;
    /**
    * STACKIT Project ID to which the bucket is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket#project_id ObjectstorageBucket#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket#region ObjectstorageBucket#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket stackit_objectstorage_bucket}
*/
export declare class ObjectstorageBucket extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_objectstorage_bucket";
    /**
    * Generates CDKTF code for importing a ObjectstorageBucket resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObjectstorageBucket to import
    * @param importFromId The id of the existing ObjectstorageBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObjectstorageBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/objectstorage_bucket stackit_objectstorage_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObjectstorageBucketConfig
    */
    constructor(scope: Construct, id: string, config: ObjectstorageBucketConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get urlPathStyle(): string;
    get urlVirtualHostedStyle(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
