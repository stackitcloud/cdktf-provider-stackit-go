# `stackit_objectstorage_bucket`

Refer to the Terraform Registry for docs: [`stackit_objectstorage_bucket`](https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/resources/objectstorage_bucket).
