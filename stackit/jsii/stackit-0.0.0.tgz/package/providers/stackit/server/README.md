# `stackit_server`

Refer to the Terraform Registry for docs: [`stackit_server`](https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/server).
