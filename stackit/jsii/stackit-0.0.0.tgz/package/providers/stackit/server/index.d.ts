import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The affinity group the server is assigned to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#affinity_group Server#affinity_group}
    */
    readonly affinityGroup?: string;
    /**
    * The availability zone of the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#availability_zone Server#availability_zone}
    */
    readonly availabilityZone?: string;
    /**
    * The boot volume for the server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#boot_volume Server#boot_volume}
    */
    readonly bootVolume?: ServerBootVolume;
    /**
    * The desired status of the server resource. Possible values are: `active`, `inactive`, `deallocated`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#desired_status Server#desired_status}
    */
    readonly desiredStatus?: string;
    /**
    * The image ID to be used for an ephemeral disk on the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#image_id Server#image_id}
    */
    readonly imageId?: string;
    /**
    * The name of the keypair used during server creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#keypair_name Server#keypair_name}
    */
    readonly keypairName?: string;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#labels Server#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the type of the machine for the server. Possible values are documented in [Virtual machine flavors](https://docs.stackit.cloud/products/compute-engine/server/basics/machine-types/)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#machine_type Server#machine_type}
    */
    readonly machineType: string;
    /**
    * The name of the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#name Server#name}
    */
    readonly name: string;
    /**
    * The IDs of network interfaces which should be attached to the server. Updating it will recreate the server. **Required when (re-)creating servers. Still marked as optional in the schema to not introduce breaking changes. There will be a migration path for this field soon.**
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#network_interfaces Server#network_interfaces}
    */
    readonly networkInterfaces?: string[];
    /**
    * STACKIT project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#project_id Server#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#region Server#region}
    */
    readonly region?: string;
    /**
    * User data that is passed via cloud-init to the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#user_data Server#user_data}
    */
    readonly userData?: string;
}
export interface ServerBootVolume {
    /**
    * Delete the volume during the termination of the server. Only allowed when `source_type` is `image`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#delete_on_termination Server#delete_on_termination}
    */
    readonly deleteOnTermination?: boolean | cdktf.IResolvable;
    /**
    * The performance class of the server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#performance_class Server#performance_class}
    */
    readonly performanceClass?: string;
    /**
    * The size of the boot volume in GB. Must be provided when `source_type` is `image`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#size Server#size}
    */
    readonly size?: number;
    /**
    * The ID of the source, either image ID or volume ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#source_id Server#source_id}
    */
    readonly sourceId: string;
    /**
    * The type of the source. Possible values are: `volume`, `image`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#source_type Server#source_type}
    */
    readonly sourceType: string;
}
export declare function serverBootVolumeToTerraform(struct?: ServerBootVolume | cdktf.IResolvable): any;
export declare function serverBootVolumeToHclTerraform(struct?: ServerBootVolume | cdktf.IResolvable): any;
export declare class ServerBootVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServerBootVolume | cdktf.IResolvable | undefined;
    set internalValue(value: ServerBootVolume | cdktf.IResolvable | undefined);
    private _deleteOnTermination?;
    get deleteOnTermination(): boolean | cdktf.IResolvable;
    set deleteOnTermination(value: boolean | cdktf.IResolvable);
    resetDeleteOnTermination(): void;
    get deleteOnTerminationInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _performanceClass?;
    get performanceClass(): string;
    set performanceClass(value: string);
    resetPerformanceClass(): void;
    get performanceClassInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
    private _sourceId?;
    get sourceId(): string;
    set sourceId(value: string);
    get sourceIdInput(): string | undefined;
    private _sourceType?;
    get sourceType(): string;
    set sourceType(value: string);
    get sourceTypeInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server stackit_server}
*/
export declare class Server extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server";
    /**
    * Generates CDKTF code for importing a Server resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Server to import
    * @param importFromId The id of the existing Server that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Server to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/server stackit_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerConfig
    */
    constructor(scope: Construct, id: string, config: ServerConfig);
    private _affinityGroup?;
    get affinityGroup(): string;
    set affinityGroup(value: string);
    resetAffinityGroup(): void;
    get affinityGroupInput(): string | undefined;
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    resetAvailabilityZone(): void;
    get availabilityZoneInput(): string | undefined;
    private _bootVolume;
    get bootVolume(): ServerBootVolumeOutputReference;
    putBootVolume(value: ServerBootVolume): void;
    resetBootVolume(): void;
    get bootVolumeInput(): cdktf.IResolvable | ServerBootVolume | undefined;
    get createdAt(): string;
    private _desiredStatus?;
    get desiredStatus(): string;
    set desiredStatus(value: string);
    resetDesiredStatus(): void;
    get desiredStatusInput(): string | undefined;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _keypairName?;
    get keypairName(): string;
    set keypairName(value: string);
    resetKeypairName(): void;
    get keypairNameInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get launchedAt(): string;
    private _machineType?;
    get machineType(): string;
    set machineType(value: string);
    get machineTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkInterfaces?;
    get networkInterfaces(): string[];
    set networkInterfaces(value: string[]);
    resetNetworkInterfaces(): void;
    get networkInterfacesInput(): string[] | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serverId(): string;
    get updatedAt(): string;
    private _userData?;
    get userData(): string;
    set userData(value: string);
    resetUserData(): void;
    get userDataInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
