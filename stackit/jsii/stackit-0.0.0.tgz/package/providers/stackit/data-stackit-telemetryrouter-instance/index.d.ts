import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitTelemetryrouterInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The TelemetryRouter instance ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance#instance_id DataStackitTelemetryrouterInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID associated with the TelemetryRouter instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance#project_id DataStackitTelemetryrouterInstance#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance#region DataStackitTelemetryrouterInstance#region}
    */
    readonly region?: string;
}
export interface DataStackitTelemetryrouterInstanceFilterAttributes {
}
export declare function dataStackitTelemetryrouterInstanceFilterAttributesToTerraform(struct?: DataStackitTelemetryrouterInstanceFilterAttributes): any;
export declare function dataStackitTelemetryrouterInstanceFilterAttributesToHclTerraform(struct?: DataStackitTelemetryrouterInstanceFilterAttributes): any;
export declare class DataStackitTelemetryrouterInstanceFilterAttributesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitTelemetryrouterInstanceFilterAttributes | undefined;
    set internalValue(value: DataStackitTelemetryrouterInstanceFilterAttributes | undefined);
    get key(): string;
    get level(): string;
    get matcher(): string;
    get values(): string[];
}
export declare class DataStackitTelemetryrouterInstanceFilterAttributesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitTelemetryrouterInstanceFilterAttributesOutputReference;
}
export interface DataStackitTelemetryrouterInstanceFilter {
}
export declare function dataStackitTelemetryrouterInstanceFilterToTerraform(struct?: DataStackitTelemetryrouterInstanceFilter): any;
export declare function dataStackitTelemetryrouterInstanceFilterToHclTerraform(struct?: DataStackitTelemetryrouterInstanceFilter): any;
export declare class DataStackitTelemetryrouterInstanceFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitTelemetryrouterInstanceFilter | undefined;
    set internalValue(value: DataStackitTelemetryrouterInstanceFilter | undefined);
    private _attributes;
    get attributes(): DataStackitTelemetryrouterInstanceFilterAttributesList;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance stackit_telemetryrouter_instance}
*/
export declare class DataStackitTelemetryrouterInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_telemetryrouter_instance";
    /**
    * Generates CDKTF code for importing a DataStackitTelemetryrouterInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitTelemetryrouterInstance to import
    * @param importFromId The id of the existing DataStackitTelemetryrouterInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitTelemetryrouterInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_instance stackit_telemetryrouter_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitTelemetryrouterInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitTelemetryrouterInstanceConfig);
    get creationTime(): string;
    get description(): string;
    get displayName(): string;
    private _filter;
    get filter(): DataStackitTelemetryrouterInstanceFilterOutputReference;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get uri(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
