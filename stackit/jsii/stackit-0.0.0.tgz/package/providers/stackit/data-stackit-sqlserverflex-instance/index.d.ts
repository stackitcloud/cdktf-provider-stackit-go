import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSqlserverflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the SQLServer Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance#instance_id DataStackitSqlserverflexInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance#project_id DataStackitSqlserverflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance#region DataStackitSqlserverflexInstance#region}
    */
    readonly region?: string;
}
export interface DataStackitSqlserverflexInstanceFlavor {
}
export declare function dataStackitSqlserverflexInstanceFlavorToTerraform(struct?: DataStackitSqlserverflexInstanceFlavor): any;
export declare function dataStackitSqlserverflexInstanceFlavorToHclTerraform(struct?: DataStackitSqlserverflexInstanceFlavor): any;
export declare class DataStackitSqlserverflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSqlserverflexInstanceFlavor | undefined;
    set internalValue(value: DataStackitSqlserverflexInstanceFlavor | undefined);
    get cpu(): number;
    get description(): string;
    get id(): string;
    get ram(): number;
}
export interface DataStackitSqlserverflexInstanceOptions {
}
export declare function dataStackitSqlserverflexInstanceOptionsToTerraform(struct?: DataStackitSqlserverflexInstanceOptions): any;
export declare function dataStackitSqlserverflexInstanceOptionsToHclTerraform(struct?: DataStackitSqlserverflexInstanceOptions): any;
export declare class DataStackitSqlserverflexInstanceOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSqlserverflexInstanceOptions | undefined;
    set internalValue(value: DataStackitSqlserverflexInstanceOptions | undefined);
    get edition(): string;
    get retentionDays(): number;
}
export interface DataStackitSqlserverflexInstanceStorage {
}
export declare function dataStackitSqlserverflexInstanceStorageToTerraform(struct?: DataStackitSqlserverflexInstanceStorage): any;
export declare function dataStackitSqlserverflexInstanceStorageToHclTerraform(struct?: DataStackitSqlserverflexInstanceStorage): any;
export declare class DataStackitSqlserverflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSqlserverflexInstanceStorage | undefined;
    set internalValue(value: DataStackitSqlserverflexInstanceStorage | undefined);
    get class(): string;
    get size(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance stackit_sqlserverflex_instance}
*/
export declare class DataStackitSqlserverflexInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sqlserverflex_instance";
    /**
    * Generates CDKTF code for importing a DataStackitSqlserverflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSqlserverflexInstance to import
    * @param importFromId The id of the existing DataStackitSqlserverflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSqlserverflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/sqlserverflex_instance stackit_sqlserverflex_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSqlserverflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSqlserverflexInstanceConfig);
    get acl(): string[];
    get backupSchedule(): string;
    private _flavor;
    get flavor(): DataStackitSqlserverflexInstanceFlavorOutputReference;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _options;
    get options(): DataStackitSqlserverflexInstanceOptionsOutputReference;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicas(): number;
    private _storage;
    get storage(): DataStackitSqlserverflexInstanceStorageOutputReference;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
