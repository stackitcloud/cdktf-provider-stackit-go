import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LoadbalancerObservabilityCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability credential name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#display_name LoadbalancerObservabilityCredential#display_name}
    */
    readonly displayName: string;
    /**
    * The username for the observability service (e.g. Argus) where the logs/metrics will be pushed into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#password LoadbalancerObservabilityCredential#password}
    */
    readonly password: string;
    /**
    * STACKIT project ID to which the load balancer observability credential is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#project_id LoadbalancerObservabilityCredential#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#region LoadbalancerObservabilityCredential#region}
    */
    readonly region?: string;
    /**
    * The password for the observability service (e.g. Argus) where the logs/metrics will be pushed into.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#username LoadbalancerObservabilityCredential#username}
    */
    readonly username: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential stackit_loadbalancer_observability_credential}
*/
export declare class LoadbalancerObservabilityCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_loadbalancer_observability_credential";
    /**
    * Generates CDKTF code for importing a LoadbalancerObservabilityCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LoadbalancerObservabilityCredential to import
    * @param importFromId The id of the existing LoadbalancerObservabilityCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LoadbalancerObservabilityCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/loadbalancer_observability_credential stackit_loadbalancer_observability_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LoadbalancerObservabilityCredentialConfig
    */
    constructor(scope: Construct, id: string, config: LoadbalancerObservabilityCredentialConfig);
    get credentialsRef(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
