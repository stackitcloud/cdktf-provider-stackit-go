import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServiceAccountAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID associated with the service account token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token#project_id ServiceAccountAccessToken#project_id}
    */
    readonly projectId: string;
    /**
    * A map of arbitrary key/value pairs that will force recreation of the token when they change, enabling token rotation based on external conditions such as a rotating timestamp. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token#rotate_when_changed ServiceAccountAccessToken#rotate_when_changed}
    */
    readonly rotateWhenChanged?: {
        [key: string]: string;
    };
    /**
    * Email address linked to the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token#service_account_email ServiceAccountAccessToken#service_account_email}
    */
    readonly serviceAccountEmail: string;
    /**
    * Specifies the token's validity duration in days. If unspecified, defaults to 90 days.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token#ttl_days ServiceAccountAccessToken#ttl_days}
    */
    readonly ttlDays?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token stackit_service_account_access_token}
*/
export declare class ServiceAccountAccessToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_service_account_access_token";
    /**
    * Generates CDKTF code for importing a ServiceAccountAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceAccountAccessToken to import
    * @param importFromId The id of the existing ServiceAccountAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceAccountAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/resources/service_account_access_token stackit_service_account_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceAccountAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: ServiceAccountAccessTokenConfig);
    get accessTokenId(): string;
    get active(): cdktf.IResolvable;
    get createdAt(): string;
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rotateWhenChanged?;
    get rotateWhenChanged(): {
        [key: string]: string;
    };
    set rotateWhenChanged(value: {
        [key: string]: string;
    });
    resetRotateWhenChanged(): void;
    get rotateWhenChangedInput(): {
        [key: string]: string;
    } | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
    get token(): string;
    private _ttlDays?;
    get ttlDays(): number;
    set ttlDays(value: number);
    resetTtlDays(): void;
    get ttlDaysInput(): number | undefined;
    get validUntil(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
