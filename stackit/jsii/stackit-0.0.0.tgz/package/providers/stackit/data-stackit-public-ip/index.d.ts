import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitPublicIpConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the public IP is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip#project_id DataStackitPublicIp#project_id}
    */
    readonly projectId: string;
    /**
    * The public IP ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip#public_ip_id DataStackitPublicIp#public_ip_id}
    */
    readonly publicIpId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip#region DataStackitPublicIp#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip stackit_public_ip}
*/
export declare class DataStackitPublicIp extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_public_ip";
    /**
    * Generates CDKTF code for importing a DataStackitPublicIp resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitPublicIp to import
    * @param importFromId The id of the existing DataStackitPublicIp that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitPublicIp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/public_ip stackit_public_ip} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitPublicIpConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitPublicIpConfig);
    get id(): string;
    get ip(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get networkInterfaceId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _publicIpId?;
    get publicIpId(): string;
    set publicIpId(value: string);
    get publicIpIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
