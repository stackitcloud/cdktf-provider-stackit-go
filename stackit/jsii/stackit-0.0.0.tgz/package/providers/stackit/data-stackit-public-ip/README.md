# `data_stackit_public_ip`

Refer to the Terraform Registry for docs: [`data_stackit_public_ip`](https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/public_ip).
