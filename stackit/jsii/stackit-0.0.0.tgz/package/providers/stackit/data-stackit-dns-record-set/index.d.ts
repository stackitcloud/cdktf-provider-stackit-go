import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitDnsRecordSetConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the dns record set is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set#project_id DataStackitDnsRecordSet#project_id}
    */
    readonly projectId: string;
    /**
    * The rr set id.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set#record_set_id DataStackitDnsRecordSet#record_set_id}
    */
    readonly recordSetId: string;
    /**
    * The zone ID to which is dns record set is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set#zone_id DataStackitDnsRecordSet#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set stackit_dns_record_set}
*/
export declare class DataStackitDnsRecordSet extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_dns_record_set";
    /**
    * Generates CDKTF code for importing a DataStackitDnsRecordSet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitDnsRecordSet to import
    * @param importFromId The id of the existing DataStackitDnsRecordSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitDnsRecordSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/dns_record_set stackit_dns_record_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitDnsRecordSetConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitDnsRecordSetConfig);
    get active(): cdktf.IResolvable;
    get comment(): string;
    get error(): string;
    get fqdn(): string;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _recordSetId?;
    get recordSetId(): string;
    set recordSetId(value: string);
    get recordSetIdInput(): string | undefined;
    get records(): string[];
    get state(): string;
    get ttl(): number;
    get type(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
