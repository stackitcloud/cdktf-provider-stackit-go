# `stackit_observability_alertgroup`

Refer to the Terraform Registry for docs: [`stackit_observability_alertgroup`](https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/observability_alertgroup).
