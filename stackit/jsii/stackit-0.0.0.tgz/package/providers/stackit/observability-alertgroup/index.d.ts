import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObservabilityAlertgroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability instance ID to which the alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#instance_id ObservabilityAlertgroup#instance_id}
    */
    readonly instanceId: string;
    /**
    * Specifies the frequency at which rules within the group are evaluated. The interval must be at least 60 seconds and defaults to 60 seconds if not set. Supported formats include hours, minutes, and seconds, either singly or in combination. Examples of valid formats are: '5h30m40s', '5h', '5h30m', '60m', and '60s'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#interval ObservabilityAlertgroup#interval}
    */
    readonly interval?: string;
    /**
    * The name of the alert group. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#name ObservabilityAlertgroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#project_id ObservabilityAlertgroup#project_id}
    */
    readonly projectId: string;
    /**
    * Rules for the alert group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#rules ObservabilityAlertgroup#rules}
    */
    readonly rules: ObservabilityAlertgroupRules[] | cdktf.IResolvable;
}
export interface ObservabilityAlertgroupRules {
    /**
    * The name of the alert rule. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#alert ObservabilityAlertgroup#alert}
    */
    readonly alert?: string;
    /**
    * A map of key:value. Annotations to add or overwrite for each alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#annotations ObservabilityAlertgroup#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The PromQL expression to evaluate. Every evaluation cycle this is evaluated at the current time, and all resultant time series become pending/firing alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#expression ObservabilityAlertgroup#expression}
    */
    readonly expression: string;
    /**
    * Alerts are considered firing once they have been returned for this long. Alerts which have not yet fired for long enough are considered pending. Default is 0s
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#for ObservabilityAlertgroup#for}
    */
    readonly for?: string;
    /**
    * A map of key:value. Labels to add or overwrite for each alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#labels ObservabilityAlertgroup#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the metric. It's the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#record ObservabilityAlertgroup#record}
    */
    readonly record?: string;
}
export declare function observabilityAlertgroupRulesToTerraform(struct?: ObservabilityAlertgroupRules | cdktf.IResolvable): any;
export declare function observabilityAlertgroupRulesToHclTerraform(struct?: ObservabilityAlertgroupRules | cdktf.IResolvable): any;
export declare class ObservabilityAlertgroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityAlertgroupRules | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityAlertgroupRules | cdktf.IResolvable | undefined);
    private _alert?;
    get alert(): string;
    set alert(value: string);
    resetAlert(): void;
    get alertInput(): string | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _for?;
    get for(): string;
    set for(value: string);
    resetFor(): void;
    get forInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _record?;
    get record(): string;
    set record(value: string);
    resetRecord(): void;
    get recordInput(): string | undefined;
}
export declare class ObservabilityAlertgroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityAlertgroupRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityAlertgroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup stackit_observability_alertgroup}
*/
export declare class ObservabilityAlertgroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_observability_alertgroup";
    /**
    * Generates CDKTF code for importing a ObservabilityAlertgroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityAlertgroup to import
    * @param importFromId The id of the existing ObservabilityAlertgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityAlertgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/observability_alertgroup stackit_observability_alertgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityAlertgroupConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityAlertgroupConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rules;
    get rules(): ObservabilityAlertgroupRulesList;
    putRules(value: ObservabilityAlertgroupRules[] | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | ObservabilityAlertgroupRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
