import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MariadbCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the MariaDB instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential#instance_id MariadbCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential#project_id MariadbCredential#project_id}
    */
    readonly projectId: string;
    /**
    * A map of arbitrary key/value pairs that will force recreation of the resource when they change, enabling resource rotation based on external conditions such as a rotating timestamp. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential#rotate_when_changed MariadbCredential#rotate_when_changed}
    */
    readonly rotateWhenChanged?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential stackit_mariadb_credential}
*/
export declare class MariadbCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_mariadb_credential";
    /**
    * Generates CDKTF code for importing a MariadbCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MariadbCredential to import
    * @param importFromId The id of the existing MariadbCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MariadbCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/mariadb_credential stackit_mariadb_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MariadbCredentialConfig
    */
    constructor(scope: Construct, id: string, config: MariadbCredentialConfig);
    get credentialId(): string;
    get host(): string;
    get hosts(): string[];
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rotateWhenChanged?;
    get rotateWhenChanged(): {
        [key: string]: string;
    };
    set rotateWhenChanged(value: {
        [key: string]: string;
    });
    resetRotateWhenChanged(): void;
    get rotateWhenChangedInput(): {
        [key: string]: string;
    } | undefined;
    get uri(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
