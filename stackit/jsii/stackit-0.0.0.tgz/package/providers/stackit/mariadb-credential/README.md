# `stackit_mariadb_credential`

Refer to the Terraform Registry for docs: [`stackit_mariadb_credential`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/mariadb_credential).
