import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSecretsmanagerInstanceRoleBindingsV1Config extends cdktf.TerraformMetaArguments {
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/secretsmanager_instance_role_bindings_v1#region DataStackitSecretsmanagerInstanceRoleBindingsV1#region}
    */
    readonly region?: string;
    /**
    * The identifier of the resource to get the role bindings for.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/secretsmanager_instance_role_bindings_v1#resource_id DataStackitSecretsmanagerInstanceRoleBindingsV1#resource_id}
    */
    readonly resourceId: string;
}
export interface DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindings {
}
export declare function dataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsToTerraform(struct?: DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindings): any;
export declare function dataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsToHclTerraform(struct?: DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindings): any;
export declare class DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindings | undefined;
    set internalValue(value: DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindings | undefined);
    get role(): string;
    get subject(): string;
}
export declare class DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/secretsmanager_instance_role_bindings_v1 stackit_secretsmanager_instance_role_bindings_v1}
*/
export declare class DataStackitSecretsmanagerInstanceRoleBindingsV1 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_secretsmanager_instance_role_bindings_v1";
    /**
    * Generates CDKTF code for importing a DataStackitSecretsmanagerInstanceRoleBindingsV1 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSecretsmanagerInstanceRoleBindingsV1 to import
    * @param importFromId The id of the existing DataStackitSecretsmanagerInstanceRoleBindingsV1 that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/secretsmanager_instance_role_bindings_v1#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSecretsmanagerInstanceRoleBindingsV1 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/secretsmanager_instance_role_bindings_v1 stackit_secretsmanager_instance_role_bindings_v1} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSecretsmanagerInstanceRoleBindingsV1Config
    */
    constructor(scope: Construct, id: string, config: DataStackitSecretsmanagerInstanceRoleBindingsV1Config);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _roleBindings;
    get roleBindings(): DataStackitSecretsmanagerInstanceRoleBindingsV1RoleBindingsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
