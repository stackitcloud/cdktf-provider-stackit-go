import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlbWafConfigurationConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the custom rule group for this WAF Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#custom_rule_group_name AlbWafConfiguration#custom_rule_group_name}
    */
    readonly customRuleGroupName?: string;
    /**
    * User-defined metadata as key-value pairs. Should not exceed 64 entries.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#labels AlbWafConfiguration#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Name of the managed rule set configuration for this WAF Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#managed_rule_set_name AlbWafConfiguration#managed_rule_set_name}
    */
    readonly managedRuleSetName?: string;
    /**
    * The name of the WAF Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#name AlbWafConfiguration#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the WAF Configuration is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#project_id AlbWafConfiguration#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region (e.g. eu01). If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#region AlbWafConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration stackit_alb_waf_configuration}
*/
export declare class AlbWafConfiguration extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_alb_waf_configuration";
    /**
    * Generates CDKTF code for importing a AlbWafConfiguration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlbWafConfiguration to import
    * @param importFromId The id of the existing AlbWafConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlbWafConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/resources/alb_waf_configuration stackit_alb_waf_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlbWafConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AlbWafConfigurationConfig);
    private _customRuleGroupName?;
    get customRuleGroupName(): string;
    set customRuleGroupName(value: string);
    resetCustomRuleGroupName(): void;
    get customRuleGroupNameInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _managedRuleSetName?;
    get managedRuleSetName(): string;
    set managedRuleSetName(value: string);
    resetManagedRuleSetName(): void;
    get managedRuleSetNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
