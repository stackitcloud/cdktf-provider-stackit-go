# `stackit_public_ip`

Refer to the Terraform Registry for docs: [`stackit_public_ip`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/public_ip).
