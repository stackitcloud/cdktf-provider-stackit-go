import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitKeyPairConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the SSH key pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/key_pair#name DataStackitKeyPair#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/key_pair stackit_key_pair}
*/
export declare class DataStackitKeyPair extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_key_pair";
    /**
    * Generates CDKTF code for importing a DataStackitKeyPair resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitKeyPair to import
    * @param importFromId The id of the existing DataStackitKeyPair that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/key_pair#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitKeyPair to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/key_pair stackit_key_pair} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitKeyPairConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitKeyPairConfig);
    get fingerprint(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicKey(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
