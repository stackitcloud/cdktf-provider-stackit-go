import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitMachineTypeConfig extends cdktf.TerraformMetaArguments {
    /**
    * Expr-lang filter for filtering machine types.
    *
    * Examples:
    * - vcpus == 2
    * - ram >= 2048
    * - extraSpecs.cpu == "intel-icelake-generic"
    * - extraSpecs.cpu == "intel-icelake-generic" && vcpus == 2
    *
    * Syntax reference: https://expr-lang.org/docs/language-definition
    *
    * You can also list available machine-types using the [STACKIT CLI](https://github.com/stackitcloud/stackit-cli):
    *
    * ```bash
    * stackit server machine-type list
    * ```
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type#filter DataStackitMachineType#filter}
    */
    readonly filter: string;
    /**
    * STACKIT Project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type#project_id DataStackitMachineType#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type#region DataStackitMachineType#region}
    */
    readonly region?: string;
    /**
    * Sort machine types by name ascending (`true`) or descending (`false`). Defaults to `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type#sort_ascending DataStackitMachineType#sort_ascending}
    */
    readonly sortAscending?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type stackit_machine_type}
*/
export declare class DataStackitMachineType extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_machine_type";
    /**
    * Generates CDKTF code for importing a DataStackitMachineType resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitMachineType to import
    * @param importFromId The id of the existing DataStackitMachineType that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitMachineType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/machine_type stackit_machine_type} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitMachineTypeConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitMachineTypeConfig);
    get description(): string;
    get disk(): number;
    private _extraSpecs;
    get extraSpecs(): cdktf.StringMap;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    get filterInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get ram(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sortAscending?;
    get sortAscending(): boolean | cdktf.IResolvable;
    set sortAscending(value: boolean | cdktf.IResolvable);
    resetSortAscending(): void;
    get sortAscendingInput(): boolean | cdktf.IResolvable | undefined;
    get vcpus(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
