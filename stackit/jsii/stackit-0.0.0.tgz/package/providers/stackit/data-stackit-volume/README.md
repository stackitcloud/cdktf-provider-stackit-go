# `data_stackit_volume`

Refer to the Terraform Registry for docs: [`data_stackit_volume`](https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/volume).
