import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitVolumeConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the volume is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume#project_id DataStackitVolume#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume#region DataStackitVolume#region}
    */
    readonly region?: string;
    /**
    * The volume ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume#volume_id DataStackitVolume#volume_id}
    */
    readonly volumeId: string;
}
export interface DataStackitVolumeSource {
}
export declare function dataStackitVolumeSourceToTerraform(struct?: DataStackitVolumeSource): any;
export declare function dataStackitVolumeSourceToHclTerraform(struct?: DataStackitVolumeSource): any;
export declare class DataStackitVolumeSourceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitVolumeSource | undefined;
    set internalValue(value: DataStackitVolumeSource | undefined);
    get id(): string;
    get type(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume stackit_volume}
*/
export declare class DataStackitVolume extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_volume";
    /**
    * Generates CDKTF code for importing a DataStackitVolume resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitVolume to import
    * @param importFromId The id of the existing DataStackitVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/volume stackit_volume} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitVolumeConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitVolumeConfig);
    get availabilityZone(): string;
    get description(): string;
    get encrypted(): cdktf.IResolvable;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    get performanceClass(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serverId(): string;
    get size(): number;
    private _source;
    get source(): DataStackitVolumeSourceOutputReference;
    private _volumeId?;
    get volumeId(): string;
    set volumeId(value: string);
    get volumeIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
