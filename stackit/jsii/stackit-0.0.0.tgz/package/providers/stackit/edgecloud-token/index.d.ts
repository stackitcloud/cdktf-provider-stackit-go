import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface EdgecloudTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * Expiration time of the token, in seconds. Minimum is 600, Maximum is 15552000. Defaults to `3600`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#expiration EdgecloudToken#expiration}
    */
    readonly expiration?: number;
    /**
    * ID of the Edge Cloud instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#instance_id EdgecloudToken#instance_id}
    */
    readonly instanceId?: string;
    /**
    * Name of the Edge Cloud instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#instance_name EdgecloudToken#instance_name}
    */
    readonly instanceName?: string;
    /**
    * STACKIT project ID to which the Edge Cloud instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#project_id EdgecloudToken#project_id}
    */
    readonly projectId: string;
    /**
    * Number of seconds before expiration to trigger recreation of the token at.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#recreate_before EdgecloudToken#recreate_before}
    */
    readonly recreateBefore?: number;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#region EdgecloudToken#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token stackit_edgecloud_token}
*/
export declare class EdgecloudToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_edgecloud_token";
    /**
    * Generates CDKTF code for importing a EdgecloudToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the EdgecloudToken to import
    * @param importFromId The id of the existing EdgecloudToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the EdgecloudToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/edgecloud_token stackit_edgecloud_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EdgecloudTokenConfig
    */
    constructor(scope: Construct, id: string, config: EdgecloudTokenConfig);
    get creationTime(): string;
    private _expiration?;
    get expiration(): number;
    set expiration(value: number);
    resetExpiration(): void;
    get expirationInput(): number | undefined;
    get expiresAt(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    resetInstanceId(): void;
    get instanceIdInput(): string | undefined;
    private _instanceName?;
    get instanceName(): string;
    set instanceName(value: string);
    resetInstanceName(): void;
    get instanceNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _recreateBefore?;
    get recreateBefore(): number;
    set recreateBefore(value: number);
    resetRecreateBefore(): void;
    get recreateBeforeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get token(): string;
    get tokenId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
