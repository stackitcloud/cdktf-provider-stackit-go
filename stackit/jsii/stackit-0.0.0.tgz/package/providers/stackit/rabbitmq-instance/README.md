# `stackit_rabbitmq_instance`

Refer to the Terraform Registry for docs: [`stackit_rabbitmq_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/resources/rabbitmq_instance).
