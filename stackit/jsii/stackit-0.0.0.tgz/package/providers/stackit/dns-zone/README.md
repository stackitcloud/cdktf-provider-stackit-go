# `stackit_dns_zone`

Refer to the Terraform Registry for docs: [`stackit_dns_zone`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/resources/dns_zone).
