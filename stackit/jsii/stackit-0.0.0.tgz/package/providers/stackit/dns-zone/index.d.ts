import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DnsZoneConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list. E.g. `0.0.0.0/0,::/0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#acl DnsZone#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#active DnsZone#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * A contact e-mail for the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#contact_email DnsZone#contact_email}
    */
    readonly contactEmail?: string;
    /**
    * Default time to live. E.g. 3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#default_ttl DnsZone#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Description of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#description DnsZone#description}
    */
    readonly description?: string;
    /**
    * The zone name. E.g. `example.com`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#dns_name DnsZone#dns_name}
    */
    readonly dnsName: string;
    /**
    * Expire time. E.g. 1209600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#expire_time DnsZone#expire_time}
    */
    readonly expireTime?: number;
    /**
    * Specifies, if the zone is a reverse zone or not. Defaults to `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#is_reverse_zone DnsZone#is_reverse_zone}
    */
    readonly isReverseZone?: boolean | cdktf.IResolvable;
    /**
    * The user given name of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#name DnsZone#name}
    */
    readonly name: string;
    /**
    * Negative caching. E.g. 60
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#negative_cache DnsZone#negative_cache}
    */
    readonly negativeCache?: number;
    /**
    * Primary name server for secondary zone. E.g. ["1.2.3.4"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#primaries DnsZone#primaries}
    */
    readonly primaries?: string[];
    /**
    * STACKIT project ID to which the dns zone is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#project_id DnsZone#project_id}
    */
    readonly projectId: string;
    /**
    * Refresh time. E.g. 3600
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#refresh_time DnsZone#refresh_time}
    */
    readonly refreshTime?: number;
    /**
    * Retry time. E.g. 600
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#retry_time DnsZone#retry_time}
    */
    readonly retryTime?: number;
    /**
    * Zone type. Defaults to `primary`. Possible values are: `primary`, `secondary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#type DnsZone#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone stackit_dns_zone}
*/
export declare class DnsZone extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_dns_zone";
    /**
    * Generates CDKTF code for importing a DnsZone resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsZone to import
    * @param importFromId The id of the existing DnsZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/dns_zone stackit_dns_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsZoneConfig
    */
    constructor(scope: Construct, id: string, config: DnsZoneConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _contactEmail?;
    get contactEmail(): string;
    set contactEmail(value: string);
    resetContactEmail(): void;
    get contactEmailInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    get dnsNameInput(): string | undefined;
    private _expireTime?;
    get expireTime(): number;
    set expireTime(value: number);
    resetExpireTime(): void;
    get expireTimeInput(): number | undefined;
    get id(): string;
    private _isReverseZone?;
    get isReverseZone(): boolean | cdktf.IResolvable;
    set isReverseZone(value: boolean | cdktf.IResolvable);
    resetIsReverseZone(): void;
    get isReverseZoneInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _negativeCache?;
    get negativeCache(): number;
    set negativeCache(value: number);
    resetNegativeCache(): void;
    get negativeCacheInput(): number | undefined;
    private _primaries?;
    get primaries(): string[];
    set primaries(value: string[]);
    resetPrimaries(): void;
    get primariesInput(): string[] | undefined;
    get primaryNameServer(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get recordCount(): number;
    private _refreshTime?;
    get refreshTime(): number;
    set refreshTime(value: number);
    resetRefreshTime(): void;
    get refreshTimeInput(): number | undefined;
    private _retryTime?;
    get retryTime(): number;
    set retryTime(value: number);
    resetRetryTime(): void;
    get retryTimeInput(): number | undefined;
    get serialNumber(): number;
    get state(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get visibility(): string;
    get zoneId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
