import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DnsZoneConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list. E.g. `0.0.0.0/0,::/0`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#acl DnsZone#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#active DnsZone#active}
    */
    readonly active?: boolean | cdktf.IResolvable;
    /**
    * A contact e-mail for the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#contact_email DnsZone#contact_email}
    */
    readonly contactEmail?: string;
    /**
    * Default time to live. E.g. 3600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#default_ttl DnsZone#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Description of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#description DnsZone#description}
    */
    readonly description?: string;
    /**
    * The zone name. E.g. `example.com`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#dns_name DnsZone#dns_name}
    */
    readonly dnsName: string;
    /**
    * Expire time. E.g. 1209600.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#expire_time DnsZone#expire_time}
    */
    readonly expireTime?: number;
    /**
    * Specifies, if the zone is a reverse zone or not. Defaults to `false`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#is_reverse_zone DnsZone#is_reverse_zone}
    */
    readonly isReverseZone?: boolean | cdktf.IResolvable;
    /**
    * The user given name of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#name DnsZone#name}
    */
    readonly name: string;
    /**
    * Negative caching. E.g. 60
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#negative_cache DnsZone#negative_cache}
    */
    readonly negativeCache?: number;
    /**
    * Primary name server for secondary zone. E.g. ["1.2.3.4"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#primaries DnsZone#primaries}
    */
    readonly primaries?: string[];
    /**
    * STACKIT project ID to which the dns zone is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#project_id DnsZone#project_id}
    */
    readonly projectId: string;
    /**
    * Refresh time. E.g. 3600
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#refresh_time DnsZone#refresh_time}
    */
    readonly refreshTime?: number;
    /**
    * Retry time. E.g. 600
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#retry_time DnsZone#retry_time}
    */
    readonly retryTime?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#timeouts DnsZone#timeouts}
    */
    readonly timeouts?: DnsZoneTimeouts;
    /**
    * Zone type. Defaults to `primary`. Possible values are: `primary`, `secondary`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#type DnsZone#type}
    */
    readonly type?: string;
}
export interface DnsZoneTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#create DnsZone#create}
    */
    readonly create?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#delete DnsZone#delete}
    */
    readonly delete?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Read operations occur during any refresh or planning operation when refresh is enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#read DnsZone#read}
    */
    readonly read?: string;
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#update DnsZone#update}
    */
    readonly update?: string;
}
export declare function dnsZoneTimeoutsToTerraform(struct?: DnsZoneTimeouts | cdktf.IResolvable): any;
export declare function dnsZoneTimeoutsToHclTerraform(struct?: DnsZoneTimeouts | cdktf.IResolvable): any;
export declare class DnsZoneTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DnsZoneTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DnsZoneTimeouts | cdktf.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone stackit_dns_zone}
*/
export declare class DnsZone extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_dns_zone";
    /**
    * Generates CDKTF code for importing a DnsZone resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsZone to import
    * @param importFromId The id of the existing DnsZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/dns_zone stackit_dns_zone} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsZoneConfig
    */
    constructor(scope: Construct, id: string, config: DnsZoneConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _active?;
    get active(): boolean | cdktf.IResolvable;
    set active(value: boolean | cdktf.IResolvable);
    resetActive(): void;
    get activeInput(): boolean | cdktf.IResolvable | undefined;
    private _contactEmail?;
    get contactEmail(): string;
    set contactEmail(value: string);
    resetContactEmail(): void;
    get contactEmailInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    get dnsNameInput(): string | undefined;
    private _expireTime?;
    get expireTime(): number;
    set expireTime(value: number);
    resetExpireTime(): void;
    get expireTimeInput(): number | undefined;
    get id(): string;
    private _isReverseZone?;
    get isReverseZone(): boolean | cdktf.IResolvable;
    set isReverseZone(value: boolean | cdktf.IResolvable);
    resetIsReverseZone(): void;
    get isReverseZoneInput(): boolean | cdktf.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _negativeCache?;
    get negativeCache(): number;
    set negativeCache(value: number);
    resetNegativeCache(): void;
    get negativeCacheInput(): number | undefined;
    private _primaries?;
    get primaries(): string[];
    set primaries(value: string[]);
    resetPrimaries(): void;
    get primariesInput(): string[] | undefined;
    get primaryNameServer(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get recordCount(): number;
    private _refreshTime?;
    get refreshTime(): number;
    set refreshTime(value: number);
    resetRefreshTime(): void;
    get refreshTimeInput(): number | undefined;
    private _retryTime?;
    get retryTime(): number;
    set retryTime(value: number);
    resetRetryTime(): void;
    get retryTimeInput(): number | undefined;
    get serialNumber(): number;
    get state(): string;
    private _timeouts;
    get timeouts(): DnsZoneTimeoutsOutputReference;
    putTimeouts(value: DnsZoneTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DnsZoneTimeouts | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    get visibility(): string;
    get zoneId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
