import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitMongodbflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the MongoDB Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance#instance_id DataStackitMongodbflexInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance#project_id DataStackitMongodbflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance#region DataStackitMongodbflexInstance#region}
    */
    readonly region?: string;
}
export interface DataStackitMongodbflexInstanceFlavor {
}
export declare function dataStackitMongodbflexInstanceFlavorToTerraform(struct?: DataStackitMongodbflexInstanceFlavor): any;
export declare function dataStackitMongodbflexInstanceFlavorToHclTerraform(struct?: DataStackitMongodbflexInstanceFlavor): any;
export declare class DataStackitMongodbflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitMongodbflexInstanceFlavor | undefined;
    set internalValue(value: DataStackitMongodbflexInstanceFlavor | undefined);
    get cpu(): number;
    get description(): string;
    get id(): string;
    get ram(): number;
}
export interface DataStackitMongodbflexInstanceOptions {
}
export declare function dataStackitMongodbflexInstanceOptionsToTerraform(struct?: DataStackitMongodbflexInstanceOptions): any;
export declare function dataStackitMongodbflexInstanceOptionsToHclTerraform(struct?: DataStackitMongodbflexInstanceOptions): any;
export declare class DataStackitMongodbflexInstanceOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitMongodbflexInstanceOptions | undefined;
    set internalValue(value: DataStackitMongodbflexInstanceOptions | undefined);
    get dailySnapshotRetentionDays(): number;
    get monthlySnapshotRetentionMonths(): number;
    get pointInTimeWindowHours(): number;
    get snapshotRetentionDays(): number;
    get type(): string;
    get weeklySnapshotRetentionWeeks(): number;
}
export interface DataStackitMongodbflexInstanceStorage {
}
export declare function dataStackitMongodbflexInstanceStorageToTerraform(struct?: DataStackitMongodbflexInstanceStorage): any;
export declare function dataStackitMongodbflexInstanceStorageToHclTerraform(struct?: DataStackitMongodbflexInstanceStorage): any;
export declare class DataStackitMongodbflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitMongodbflexInstanceStorage | undefined;
    set internalValue(value: DataStackitMongodbflexInstanceStorage | undefined);
    get class(): string;
    get size(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance stackit_mongodbflex_instance}
*/
export declare class DataStackitMongodbflexInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_mongodbflex_instance";
    /**
    * Generates CDKTF code for importing a DataStackitMongodbflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitMongodbflexInstance to import
    * @param importFromId The id of the existing DataStackitMongodbflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitMongodbflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/mongodbflex_instance stackit_mongodbflex_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitMongodbflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitMongodbflexInstanceConfig);
    get acl(): string[];
    get backupSchedule(): string;
    private _flavor;
    get flavor(): DataStackitMongodbflexInstanceFlavorOutputReference;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _options;
    get options(): DataStackitMongodbflexInstanceOptionsOutputReference;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicas(): number;
    private _storage;
    get storage(): DataStackitMongodbflexInstanceStorageOutputReference;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
