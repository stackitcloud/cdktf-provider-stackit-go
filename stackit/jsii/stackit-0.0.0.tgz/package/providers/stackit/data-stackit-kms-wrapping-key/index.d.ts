import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitKmsWrappingKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the associated keyring
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key#keyring_id DataStackitKmsWrappingKey#keyring_id}
    */
    readonly keyringId: string;
    /**
    * STACKIT project ID to which the keyring is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key#project_id DataStackitKmsWrappingKey#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key#region DataStackitKmsWrappingKey#region}
    */
    readonly region?: string;
    /**
    * The ID of the wrapping key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key#wrapping_key_id DataStackitKmsWrappingKey#wrapping_key_id}
    */
    readonly wrappingKeyId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key stackit_kms_wrapping_key}
*/
export declare class DataStackitKmsWrappingKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_kms_wrapping_key";
    /**
    * Generates CDKTF code for importing a DataStackitKmsWrappingKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitKmsWrappingKey to import
    * @param importFromId The id of the existing DataStackitKmsWrappingKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitKmsWrappingKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/kms_wrapping_key stackit_kms_wrapping_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitKmsWrappingKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitKmsWrappingKeyConfig);
    get accessScope(): string;
    get algorithm(): string;
    get createdAt(): string;
    get description(): string;
    get displayName(): string;
    get expiresAt(): string;
    get id(): string;
    private _keyringId?;
    get keyringId(): string;
    set keyringId(value: string);
    get keyringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get protection(): string;
    get publicKey(): string;
    get purpose(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _wrappingKeyId?;
    get wrappingKeyId(): string;
    set wrappingKeyId(value: string);
    get wrappingKeyIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
