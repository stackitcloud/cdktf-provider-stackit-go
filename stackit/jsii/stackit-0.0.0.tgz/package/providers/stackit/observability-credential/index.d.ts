import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObservabilityCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * A description of the credential.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential#description ObservabilityCredential#description}
    */
    readonly description?: string;
    /**
    * The Observability Instance ID the credential belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential#instance_id ObservabilityCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the credential is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential#project_id ObservabilityCredential#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential stackit_observability_credential}
*/
export declare class ObservabilityCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_observability_credential";
    /**
    * Generates CDKTF code for importing a ObservabilityCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityCredential to import
    * @param importFromId The id of the existing ObservabilityCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_credential stackit_observability_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityCredentialConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityCredentialConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get password(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
