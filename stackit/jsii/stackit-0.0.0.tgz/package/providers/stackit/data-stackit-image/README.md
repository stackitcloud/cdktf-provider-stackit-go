# `data_stackit_image`

Refer to the Terraform Registry for docs: [`data_stackit_image`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/image).
