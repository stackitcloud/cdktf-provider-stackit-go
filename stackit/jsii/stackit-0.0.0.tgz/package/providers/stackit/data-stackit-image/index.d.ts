import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitImageConfig extends cdktf.TerraformMetaArguments {
    /**
    * The image ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image#image_id DataStackitImage#image_id}
    */
    readonly imageId: string;
    /**
    * STACKIT project ID to which the image is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image#project_id DataStackitImage#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image#region DataStackitImage#region}
    */
    readonly region?: string;
}
export interface DataStackitImageChecksum {
}
export declare function dataStackitImageChecksumToTerraform(struct?: DataStackitImageChecksum): any;
export declare function dataStackitImageChecksumToHclTerraform(struct?: DataStackitImageChecksum): any;
export declare class DataStackitImageChecksumOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitImageChecksum | undefined;
    set internalValue(value: DataStackitImageChecksum | undefined);
    get algorithm(): string;
    get digest(): string;
}
export interface DataStackitImageConfigA {
}
export declare function dataStackitImageConfigAToTerraform(struct?: DataStackitImageConfigA): any;
export declare function dataStackitImageConfigAToHclTerraform(struct?: DataStackitImageConfigA): any;
export declare class DataStackitImageConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitImageConfigA | undefined;
    set internalValue(value: DataStackitImageConfigA | undefined);
    get bootMenu(): cdktf.IResolvable;
    get cdromBus(): string;
    get diskBus(): string;
    get nicModel(): string;
    get operatingSystem(): string;
    get operatingSystemDistro(): string;
    get operatingSystemVersion(): string;
    get rescueBus(): string;
    get rescueDevice(): string;
    get secureBoot(): cdktf.IResolvable;
    get uefi(): cdktf.IResolvable;
    get videoModel(): string;
    get virtioScsi(): cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image stackit_image}
*/
export declare class DataStackitImage extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_image";
    /**
    * Generates CDKTF code for importing a DataStackitImage resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitImage to import
    * @param importFromId The id of the existing DataStackitImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/image stackit_image} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitImageConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitImageConfig);
    private _checksum;
    get checksum(): DataStackitImageChecksumOutputReference;
    private _config;
    get config(): DataStackitImageConfigAOutputReference;
    get diskFormat(): string;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    get imageIdInput(): string | undefined;
    private _labels;
    get labels(): cdktf.StringMap;
    get minDiskSize(): number;
    get minRam(): number;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get protected(): cdktf.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scope(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
