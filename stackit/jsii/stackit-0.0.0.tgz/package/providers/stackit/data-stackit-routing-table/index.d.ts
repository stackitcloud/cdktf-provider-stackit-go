import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitRoutingTableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table#network_area_id DataStackitRoutingTable#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table#organization_id DataStackitRoutingTable#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table#region DataStackitRoutingTable#region}
    */
    readonly region?: string;
    /**
    * The routing tables ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table#routing_table_id DataStackitRoutingTable#routing_table_id}
    */
    readonly routingTableId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table stackit_routing_table}
*/
export declare class DataStackitRoutingTable extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_routing_table";
    /**
    * Generates CDKTF code for importing a DataStackitRoutingTable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitRoutingTable to import
    * @param importFromId The id of the existing DataStackitRoutingTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitRoutingTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table stackit_routing_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitRoutingTableConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitRoutingTableConfig);
    get createdAt(): string;
    get default(): cdktf.IResolvable;
    get description(): string;
    get dynamicRoutes(): cdktf.IResolvable;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingTableId?;
    get routingTableId(): string;
    set routingTableId(value: string);
    get routingTableIdInput(): string | undefined;
    get systemRoutes(): cdktf.IResolvable;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
