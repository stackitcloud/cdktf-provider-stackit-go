import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitApplicationLoadBalancerConfig extends cdktf.TerraformMetaArguments {
    /**
    * Application Load balancer name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/application_load_balancer#name DataStackitApplicationLoadBalancer#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the Application Load Balancer is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/application_load_balancer#project_id DataStackitApplicationLoadBalancer#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitApplicationLoadBalancerErrors {
}
export declare function dataStackitApplicationLoadBalancerErrorsToTerraform(struct?: DataStackitApplicationLoadBalancerErrors): any;
export declare function dataStackitApplicationLoadBalancerErrorsToHclTerraform(struct?: DataStackitApplicationLoadBalancerErrors): any;
export declare class DataStackitApplicationLoadBalancerErrorsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerErrors | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerErrors | undefined);
    get description(): string;
    get type(): string;
}
export declare class DataStackitApplicationLoadBalancerErrorsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerErrorsOutputReference;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistence | undefined);
    get name(): string;
    get ttl(): string;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeaders {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeaders): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeaders): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeaders | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeaders | undefined);
    get exactMatch(): string;
    get name(): string;
}
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersOutputReference;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHostsRulesPath {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesPathToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesPath): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesPathToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesPath): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesPathOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesPath | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHostsRulesPath | undefined);
    get exactMatch(): string;
    get prefix(): string;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParameters {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParameters): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParameters): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParameters | undefined);
    get exactMatch(): string;
    get name(): string;
}
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersOutputReference;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHostsRules {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRules): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsRulesToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHostsRules): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHostsRules | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHostsRules | undefined);
    private _cookiePersistence;
    get cookiePersistence(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesCookiePersistenceOutputReference;
    private _headers;
    get headers(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesHeadersList;
    private _path;
    get path(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesPathOutputReference;
    private _queryParameters;
    get queryParameters(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesQueryParametersList;
    get targetPool(): string;
    get webSocket(): cdktf.IResolvable;
}
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerListenersHttpHostsRulesOutputReference;
}
export interface DataStackitApplicationLoadBalancerListenersHttpHosts {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHosts): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpHostsToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpHosts): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpHosts | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpHosts | undefined);
    get host(): string;
    private _rules;
    get rules(): DataStackitApplicationLoadBalancerListenersHttpHostsRulesList;
}
export declare class DataStackitApplicationLoadBalancerListenersHttpHostsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerListenersHttpHostsOutputReference;
}
export interface DataStackitApplicationLoadBalancerListenersHttp {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttp): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttp): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttp | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttp | undefined);
    private _hosts;
    get hosts(): DataStackitApplicationLoadBalancerListenersHttpHostsList;
}
export interface DataStackitApplicationLoadBalancerListenersHttpsCertificateConfig {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpsCertificateConfigToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpsCertificateConfig): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpsCertificateConfigToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttpsCertificateConfig): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpsCertificateConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttpsCertificateConfig | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttpsCertificateConfig | undefined);
    get certificateIds(): string[];
}
export interface DataStackitApplicationLoadBalancerListenersHttps {
}
export declare function dataStackitApplicationLoadBalancerListenersHttpsToTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttps): any;
export declare function dataStackitApplicationLoadBalancerListenersHttpsToHclTerraform(struct?: DataStackitApplicationLoadBalancerListenersHttps): any;
export declare class DataStackitApplicationLoadBalancerListenersHttpsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerListenersHttps | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListenersHttps | undefined);
    private _certificateConfig;
    get certificateConfig(): DataStackitApplicationLoadBalancerListenersHttpsCertificateConfigOutputReference;
}
export interface DataStackitApplicationLoadBalancerListeners {
}
export declare function dataStackitApplicationLoadBalancerListenersToTerraform(struct?: DataStackitApplicationLoadBalancerListeners): any;
export declare function dataStackitApplicationLoadBalancerListenersToHclTerraform(struct?: DataStackitApplicationLoadBalancerListeners): any;
export declare class DataStackitApplicationLoadBalancerListenersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerListeners | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerListeners | undefined);
    private _http;
    get http(): DataStackitApplicationLoadBalancerListenersHttpOutputReference;
    private _https;
    get https(): DataStackitApplicationLoadBalancerListenersHttpsOutputReference;
    get name(): string;
    get port(): number;
    get protocol(): string;
    get wafConfigName(): string;
}
export declare class DataStackitApplicationLoadBalancerListenersList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerListenersOutputReference;
}
export interface DataStackitApplicationLoadBalancerLoadBalancerSecurityGroup {
}
export declare function dataStackitApplicationLoadBalancerLoadBalancerSecurityGroupToTerraform(struct?: DataStackitApplicationLoadBalancerLoadBalancerSecurityGroup): any;
export declare function dataStackitApplicationLoadBalancerLoadBalancerSecurityGroupToHclTerraform(struct?: DataStackitApplicationLoadBalancerLoadBalancerSecurityGroup): any;
export declare class DataStackitApplicationLoadBalancerLoadBalancerSecurityGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerLoadBalancerSecurityGroup | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerLoadBalancerSecurityGroup | undefined);
    get id(): string;
    get name(): string;
}
export interface DataStackitApplicationLoadBalancerNetworks {
}
export declare function dataStackitApplicationLoadBalancerNetworksToTerraform(struct?: DataStackitApplicationLoadBalancerNetworks): any;
export declare function dataStackitApplicationLoadBalancerNetworksToHclTerraform(struct?: DataStackitApplicationLoadBalancerNetworks): any;
export declare class DataStackitApplicationLoadBalancerNetworksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerNetworks | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerNetworks | undefined);
    get networkId(): string;
    get role(): string;
}
export declare class DataStackitApplicationLoadBalancerNetworksList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerNetworksOutputReference;
}
export interface DataStackitApplicationLoadBalancerOptionsAccessControl {
}
export declare function dataStackitApplicationLoadBalancerOptionsAccessControlToTerraform(struct?: DataStackitApplicationLoadBalancerOptionsAccessControl): any;
export declare function dataStackitApplicationLoadBalancerOptionsAccessControlToHclTerraform(struct?: DataStackitApplicationLoadBalancerOptionsAccessControl): any;
export declare class DataStackitApplicationLoadBalancerOptionsAccessControlOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerOptionsAccessControl | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerOptionsAccessControl | undefined);
    get allowedSourceRanges(): string[];
}
export interface DataStackitApplicationLoadBalancerOptionsObservabilityLogs {
}
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityLogsToTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservabilityLogs): any;
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityLogsToHclTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservabilityLogs): any;
export declare class DataStackitApplicationLoadBalancerOptionsObservabilityLogsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerOptionsObservabilityLogs | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerOptionsObservabilityLogs | undefined);
    get credentialsRef(): string;
    get pushUrl(): string;
}
export interface DataStackitApplicationLoadBalancerOptionsObservabilityMetrics {
}
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityMetricsToTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservabilityMetrics): any;
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityMetricsToHclTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservabilityMetrics): any;
export declare class DataStackitApplicationLoadBalancerOptionsObservabilityMetricsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerOptionsObservabilityMetrics | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerOptionsObservabilityMetrics | undefined);
    get credentialsRef(): string;
    get pushUrl(): string;
}
export interface DataStackitApplicationLoadBalancerOptionsObservability {
}
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityToTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservability): any;
export declare function dataStackitApplicationLoadBalancerOptionsObservabilityToHclTerraform(struct?: DataStackitApplicationLoadBalancerOptionsObservability): any;
export declare class DataStackitApplicationLoadBalancerOptionsObservabilityOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerOptionsObservability | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerOptionsObservability | undefined);
    private _logs;
    get logs(): DataStackitApplicationLoadBalancerOptionsObservabilityLogsOutputReference;
    private _metrics;
    get metrics(): DataStackitApplicationLoadBalancerOptionsObservabilityMetricsOutputReference;
}
export interface DataStackitApplicationLoadBalancerOptions {
}
export declare function dataStackitApplicationLoadBalancerOptionsToTerraform(struct?: DataStackitApplicationLoadBalancerOptions): any;
export declare function dataStackitApplicationLoadBalancerOptionsToHclTerraform(struct?: DataStackitApplicationLoadBalancerOptions): any;
export declare class DataStackitApplicationLoadBalancerOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerOptions | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerOptions | undefined);
    private _accessControl;
    get accessControl(): DataStackitApplicationLoadBalancerOptionsAccessControlOutputReference;
    get ephemeralAddress(): cdktf.IResolvable;
    private _observability;
    get observability(): DataStackitApplicationLoadBalancerOptionsObservabilityOutputReference;
    get privateNetworkOnly(): cdktf.IResolvable;
}
export interface DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks {
}
export declare function dataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksToTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks): any;
export declare function dataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks): any;
export declare class DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecks | undefined);
    get okStatus(): string[];
    get path(): string;
}
export interface DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheck {
}
export declare function dataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckToTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheck): any;
export declare function dataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheck): any;
export declare class DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheck | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheck | undefined);
    get healthyThreshold(): number;
    private _httpHealthChecks;
    get httpHealthChecks(): DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckHttpHealthChecksOutputReference;
    get interval(): string;
    get intervalJitter(): string;
    get timeout(): string;
    get unhealthyThreshold(): number;
}
export interface DataStackitApplicationLoadBalancerTargetPoolsTargets {
}
export declare function dataStackitApplicationLoadBalancerTargetPoolsTargetsToTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsTargets): any;
export declare function dataStackitApplicationLoadBalancerTargetPoolsTargetsToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsTargets): any;
export declare class DataStackitApplicationLoadBalancerTargetPoolsTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerTargetPoolsTargets | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetPoolsTargets | undefined);
    get displayName(): string;
    get ip(): string;
}
export declare class DataStackitApplicationLoadBalancerTargetPoolsTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerTargetPoolsTargetsOutputReference;
}
export interface DataStackitApplicationLoadBalancerTargetPoolsTlsConfig {
}
export declare function dataStackitApplicationLoadBalancerTargetPoolsTlsConfigToTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsTlsConfig): any;
export declare function dataStackitApplicationLoadBalancerTargetPoolsTlsConfigToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetPoolsTlsConfig): any;
export declare class DataStackitApplicationLoadBalancerTargetPoolsTlsConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerTargetPoolsTlsConfig | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetPoolsTlsConfig | undefined);
    get customCa(): string;
    get enabled(): cdktf.IResolvable;
    get skipCertificateValidation(): cdktf.IResolvable;
}
export interface DataStackitApplicationLoadBalancerTargetPools {
}
export declare function dataStackitApplicationLoadBalancerTargetPoolsToTerraform(struct?: DataStackitApplicationLoadBalancerTargetPools): any;
export declare function dataStackitApplicationLoadBalancerTargetPoolsToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetPools): any;
export declare class DataStackitApplicationLoadBalancerTargetPoolsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitApplicationLoadBalancerTargetPools | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetPools | undefined);
    private _activeHealthCheck;
    get activeHealthCheck(): DataStackitApplicationLoadBalancerTargetPoolsActiveHealthCheckOutputReference;
    get name(): string;
    get targetPort(): number;
    private _targets;
    get targets(): DataStackitApplicationLoadBalancerTargetPoolsTargetsList;
    private _tlsConfig;
    get tlsConfig(): DataStackitApplicationLoadBalancerTargetPoolsTlsConfigOutputReference;
}
export declare class DataStackitApplicationLoadBalancerTargetPoolsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitApplicationLoadBalancerTargetPoolsOutputReference;
}
export interface DataStackitApplicationLoadBalancerTargetSecurityGroup {
}
export declare function dataStackitApplicationLoadBalancerTargetSecurityGroupToTerraform(struct?: DataStackitApplicationLoadBalancerTargetSecurityGroup): any;
export declare function dataStackitApplicationLoadBalancerTargetSecurityGroupToHclTerraform(struct?: DataStackitApplicationLoadBalancerTargetSecurityGroup): any;
export declare class DataStackitApplicationLoadBalancerTargetSecurityGroupOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitApplicationLoadBalancerTargetSecurityGroup | undefined;
    set internalValue(value: DataStackitApplicationLoadBalancerTargetSecurityGroup | undefined);
    get id(): string;
    get name(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/application_load_balancer stackit_application_load_balancer}
*/
export declare class DataStackitApplicationLoadBalancer extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_application_load_balancer";
    /**
    * Generates CDKTF code for importing a DataStackitApplicationLoadBalancer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitApplicationLoadBalancer to import
    * @param importFromId The id of the existing DataStackitApplicationLoadBalancer that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/application_load_balancer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitApplicationLoadBalancer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/application_load_balancer stackit_application_load_balancer} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitApplicationLoadBalancerConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitApplicationLoadBalancerConfig);
    get disableTargetSecurityGroupAssignment(): cdktf.IResolvable;
    private _errors;
    get errors(): DataStackitApplicationLoadBalancerErrorsList;
    get externalAddress(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    private _listeners;
    get listeners(): DataStackitApplicationLoadBalancerListenersList;
    private _loadBalancerSecurityGroup;
    get loadBalancerSecurityGroup(): DataStackitApplicationLoadBalancerLoadBalancerSecurityGroupOutputReference;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networks;
    get networks(): DataStackitApplicationLoadBalancerNetworksList;
    private _options;
    get options(): DataStackitApplicationLoadBalancerOptionsOutputReference;
    get planId(): string;
    get privateAddress(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get region(): string;
    private _targetPools;
    get targetPools(): DataStackitApplicationLoadBalancerTargetPoolsList;
    private _targetSecurityGroup;
    get targetSecurityGroup(): DataStackitApplicationLoadBalancerTargetSecurityGroupOutputReference;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
