import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitNetworkAreaRegionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region#network_area_id DataStackitNetworkAreaRegion#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region#organization_id DataStackitNetworkAreaRegion#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region#region DataStackitNetworkAreaRegion#region}
    */
    readonly region?: string;
}
export interface DataStackitNetworkAreaRegionIpv4NetworkRanges {
}
export declare function dataStackitNetworkAreaRegionIpv4NetworkRangesToTerraform(struct?: DataStackitNetworkAreaRegionIpv4NetworkRanges): any;
export declare function dataStackitNetworkAreaRegionIpv4NetworkRangesToHclTerraform(struct?: DataStackitNetworkAreaRegionIpv4NetworkRanges): any;
export declare class DataStackitNetworkAreaRegionIpv4NetworkRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitNetworkAreaRegionIpv4NetworkRanges | undefined;
    set internalValue(value: DataStackitNetworkAreaRegionIpv4NetworkRanges | undefined);
    get networkRangeId(): string;
    get prefix(): string;
}
export declare class DataStackitNetworkAreaRegionIpv4NetworkRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitNetworkAreaRegionIpv4NetworkRangesOutputReference;
}
export interface DataStackitNetworkAreaRegionIpv4 {
}
export declare function dataStackitNetworkAreaRegionIpv4ToTerraform(struct?: DataStackitNetworkAreaRegionIpv4): any;
export declare function dataStackitNetworkAreaRegionIpv4ToHclTerraform(struct?: DataStackitNetworkAreaRegionIpv4): any;
export declare class DataStackitNetworkAreaRegionIpv4OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitNetworkAreaRegionIpv4 | undefined;
    set internalValue(value: DataStackitNetworkAreaRegionIpv4 | undefined);
    get defaultNameservers(): string[];
    get defaultPrefixLength(): number;
    get maxPrefixLength(): number;
    get minPrefixLength(): number;
    private _networkRanges;
    get networkRanges(): DataStackitNetworkAreaRegionIpv4NetworkRangesList;
    get transferNetwork(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region stackit_network_area_region}
*/
export declare class DataStackitNetworkAreaRegion extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_network_area_region";
    /**
    * Generates CDKTF code for importing a DataStackitNetworkAreaRegion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitNetworkAreaRegion to import
    * @param importFromId The id of the existing DataStackitNetworkAreaRegion that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitNetworkAreaRegion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/network_area_region stackit_network_area_region} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitNetworkAreaRegionConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitNetworkAreaRegionConfig);
    get id(): string;
    private _ipv4;
    get ipv4(): DataStackitNetworkAreaRegionIpv4OutputReference;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
