import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitLogmeInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the LogMe instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/logme_instance#instance_id DataStackitLogmeInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/logme_instance#project_id DataStackitLogmeInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitLogmeInstanceParameters {
}
export declare function dataStackitLogmeInstanceParametersToTerraform(struct?: DataStackitLogmeInstanceParameters): any;
export declare function dataStackitLogmeInstanceParametersToHclTerraform(struct?: DataStackitLogmeInstanceParameters): any;
export declare class DataStackitLogmeInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitLogmeInstanceParameters | undefined;
    set internalValue(value: DataStackitLogmeInstanceParameters | undefined);
    get enableMonitoring(): cdktf.IResolvable;
    get fluentdTcp(): number;
    get fluentdTls(): number;
    get fluentdTlsCiphers(): string;
    get fluentdTlsMaxVersion(): string;
    get fluentdTlsMinVersion(): string;
    get fluentdTlsVersion(): string;
    get fluentdUdp(): number;
    get graphite(): string;
    get ismDeletionAfter(): string;
    get ismJitter(): number;
    get ismJobInterval(): number;
    get javaHeapspace(): number;
    get javaMaxmetaspace(): number;
    get maxDiskThreshold(): number;
    get metricsFrequency(): number;
    get metricsPrefix(): string;
    get monitoringInstanceId(): string;
    get opensearchTlsCiphers(): string[];
    get opensearchTlsProtocols(): string[];
    get sgwAcl(): string;
    get syslog(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/logme_instance stackit_logme_instance}
*/
export declare class DataStackitLogmeInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_logme_instance";
    /**
    * Generates CDKTF code for importing a DataStackitLogmeInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitLogmeInstance to import
    * @param importFromId The id of the existing DataStackitLogmeInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/logme_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitLogmeInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/logme_instance stackit_logme_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitLogmeInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitLogmeInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _parameters;
    get parameters(): DataStackitLogmeInstanceParametersOutputReference;
    get planId(): string;
    get planName(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
