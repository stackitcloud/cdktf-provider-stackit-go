# `data_stackit_logme_instance`

Refer to the Terraform Registry for docs: [`data_stackit_logme_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/logme_instance).
