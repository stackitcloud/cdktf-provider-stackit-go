import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SqlserverflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Access Control List (ACL) for the SQLServer Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#acl SqlserverflexInstance#acl}
    */
    readonly acl?: string[];
    /**
    * The backup schedule. Should follow the cron scheduling system format (e.g. "0 0 * * *")
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#backup_schedule SqlserverflexInstance#backup_schedule}
    */
    readonly backupSchedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#flavor SqlserverflexInstance#flavor}
    */
    readonly flavor: SqlserverflexInstanceFlavor;
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#name SqlserverflexInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#options SqlserverflexInstance#options}
    */
    readonly options?: SqlserverflexInstanceOptions;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#project_id SqlserverflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#region SqlserverflexInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#storage SqlserverflexInstance#storage}
    */
    readonly storage?: SqlserverflexInstanceStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#version SqlserverflexInstance#version}
    */
    readonly version?: string;
}
export interface SqlserverflexInstanceFlavor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#cpu SqlserverflexInstance#cpu}
    */
    readonly cpu: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#ram SqlserverflexInstance#ram}
    */
    readonly ram: number;
}
export declare function sqlserverflexInstanceFlavorToTerraform(struct?: SqlserverflexInstanceFlavor | cdktf.IResolvable): any;
export declare function sqlserverflexInstanceFlavorToHclTerraform(struct?: SqlserverflexInstanceFlavor | cdktf.IResolvable): any;
export declare class SqlserverflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlserverflexInstanceFlavor | cdktf.IResolvable | undefined;
    set internalValue(value: SqlserverflexInstanceFlavor | cdktf.IResolvable | undefined);
    private _cpu?;
    get cpu(): number;
    set cpu(value: number);
    get cpuInput(): number | undefined;
    get description(): string;
    get id(): string;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
}
export interface SqlserverflexInstanceOptions {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#retention_days SqlserverflexInstance#retention_days}
    */
    readonly retentionDays?: number;
}
export declare function sqlserverflexInstanceOptionsToTerraform(struct?: SqlserverflexInstanceOptions | cdktf.IResolvable): any;
export declare function sqlserverflexInstanceOptionsToHclTerraform(struct?: SqlserverflexInstanceOptions | cdktf.IResolvable): any;
export declare class SqlserverflexInstanceOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlserverflexInstanceOptions | cdktf.IResolvable | undefined;
    set internalValue(value: SqlserverflexInstanceOptions | cdktf.IResolvable | undefined);
    get edition(): string;
    private _retentionDays?;
    get retentionDays(): number;
    set retentionDays(value: number);
    resetRetentionDays(): void;
    get retentionDaysInput(): number | undefined;
}
export interface SqlserverflexInstanceStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#class SqlserverflexInstance#class}
    */
    readonly class?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#size SqlserverflexInstance#size}
    */
    readonly size?: number;
}
export declare function sqlserverflexInstanceStorageToTerraform(struct?: SqlserverflexInstanceStorage | cdktf.IResolvable): any;
export declare function sqlserverflexInstanceStorageToHclTerraform(struct?: SqlserverflexInstanceStorage | cdktf.IResolvable): any;
export declare class SqlserverflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SqlserverflexInstanceStorage | cdktf.IResolvable | undefined;
    set internalValue(value: SqlserverflexInstanceStorage | cdktf.IResolvable | undefined);
    private _class?;
    get class(): string;
    set class(value: string);
    resetClass(): void;
    get classInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    resetSize(): void;
    get sizeInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance stackit_sqlserverflex_instance}
*/
export declare class SqlserverflexInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_sqlserverflex_instance";
    /**
    * Generates CDKTF code for importing a SqlserverflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SqlserverflexInstance to import
    * @param importFromId The id of the existing SqlserverflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SqlserverflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/sqlserverflex_instance stackit_sqlserverflex_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SqlserverflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: SqlserverflexInstanceConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    resetAcl(): void;
    get aclInput(): string[] | undefined;
    private _backupSchedule?;
    get backupSchedule(): string;
    set backupSchedule(value: string);
    resetBackupSchedule(): void;
    get backupScheduleInput(): string | undefined;
    private _flavor;
    get flavor(): SqlserverflexInstanceFlavorOutputReference;
    putFlavor(value: SqlserverflexInstanceFlavor): void;
    get flavorInput(): cdktf.IResolvable | SqlserverflexInstanceFlavor | undefined;
    get id(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options;
    get options(): SqlserverflexInstanceOptionsOutputReference;
    putOptions(value: SqlserverflexInstanceOptions): void;
    resetOptions(): void;
    get optionsInput(): cdktf.IResolvable | SqlserverflexInstanceOptions | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicas(): number;
    private _storage;
    get storage(): SqlserverflexInstanceStorageOutputReference;
    putStorage(value: SqlserverflexInstanceStorage): void;
    resetStorage(): void;
    get storageInput(): cdktf.IResolvable | SqlserverflexInstanceStorage | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
