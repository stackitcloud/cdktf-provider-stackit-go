# `stackit_sqlserverflex_instance`

Refer to the Terraform Registry for docs: [`stackit_sqlserverflex_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/sqlserverflex_instance).
