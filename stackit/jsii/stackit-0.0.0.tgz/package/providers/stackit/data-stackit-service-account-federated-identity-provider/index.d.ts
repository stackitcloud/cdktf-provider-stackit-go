import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServiceAccountFederatedIdentityProviderConfig extends cdktf.TerraformMetaArguments {
    /**
    * The unique identifier for the federated identity provider associated with the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider#federation_id DataStackitServiceAccountFederatedIdentityProvider#federation_id}
    */
    readonly federationId: string;
    /**
    * The STACKIT project ID associated with the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider#project_id DataStackitServiceAccountFederatedIdentityProvider#project_id}
    */
    readonly projectId: string;
    /**
    * The email address associated with the service account, used for account identification and communication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider#service_account_email DataStackitServiceAccountFederatedIdentityProvider#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export interface DataStackitServiceAccountFederatedIdentityProviderAssertions {
}
export declare function dataStackitServiceAccountFederatedIdentityProviderAssertionsToTerraform(struct?: DataStackitServiceAccountFederatedIdentityProviderAssertions): any;
export declare function dataStackitServiceAccountFederatedIdentityProviderAssertionsToHclTerraform(struct?: DataStackitServiceAccountFederatedIdentityProviderAssertions): any;
export declare class DataStackitServiceAccountFederatedIdentityProviderAssertionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitServiceAccountFederatedIdentityProviderAssertions | undefined;
    set internalValue(value: DataStackitServiceAccountFederatedIdentityProviderAssertions | undefined);
    get item(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataStackitServiceAccountFederatedIdentityProviderAssertionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitServiceAccountFederatedIdentityProviderAssertionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider stackit_service_account_federated_identity_provider}
*/
export declare class DataStackitServiceAccountFederatedIdentityProvider extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_service_account_federated_identity_provider";
    /**
    * Generates CDKTF code for importing a DataStackitServiceAccountFederatedIdentityProvider resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServiceAccountFederatedIdentityProvider to import
    * @param importFromId The id of the existing DataStackitServiceAccountFederatedIdentityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServiceAccountFederatedIdentityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/service_account_federated_identity_provider stackit_service_account_federated_identity_provider} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServiceAccountFederatedIdentityProviderConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServiceAccountFederatedIdentityProviderConfig);
    private _assertions;
    get assertions(): DataStackitServiceAccountFederatedIdentityProviderAssertionsList;
    private _federationId?;
    get federationId(): string;
    set federationId(value: string);
    get federationIdInput(): string | undefined;
    get id(): string;
    get issuer(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
