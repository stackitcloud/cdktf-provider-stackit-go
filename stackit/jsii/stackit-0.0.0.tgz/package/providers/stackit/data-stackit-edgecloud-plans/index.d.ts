import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitEdgecloudPlansConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID the Plans belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/edgecloud_plans#project_id DataStackitEdgecloudPlans#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitEdgecloudPlansPlans {
}
export declare function dataStackitEdgecloudPlansPlansToTerraform(struct?: DataStackitEdgecloudPlansPlans): any;
export declare function dataStackitEdgecloudPlansPlansToHclTerraform(struct?: DataStackitEdgecloudPlansPlans): any;
export declare class DataStackitEdgecloudPlansPlansOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitEdgecloudPlansPlans | undefined;
    set internalValue(value: DataStackitEdgecloudPlansPlans | undefined);
    get description(): string;
    get id(): string;
    get maxEdgeHosts(): number;
    get minEdgeHosts(): number;
    get name(): string;
}
export declare class DataStackitEdgecloudPlansPlansList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitEdgecloudPlansPlansOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/edgecloud_plans stackit_edgecloud_plans}
*/
export declare class DataStackitEdgecloudPlans extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_edgecloud_plans";
    /**
    * Generates CDKTF code for importing a DataStackitEdgecloudPlans resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitEdgecloudPlans to import
    * @param importFromId The id of the existing DataStackitEdgecloudPlans that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/edgecloud_plans#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitEdgecloudPlans to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/edgecloud_plans stackit_edgecloud_plans} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitEdgecloudPlansConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitEdgecloudPlansConfig);
    get id(): string;
    private _plans;
    get plans(): DataStackitEdgecloudPlansPlansList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
