# `data_stackit_edgecloud_plans`

Refer to the Terraform Registry for docs: [`data_stackit_edgecloud_plans`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/edgecloud_plans).
