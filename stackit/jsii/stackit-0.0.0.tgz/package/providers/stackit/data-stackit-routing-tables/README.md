# `data_stackit_routing_tables`

Refer to the Terraform Registry for docs: [`data_stackit_routing_tables`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/data-sources/routing_tables).
