import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitRoutingTablesConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables#network_area_id DataStackitRoutingTables#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables#organization_id DataStackitRoutingTables#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables#region DataStackitRoutingTables#region}
    */
    readonly region?: string;
}
export interface DataStackitRoutingTablesItems {
}
export declare function dataStackitRoutingTablesItemsToTerraform(struct?: DataStackitRoutingTablesItems): any;
export declare function dataStackitRoutingTablesItemsToHclTerraform(struct?: DataStackitRoutingTablesItems): any;
export declare class DataStackitRoutingTablesItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitRoutingTablesItems | undefined;
    set internalValue(value: DataStackitRoutingTablesItems | undefined);
    get createdAt(): string;
    get default(): cdktf.IResolvable;
    get description(): string;
    get dynamicRoutes(): cdktf.IResolvable;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    get routingTableId(): string;
    get systemRoutes(): cdktf.IResolvable;
    get updatedAt(): string;
}
export declare class DataStackitRoutingTablesItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitRoutingTablesItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables stackit_routing_tables}
*/
export declare class DataStackitRoutingTables extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_routing_tables";
    /**
    * Generates CDKTF code for importing a DataStackitRoutingTables resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitRoutingTables to import
    * @param importFromId The id of the existing DataStackitRoutingTables that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitRoutingTables to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/routing_tables stackit_routing_tables} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitRoutingTablesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitRoutingTablesConfig);
    get id(): string;
    private _items;
    get items(): DataStackitRoutingTablesItemsList;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
