# `stackit_kms_wrapping_key`

Refer to the Terraform Registry for docs: [`stackit_kms_wrapping_key`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/kms_wrapping_key).
