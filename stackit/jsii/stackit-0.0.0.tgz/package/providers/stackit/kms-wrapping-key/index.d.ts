import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KmsWrappingKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access scope of the key. Default is `PUBLIC`. Possible values are: `PUBLIC`, `SNA`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#access_scope KmsWrappingKey#access_scope}
    */
    readonly accessScope?: string;
    /**
    * The wrapping algorithm used to wrap the key to import. Possible values are: `rsa_2048_oaep_sha256`, `rsa_3072_oaep_sha256`, `rsa_4096_oaep_sha256`, `rsa_4096_oaep_sha512`, `rsa_2048_oaep_sha256_aes_256_key_wrap`, `rsa_3072_oaep_sha256_aes_256_key_wrap`, `rsa_4096_oaep_sha256_aes_256_key_wrap`, `rsa_4096_oaep_sha512_aes_256_key_wrap`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#algorithm KmsWrappingKey#algorithm}
    */
    readonly algorithm: string;
    /**
    * A user chosen description to distinguish multiple wrapping keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#description KmsWrappingKey#description}
    */
    readonly description?: string;
    /**
    * The display name to distinguish multiple wrapping keys.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#display_name KmsWrappingKey#display_name}
    */
    readonly displayName: string;
    /**
    * The ID of the associated keyring
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#keyring_id KmsWrappingKey#keyring_id}
    */
    readonly keyringId: string;
    /**
    * STACKIT project ID to which the keyring is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#project_id KmsWrappingKey#project_id}
    */
    readonly projectId: string;
    /**
    * The underlying system that is responsible for protecting the key material. Possible values are: `software`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#protection KmsWrappingKey#protection}
    */
    readonly protection: string;
    /**
    * The purpose for which the key will be used. Possible values are: `wrap_symmetric_key`, `wrap_asymmetric_key`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#purpose KmsWrappingKey#purpose}
    */
    readonly purpose: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#region KmsWrappingKey#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key stackit_kms_wrapping_key}
*/
export declare class KmsWrappingKey extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_kms_wrapping_key";
    /**
    * Generates CDKTF code for importing a KmsWrappingKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmsWrappingKey to import
    * @param importFromId The id of the existing KmsWrappingKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmsWrappingKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/kms_wrapping_key stackit_kms_wrapping_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmsWrappingKeyConfig
    */
    constructor(scope: Construct, id: string, config: KmsWrappingKeyConfig);
    private _accessScope?;
    get accessScope(): string;
    set accessScope(value: string);
    resetAccessScope(): void;
    get accessScopeInput(): string | undefined;
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get expiresAt(): string;
    get id(): string;
    private _keyringId?;
    get keyringId(): string;
    set keyringId(value: string);
    get keyringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protection?;
    get protection(): string;
    set protection(value: string);
    get protectionInput(): string | undefined;
    get publicKey(): string;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    get purposeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get wrappingKeyId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
