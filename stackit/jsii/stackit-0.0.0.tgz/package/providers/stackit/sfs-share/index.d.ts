import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SfsShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the Share Export Policy to use in the Share.
    * Note that if this is set to an empty string, the Share can only be mounted in read only by
    * clients with IPs matching the IP ACL of the Resource Pool hosting this Share.
    * You can also assign a Share Export Policy after creating the Share
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#export_policy SfsShare#export_policy}
    */
    readonly exportPolicy: string;
    /**
    * Name of the share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#name SfsShare#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the share is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#project_id SfsShare#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#region SfsShare#region}
    */
    readonly region?: string;
    /**
    * The ID of the resource pool for the SFS share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#resource_pool_id SfsShare#resource_pool_id}
    */
    readonly resourcePoolId: string;
    /**
    * Space hard limit for the Share.
    * 				If zero, the Share will have access to the full space of the Resource Pool it lives in.
    * 				(unit: gigabytes)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#space_hard_limit_gigabytes SfsShare#space_hard_limit_gigabytes}
    */
    readonly spaceHardLimitGigabytes: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share stackit_sfs_share}
*/
export declare class SfsShare extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_sfs_share";
    /**
    * Generates CDKTF code for importing a SfsShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SfsShare to import
    * @param importFromId The id of the existing SfsShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SfsShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_share stackit_sfs_share} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SfsShareConfig
    */
    constructor(scope: Construct, id: string, config: SfsShareConfig);
    private _exportPolicy?;
    get exportPolicy(): string;
    set exportPolicy(value: string);
    get exportPolicyInput(): string | undefined;
    get id(): string;
    get mountPath(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcePoolId?;
    get resourcePoolId(): string;
    set resourcePoolId(value: string);
    get resourcePoolIdInput(): string | undefined;
    get shareId(): string;
    private _spaceHardLimitGigabytes?;
    get spaceHardLimitGigabytes(): number;
    set spaceHardLimitGigabytes(value: number);
    get spaceHardLimitGigabytesInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
