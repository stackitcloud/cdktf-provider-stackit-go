import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAuthorizationOrganizationCustomRoleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Resource to add the custom role to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/authorization_organization_custom_role#resource_id DataStackitAuthorizationOrganizationCustomRole#resource_id}
    */
    readonly resourceId: string;
    /**
    * The ID of the role.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/authorization_organization_custom_role#role_id DataStackitAuthorizationOrganizationCustomRole#role_id}
    */
    readonly roleId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/authorization_organization_custom_role stackit_authorization_organization_custom_role}
*/
export declare class DataStackitAuthorizationOrganizationCustomRole extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_authorization_organization_custom_role";
    /**
    * Generates CDKTF code for importing a DataStackitAuthorizationOrganizationCustomRole resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAuthorizationOrganizationCustomRole to import
    * @param importFromId The id of the existing DataStackitAuthorizationOrganizationCustomRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/authorization_organization_custom_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAuthorizationOrganizationCustomRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/authorization_organization_custom_role stackit_authorization_organization_custom_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAuthorizationOrganizationCustomRoleConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAuthorizationOrganizationCustomRoleConfig);
    get description(): string;
    get id(): string;
    get name(): string;
    get permissions(): string[];
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
