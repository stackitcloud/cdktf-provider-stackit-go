import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSecurityGroupRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the security group rule is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule#project_id DataStackitSecurityGroupRule#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule#region DataStackitSecurityGroupRule#region}
    */
    readonly region?: string;
    /**
    * The security group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule#security_group_id DataStackitSecurityGroupRule#security_group_id}
    */
    readonly securityGroupId: string;
    /**
    * The security group rule ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule#security_group_rule_id DataStackitSecurityGroupRule#security_group_rule_id}
    */
    readonly securityGroupRuleId: string;
}
export interface DataStackitSecurityGroupRuleIcmpParameters {
}
export declare function dataStackitSecurityGroupRuleIcmpParametersToTerraform(struct?: DataStackitSecurityGroupRuleIcmpParameters): any;
export declare function dataStackitSecurityGroupRuleIcmpParametersToHclTerraform(struct?: DataStackitSecurityGroupRuleIcmpParameters): any;
export declare class DataStackitSecurityGroupRuleIcmpParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSecurityGroupRuleIcmpParameters | undefined;
    set internalValue(value: DataStackitSecurityGroupRuleIcmpParameters | undefined);
    get code(): number;
    get type(): number;
}
export interface DataStackitSecurityGroupRulePortRange {
}
export declare function dataStackitSecurityGroupRulePortRangeToTerraform(struct?: DataStackitSecurityGroupRulePortRange): any;
export declare function dataStackitSecurityGroupRulePortRangeToHclTerraform(struct?: DataStackitSecurityGroupRulePortRange): any;
export declare class DataStackitSecurityGroupRulePortRangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSecurityGroupRulePortRange | undefined;
    set internalValue(value: DataStackitSecurityGroupRulePortRange | undefined);
    get max(): number;
    get min(): number;
}
export interface DataStackitSecurityGroupRuleProtocol {
}
export declare function dataStackitSecurityGroupRuleProtocolToTerraform(struct?: DataStackitSecurityGroupRuleProtocol): any;
export declare function dataStackitSecurityGroupRuleProtocolToHclTerraform(struct?: DataStackitSecurityGroupRuleProtocol): any;
export declare class DataStackitSecurityGroupRuleProtocolOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitSecurityGroupRuleProtocol | undefined;
    set internalValue(value: DataStackitSecurityGroupRuleProtocol | undefined);
    get name(): string;
    get number(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule stackit_security_group_rule}
*/
export declare class DataStackitSecurityGroupRule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_security_group_rule";
    /**
    * Generates CDKTF code for importing a DataStackitSecurityGroupRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSecurityGroupRule to import
    * @param importFromId The id of the existing DataStackitSecurityGroupRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSecurityGroupRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/security_group_rule stackit_security_group_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSecurityGroupRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSecurityGroupRuleConfig);
    get description(): string;
    get direction(): string;
    get etherType(): string;
    private _icmpParameters;
    get icmpParameters(): DataStackitSecurityGroupRuleIcmpParametersOutputReference;
    get id(): string;
    get ipRange(): string;
    private _portRange;
    get portRange(): DataStackitSecurityGroupRulePortRangeOutputReference;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protocol;
    get protocol(): DataStackitSecurityGroupRuleProtocolOutputReference;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get remoteSecurityGroupId(): string;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    private _securityGroupRuleId?;
    get securityGroupRuleId(): string;
    set securityGroupRuleId(value: string);
    get securityGroupRuleIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
