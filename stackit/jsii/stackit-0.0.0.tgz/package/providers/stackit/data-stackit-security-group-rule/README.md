# `data_stackit_security_group_rule`

Refer to the Terraform Registry for docs: [`data_stackit_security_group_rule`](https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/security_group_rule).
