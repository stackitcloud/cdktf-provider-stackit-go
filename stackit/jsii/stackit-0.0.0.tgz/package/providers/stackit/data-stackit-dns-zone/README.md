# `data_stackit_dns_zone`

Refer to the Terraform Registry for docs: [`data_stackit_dns_zone`](https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/data-sources/dns_zone).
