import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitDnsZoneConfig extends cdktf.TerraformMetaArguments {
    /**
    * The zone name. E.g. `example.com` (must not end with a trailing dot).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#dns_name DataStackitDnsZone#dns_name}
    */
    readonly dnsName?: string;
    /**
    * STACKIT project ID to which the dns zone is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#project_id DataStackitDnsZone#project_id}
    */
    readonly projectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#timeouts DataStackitDnsZone#timeouts}
    */
    readonly timeouts?: DataStackitDnsZoneTimeouts;
    /**
    * The zone ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#zone_id DataStackitDnsZone#zone_id}
    */
    readonly zoneId?: string;
}
export interface DataStackitDnsZoneTimeouts {
    /**
    * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#read DataStackitDnsZone#read}
    */
    readonly read?: string;
}
export declare function dataStackitDnsZoneTimeoutsToTerraform(struct?: DataStackitDnsZoneTimeouts | cdktf.IResolvable): any;
export declare function dataStackitDnsZoneTimeoutsToHclTerraform(struct?: DataStackitDnsZoneTimeouts | cdktf.IResolvable): any;
export declare class DataStackitDnsZoneTimeoutsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitDnsZoneTimeouts | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitDnsZoneTimeouts | cdktf.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone stackit_dns_zone}
*/
export declare class DataStackitDnsZone extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_dns_zone";
    /**
    * Generates CDKTF code for importing a DataStackitDnsZone resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitDnsZone to import
    * @param importFromId The id of the existing DataStackitDnsZone that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitDnsZone to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/dns_zone stackit_dns_zone} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitDnsZoneConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitDnsZoneConfig);
    get acl(): string;
    get active(): cdktf.IResolvable;
    get contactEmail(): string;
    get defaultTtl(): number;
    get description(): string;
    private _dnsName?;
    get dnsName(): string;
    set dnsName(value: string);
    resetDnsName(): void;
    get dnsNameInput(): string | undefined;
    get expireTime(): number;
    get id(): string;
    get isReverseZone(): cdktf.IResolvable;
    get name(): string;
    get negativeCache(): number;
    get primaries(): string[];
    get primaryNameServer(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get recordCount(): number;
    get refreshTime(): number;
    get retryTime(): number;
    get serialNumber(): number;
    get state(): string;
    private _timeouts;
    get timeouts(): DataStackitDnsZoneTimeoutsOutputReference;
    putTimeouts(value: DataStackitDnsZoneTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktf.IResolvable | DataStackitDnsZoneTimeouts | undefined;
    get type(): string;
    get visibility(): string;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    resetZoneId(): void;
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
