# `data_stackit_kms_keyring`

Refer to the Terraform Registry for docs: [`data_stackit_kms_keyring`](https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/kms_keyring).
