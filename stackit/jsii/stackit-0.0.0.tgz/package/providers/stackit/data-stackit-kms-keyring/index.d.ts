import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitKmsKeyringConfig extends cdktf.TerraformMetaArguments {
    /**
    * An auto generated unique id which identifies the keyring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring#keyring_id DataStackitKmsKeyring#keyring_id}
    */
    readonly keyringId: string;
    /**
    * STACKIT project ID to which the keyring is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring#project_id DataStackitKmsKeyring#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring#region DataStackitKmsKeyring#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring stackit_kms_keyring}
*/
export declare class DataStackitKmsKeyring extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_kms_keyring";
    /**
    * Generates CDKTF code for importing a DataStackitKmsKeyring resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitKmsKeyring to import
    * @param importFromId The id of the existing DataStackitKmsKeyring that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitKmsKeyring to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.96.0/docs/data-sources/kms_keyring stackit_kms_keyring} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitKmsKeyringConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitKmsKeyringConfig);
    get description(): string;
    get displayName(): string;
    get id(): string;
    private _keyringId?;
    get keyringId(): string;
    set keyringId(value: string);
    get keyringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
