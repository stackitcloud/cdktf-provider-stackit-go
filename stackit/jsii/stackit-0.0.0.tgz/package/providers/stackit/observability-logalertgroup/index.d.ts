import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObservabilityLogalertgroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability instance ID to which the log alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#instance_id ObservabilityLogalertgroup#instance_id}
    */
    readonly instanceId: string;
    /**
    * Specifies the frequency at which rules within the group are evaluated. The interval must be at least 60 seconds and defaults to 60 seconds if not set. Supported formats include hours, minutes, and seconds, either singly or in combination. Examples of valid formats are: '5h30m40s', '5h', '5h30m', '60m', and '60s'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#interval ObservabilityLogalertgroup#interval}
    */
    readonly interval?: string;
    /**
    * The name of the log alert group. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#name ObservabilityLogalertgroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the log alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#project_id ObservabilityLogalertgroup#project_id}
    */
    readonly projectId: string;
    /**
    * Rules for the log alert group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#rules ObservabilityLogalertgroup#rules}
    */
    readonly rules: ObservabilityLogalertgroupRules[] | cdktf.IResolvable;
}
export interface ObservabilityLogalertgroupRules {
    /**
    * The name of the alert rule. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#alert ObservabilityLogalertgroup#alert}
    */
    readonly alert: string;
    /**
    * A map of key:value. Annotations to add or overwrite for each alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#annotations ObservabilityLogalertgroup#annotations}
    */
    readonly annotations?: {
        [key: string]: string;
    };
    /**
    * The LogQL expression to evaluate. Every evaluation cycle this is evaluated at the current time, and all resultant time series become pending/firing alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#expression ObservabilityLogalertgroup#expression}
    */
    readonly expression: string;
    /**
    * Alerts are considered firing once they have been returned for this long. Alerts which have not yet fired for long enough are considered pending. Default is 0s
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#for ObservabilityLogalertgroup#for}
    */
    readonly for?: string;
    /**
    * A map of key:value. Labels to add or overwrite for each alert
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#labels ObservabilityLogalertgroup#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
}
export declare function observabilityLogalertgroupRulesToTerraform(struct?: ObservabilityLogalertgroupRules | cdktf.IResolvable): any;
export declare function observabilityLogalertgroupRulesToHclTerraform(struct?: ObservabilityLogalertgroupRules | cdktf.IResolvable): any;
export declare class ObservabilityLogalertgroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityLogalertgroupRules | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityLogalertgroupRules | cdktf.IResolvable | undefined);
    private _alert?;
    get alert(): string;
    set alert(value: string);
    get alertInput(): string | undefined;
    private _annotations?;
    get annotations(): {
        [key: string]: string;
    };
    set annotations(value: {
        [key: string]: string;
    });
    resetAnnotations(): void;
    get annotationsInput(): {
        [key: string]: string;
    } | undefined;
    private _expression?;
    get expression(): string;
    set expression(value: string);
    get expressionInput(): string | undefined;
    private _for?;
    get for(): string;
    set for(value: string);
    resetFor(): void;
    get forInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
}
export declare class ObservabilityLogalertgroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityLogalertgroupRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityLogalertgroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup stackit_observability_logalertgroup}
*/
export declare class ObservabilityLogalertgroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_observability_logalertgroup";
    /**
    * Generates CDKTF code for importing a ObservabilityLogalertgroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityLogalertgroup to import
    * @param importFromId The id of the existing ObservabilityLogalertgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityLogalertgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/observability_logalertgroup stackit_observability_logalertgroup} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityLogalertgroupConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityLogalertgroupConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _interval?;
    get interval(): string;
    set interval(value: string);
    resetInterval(): void;
    get intervalInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rules;
    get rules(): ObservabilityLogalertgroupRulesList;
    putRules(value: ObservabilityLogalertgroupRules[] | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | ObservabilityLogalertgroupRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
