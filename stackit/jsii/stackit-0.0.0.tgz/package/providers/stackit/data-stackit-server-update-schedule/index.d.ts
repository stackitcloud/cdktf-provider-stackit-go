import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServerUpdateScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule#project_id DataStackitServerUpdateSchedule#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule#region DataStackitServerUpdateSchedule#region}
    */
    readonly region?: string;
    /**
    * Server ID for the update schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule#server_id DataStackitServerUpdateSchedule#server_id}
    */
    readonly serverId: string;
    /**
    * Update schedule ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule#update_schedule_id DataStackitServerUpdateSchedule#update_schedule_id}
    */
    readonly updateScheduleId: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule stackit_server_update_schedule}
*/
export declare class DataStackitServerUpdateSchedule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_server_update_schedule";
    /**
    * Generates CDKTF code for importing a DataStackitServerUpdateSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServerUpdateSchedule to import
    * @param importFromId The id of the existing DataStackitServerUpdateSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServerUpdateSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/server_update_schedule stackit_server_update_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServerUpdateScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServerUpdateScheduleConfig);
    get enabled(): cdktf.IResolvable;
    get id(): string;
    get maintenanceWindow(): number;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rrule(): string;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    private _updateScheduleId?;
    get updateScheduleId(): number;
    set updateScheduleId(value: number);
    get updateScheduleIdInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
