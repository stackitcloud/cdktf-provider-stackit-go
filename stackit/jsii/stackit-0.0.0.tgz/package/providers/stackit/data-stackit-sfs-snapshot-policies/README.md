# `data_stackit_sfs_snapshot_policies`

Refer to the Terraform Registry for docs: [`data_stackit_sfs_snapshot_policies`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/data-sources/sfs_snapshot_policies).
