import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsSnapshotPoliciesConfig extends cdktf.TerraformMetaArguments {
    /**
    * Filter snapshot policies by immutability. Possible values are: `all`, `immutable-only`, `mutable-only`. Defaults to `all`. This attribute is in beta, may have breaking changes in the future.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/sfs_snapshot_policies#immutable DataStackitSfsSnapshotPolicies#immutable}
    */
    readonly immutable?: string;
    /**
    * STACKIT project ID to which the snapshot policy is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/sfs_snapshot_policies#project_id DataStackitSfsSnapshotPolicies#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitSfsSnapshotPoliciesItemsSnapshotSchedules {
}
export declare function dataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesToTerraform(struct?: DataStackitSfsSnapshotPoliciesItemsSnapshotSchedules): any;
export declare function dataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesToHclTerraform(struct?: DataStackitSfsSnapshotPoliciesItemsSnapshotSchedules): any;
export declare class DataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSfsSnapshotPoliciesItemsSnapshotSchedules | undefined;
    set internalValue(value: DataStackitSfsSnapshotPoliciesItemsSnapshotSchedules | undefined);
    get createdAt(): string;
    get id(): string;
    get interval(): string;
    get name(): string;
    get prefix(): string;
    get retentionCount(): number;
    get retentionPeriod(): string;
}
export declare class DataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesOutputReference;
}
export interface DataStackitSfsSnapshotPoliciesItems {
}
export declare function dataStackitSfsSnapshotPoliciesItemsToTerraform(struct?: DataStackitSfsSnapshotPoliciesItems): any;
export declare function dataStackitSfsSnapshotPoliciesItemsToHclTerraform(struct?: DataStackitSfsSnapshotPoliciesItems): any;
export declare class DataStackitSfsSnapshotPoliciesItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSfsSnapshotPoliciesItems | undefined;
    set internalValue(value: DataStackitSfsSnapshotPoliciesItems | undefined);
    get comment(): string;
    get createdAt(): string;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    get name(): string;
    private _snapshotSchedules;
    get snapshotSchedules(): DataStackitSfsSnapshotPoliciesItemsSnapshotSchedulesList;
}
export declare class DataStackitSfsSnapshotPoliciesItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSfsSnapshotPoliciesItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/sfs_snapshot_policies stackit_sfs_snapshot_policies}
*/
export declare class DataStackitSfsSnapshotPolicies extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_snapshot_policies";
    /**
    * Generates CDKTF code for importing a DataStackitSfsSnapshotPolicies resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsSnapshotPolicies to import
    * @param importFromId The id of the existing DataStackitSfsSnapshotPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/sfs_snapshot_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsSnapshotPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/sfs_snapshot_policies stackit_sfs_snapshot_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsSnapshotPoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsSnapshotPoliciesConfig);
    get id(): string;
    private _immutable?;
    get immutable(): string;
    set immutable(value: string);
    resetImmutable(): void;
    get immutableInput(): string | undefined;
    private _items;
    get items(): DataStackitSfsSnapshotPoliciesItemsList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
