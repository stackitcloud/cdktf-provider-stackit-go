import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObjectstorageDefaultRetentionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The associated bucket's name. It must be DNS conform.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention#bucket_name DataStackitObjectstorageDefaultRetention#bucket_name}
    */
    readonly bucketName: string;
    /**
    * STACKIT Project ID to which the default-retention is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention#project_id DataStackitObjectstorageDefaultRetention#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention#region DataStackitObjectstorageDefaultRetention#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention stackit_objectstorage_default_retention}
*/
export declare class DataStackitObjectstorageDefaultRetention extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_objectstorage_default_retention";
    /**
    * Generates CDKTF code for importing a DataStackitObjectstorageDefaultRetention resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObjectstorageDefaultRetention to import
    * @param importFromId The id of the existing DataStackitObjectstorageDefaultRetention that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObjectstorageDefaultRetention to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/data-sources/objectstorage_default_retention stackit_objectstorage_default_retention} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObjectstorageDefaultRetentionConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObjectstorageDefaultRetentionConfig);
    private _bucketName?;
    get bucketName(): string;
    set bucketName(value: string);
    get bucketNameInput(): string | undefined;
    get days(): number;
    get id(): string;
    get mode(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
