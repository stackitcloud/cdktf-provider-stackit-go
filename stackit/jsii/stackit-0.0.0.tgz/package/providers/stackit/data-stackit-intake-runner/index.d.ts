import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitIntakeRunnerConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID to which the runner is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner#project_id DataStackitIntakeRunner#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner#region DataStackitIntakeRunner#region}
    */
    readonly region?: string;
    /**
    * The runner ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner#runner_id DataStackitIntakeRunner#runner_id}
    */
    readonly runnerId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner stackit_intake_runner}
*/
export declare class DataStackitIntakeRunner extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_intake_runner";
    /**
    * Generates CDKTF code for importing a DataStackitIntakeRunner resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitIntakeRunner to import
    * @param importFromId The id of the existing DataStackitIntakeRunner that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitIntakeRunner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/intake_runner stackit_intake_runner} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitIntakeRunnerConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitIntakeRunnerConfig);
    get createTime(): string;
    get description(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get maxMessageSizeKib(): number;
    get maxMessagesPerHour(): number;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runnerId?;
    get runnerId(): string;
    set runnerId(value: string);
    get runnerIdInput(): string | undefined;
    get uri(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
