# `data_stackit_intake_runner`

Refer to the Terraform Registry for docs: [`data_stackit_intake_runner`](https://registry.terraform.io/providers/stackitcloud/stackit/0.103.0/docs/data-sources/intake_runner).
