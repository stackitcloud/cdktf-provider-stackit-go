import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthorizationOrganizationRoleAssignmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Organization Resource to assign the role to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment#resource_id AuthorizationOrganizationRoleAssignment#resource_id}
    */
    readonly resourceId: string;
    /**
    * Role to be assigned. Available roles can be queried using stackit-cli: `stackit curl https://authorization.api.stackit.cloud/v2/permissions`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment#role AuthorizationOrganizationRoleAssignment#role}
    */
    readonly role: string;
    /**
    * Identifier of user, service account or client. Usually email address or name in case of clients. All letters must be lowercased.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment#subject AuthorizationOrganizationRoleAssignment#subject}
    */
    readonly subject: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment stackit_authorization_organization_role_assignment}
*/
export declare class AuthorizationOrganizationRoleAssignment extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_authorization_organization_role_assignment";
    /**
    * Generates CDKTF code for importing a AuthorizationOrganizationRoleAssignment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthorizationOrganizationRoleAssignment to import
    * @param importFromId The id of the existing AuthorizationOrganizationRoleAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthorizationOrganizationRoleAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_organization_role_assignment stackit_authorization_organization_role_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthorizationOrganizationRoleAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AuthorizationOrganizationRoleAssignmentConfig);
    get id(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
