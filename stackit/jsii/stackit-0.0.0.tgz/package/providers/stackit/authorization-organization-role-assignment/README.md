# `stackit_authorization_organization_role_assignment`

Refer to the Terraform Registry for docs: [`stackit_authorization_organization_role_assignment`](https://registry.terraform.io/providers/stackitcloud/stackit/0.116.0/docs/resources/authorization_organization_role_assignment).
