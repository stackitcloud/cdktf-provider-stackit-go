import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerBackupEnableConfig extends cdktf.TerraformMetaArguments {
    /**
    * The backup policy ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable#backup_policy_id ServerBackupEnable#backup_policy_id}
    */
    readonly backupPolicyId?: string;
    /**
    * STACKIT Project ID to which the server backup enable is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable#project_id ServerBackupEnable#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable#region ServerBackupEnable#region}
    */
    readonly region?: string;
    /**
    * Server ID to which the server backup enable is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable#server_id ServerBackupEnable#server_id}
    */
    readonly serverId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable stackit_server_backup_enable}
*/
export declare class ServerBackupEnable extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_backup_enable";
    /**
    * Generates CDKTF code for importing a ServerBackupEnable resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerBackupEnable to import
    * @param importFromId The id of the existing ServerBackupEnable that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerBackupEnable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_backup_enable stackit_server_backup_enable} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerBackupEnableConfig
    */
    constructor(scope: Construct, id: string, config: ServerBackupEnableConfig);
    private _backupPolicyId?;
    get backupPolicyId(): string;
    set backupPolicyId(value: string);
    resetBackupPolicyId(): void;
    get backupPolicyIdInput(): string | undefined;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
