import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkAreaRegionConfig extends cdktf.TerraformMetaArguments {
    /**
    * The regional IPv4 config of a network area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#ipv4 NetworkAreaRegion#ipv4}
    */
    readonly ipv4: NetworkAreaRegionIpv4;
    /**
    * The network area ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#network_area_id NetworkAreaRegion#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#organization_id NetworkAreaRegion#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#region NetworkAreaRegion#region}
    */
    readonly region?: string;
}
export interface NetworkAreaRegionIpv4NetworkRanges {
    /**
    * Classless Inter-Domain Routing (CIDR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#prefix NetworkAreaRegion#prefix}
    */
    readonly prefix: string;
}
export declare function networkAreaRegionIpv4NetworkRangesToTerraform(struct?: NetworkAreaRegionIpv4NetworkRanges | cdktf.IResolvable): any;
export declare function networkAreaRegionIpv4NetworkRangesToHclTerraform(struct?: NetworkAreaRegionIpv4NetworkRanges | cdktf.IResolvable): any;
export declare class NetworkAreaRegionIpv4NetworkRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkAreaRegionIpv4NetworkRanges | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkAreaRegionIpv4NetworkRanges | cdktf.IResolvable | undefined);
    get networkRangeId(): string;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class NetworkAreaRegionIpv4NetworkRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NetworkAreaRegionIpv4NetworkRanges[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkAreaRegionIpv4NetworkRangesOutputReference;
}
export interface NetworkAreaRegionIpv4 {
    /**
    * List of DNS Servers/Nameservers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#default_nameservers NetworkAreaRegion#default_nameservers}
    */
    readonly defaultNameservers?: string[];
    /**
    * The default prefix length for networks in the network area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#default_prefix_length NetworkAreaRegion#default_prefix_length}
    */
    readonly defaultPrefixLength?: number;
    /**
    * The maximal prefix length for networks in the network area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#max_prefix_length NetworkAreaRegion#max_prefix_length}
    */
    readonly maxPrefixLength?: number;
    /**
    * The minimal prefix length for networks in the network area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#min_prefix_length NetworkAreaRegion#min_prefix_length}
    */
    readonly minPrefixLength?: number;
    /**
    * List of Network ranges.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#network_ranges NetworkAreaRegion#network_ranges}
    */
    readonly networkRanges: NetworkAreaRegionIpv4NetworkRanges[] | cdktf.IResolvable;
    /**
    * IPv4 Classless Inter-Domain Routing (CIDR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#transfer_network NetworkAreaRegion#transfer_network}
    */
    readonly transferNetwork: string;
}
export declare function networkAreaRegionIpv4ToTerraform(struct?: NetworkAreaRegionIpv4 | cdktf.IResolvable): any;
export declare function networkAreaRegionIpv4ToHclTerraform(struct?: NetworkAreaRegionIpv4 | cdktf.IResolvable): any;
export declare class NetworkAreaRegionIpv4OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkAreaRegionIpv4 | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkAreaRegionIpv4 | cdktf.IResolvable | undefined);
    private _defaultNameservers?;
    get defaultNameservers(): string[];
    set defaultNameservers(value: string[]);
    resetDefaultNameservers(): void;
    get defaultNameserversInput(): string[] | undefined;
    private _defaultPrefixLength?;
    get defaultPrefixLength(): number;
    set defaultPrefixLength(value: number);
    resetDefaultPrefixLength(): void;
    get defaultPrefixLengthInput(): number | undefined;
    private _maxPrefixLength?;
    get maxPrefixLength(): number;
    set maxPrefixLength(value: number);
    resetMaxPrefixLength(): void;
    get maxPrefixLengthInput(): number | undefined;
    private _minPrefixLength?;
    get minPrefixLength(): number;
    set minPrefixLength(value: number);
    resetMinPrefixLength(): void;
    get minPrefixLengthInput(): number | undefined;
    private _networkRanges;
    get networkRanges(): NetworkAreaRegionIpv4NetworkRangesList;
    putNetworkRanges(value: NetworkAreaRegionIpv4NetworkRanges[] | cdktf.IResolvable): void;
    get networkRangesInput(): cdktf.IResolvable | NetworkAreaRegionIpv4NetworkRanges[] | undefined;
    private _transferNetwork?;
    get transferNetwork(): string;
    set transferNetwork(value: string);
    get transferNetworkInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region stackit_network_area_region}
*/
export declare class NetworkAreaRegion extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_network_area_region";
    /**
    * Generates CDKTF code for importing a NetworkAreaRegion resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkAreaRegion to import
    * @param importFromId The id of the existing NetworkAreaRegion that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkAreaRegion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/network_area_region stackit_network_area_region} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkAreaRegionConfig
    */
    constructor(scope: Construct, id: string, config: NetworkAreaRegionConfig);
    get id(): string;
    private _ipv4;
    get ipv4(): NetworkAreaRegionIpv4OutputReference;
    putIpv4(value: NetworkAreaRegionIpv4): void;
    get ipv4Input(): cdktf.IResolvable | NetworkAreaRegionIpv4 | undefined;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
