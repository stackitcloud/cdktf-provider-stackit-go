# `stackit_network_area_region`

Refer to the Terraform Registry for docs: [`stackit_network_area_region`](https://registry.terraform.io/providers/stackitcloud/stackit/0.117.0/docs/resources/network_area_region).
