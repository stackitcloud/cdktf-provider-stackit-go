# `data_stackit_logs_instance`

Refer to the Terraform Registry for docs: [`data_stackit_logs_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.114.0/docs/data-sources/logs_instance).
