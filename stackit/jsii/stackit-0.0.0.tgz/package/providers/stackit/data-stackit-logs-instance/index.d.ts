import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitLogsInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Logs instance ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance#instance_id DataStackitLogsInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID associated with the Logs instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance#project_id DataStackitLogsInstance#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance#region DataStackitLogsInstance#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance stackit_logs_instance}
*/
export declare class DataStackitLogsInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_logs_instance";
    /**
    * Generates CDKTF code for importing a DataStackitLogsInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitLogsInstance to import
    * @param importFromId The id of the existing DataStackitLogsInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitLogsInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.106.0/docs/data-sources/logs_instance stackit_logs_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitLogsInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitLogsInstanceConfig);
    get acl(): string[];
    get created(): string;
    get datasourceUrl(): string;
    get description(): string;
    get displayName(): string;
    get id(): string;
    get ingestOtlpUrl(): string;
    get ingestUrl(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get queryRangeUrl(): string;
    get queryUrl(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get retentionDays(): number;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
