import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitTelemetryrouterDestinationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The TelemetryRouter destination ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#destination_id DataStackitTelemetryrouterDestination#destination_id}
    */
    readonly destinationId: string;
    /**
    * The TelemetryRouter instance ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#instance_id DataStackitTelemetryrouterDestination#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID associated with the TelemetryRouter instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#project_id DataStackitTelemetryrouterDestination#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#region DataStackitTelemetryrouterDestination#region}
    */
    readonly region?: string;
}
export interface DataStackitTelemetryrouterDestinationConfigFilterAttributes {
}
export declare function dataStackitTelemetryrouterDestinationConfigFilterAttributesToTerraform(struct?: DataStackitTelemetryrouterDestinationConfigFilterAttributes): any;
export declare function dataStackitTelemetryrouterDestinationConfigFilterAttributesToHclTerraform(struct?: DataStackitTelemetryrouterDestinationConfigFilterAttributes): any;
export declare class DataStackitTelemetryrouterDestinationConfigFilterAttributesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitTelemetryrouterDestinationConfigFilterAttributes | undefined;
    set internalValue(value: DataStackitTelemetryrouterDestinationConfigFilterAttributes | undefined);
    get key(): string;
    get level(): string;
    get matcher(): string;
    get values(): string[];
}
export declare class DataStackitTelemetryrouterDestinationConfigFilterAttributesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitTelemetryrouterDestinationConfigFilterAttributesOutputReference;
}
export interface DataStackitTelemetryrouterDestinationConfigFilter {
}
export declare function dataStackitTelemetryrouterDestinationConfigFilterToTerraform(struct?: DataStackitTelemetryrouterDestinationConfigFilter | cdktf.IResolvable): any;
export declare function dataStackitTelemetryrouterDestinationConfigFilterToHclTerraform(struct?: DataStackitTelemetryrouterDestinationConfigFilter | cdktf.IResolvable): any;
export declare class DataStackitTelemetryrouterDestinationConfigFilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitTelemetryrouterDestinationConfigFilter | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitTelemetryrouterDestinationConfigFilter | cdktf.IResolvable | undefined);
    private _attributes;
    get attributes(): DataStackitTelemetryrouterDestinationConfigFilterAttributesList;
}
export interface DataStackitTelemetryrouterDestinationConfigOpentelemetry {
}
export declare function dataStackitTelemetryrouterDestinationConfigOpentelemetryToTerraform(struct?: DataStackitTelemetryrouterDestinationConfigOpentelemetry | cdktf.IResolvable): any;
export declare function dataStackitTelemetryrouterDestinationConfigOpentelemetryToHclTerraform(struct?: DataStackitTelemetryrouterDestinationConfigOpentelemetry | cdktf.IResolvable): any;
export declare class DataStackitTelemetryrouterDestinationConfigOpentelemetryOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitTelemetryrouterDestinationConfigOpentelemetry | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitTelemetryrouterDestinationConfigOpentelemetry | cdktf.IResolvable | undefined);
    get uri(): string;
}
export interface DataStackitTelemetryrouterDestinationConfigS3 {
}
export declare function dataStackitTelemetryrouterDestinationConfigS3ToTerraform(struct?: DataStackitTelemetryrouterDestinationConfigS3 | cdktf.IResolvable): any;
export declare function dataStackitTelemetryrouterDestinationConfigS3ToHclTerraform(struct?: DataStackitTelemetryrouterDestinationConfigS3 | cdktf.IResolvable): any;
export declare class DataStackitTelemetryrouterDestinationConfigS3OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitTelemetryrouterDestinationConfigS3 | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitTelemetryrouterDestinationConfigS3 | cdktf.IResolvable | undefined);
    get bucket(): string;
    get endpoint(): string;
}
export interface DataStackitTelemetryrouterDestinationConfigA {
    /**
    * The TelemetryRouter destination's filter settings
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#filter DataStackitTelemetryrouterDestination#filter}
    */
    readonly filter?: DataStackitTelemetryrouterDestinationConfigFilter;
    /**
    * OpenTelemetry configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#opentelemetry DataStackitTelemetryrouterDestination#opentelemetry}
    */
    readonly opentelemetry?: DataStackitTelemetryrouterDestinationConfigOpentelemetry;
    /**
    * S3 configuration
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#s3 DataStackitTelemetryrouterDestination#s3}
    */
    readonly s3?: DataStackitTelemetryrouterDestinationConfigS3;
}
export declare function dataStackitTelemetryrouterDestinationConfigAToTerraform(struct?: DataStackitTelemetryrouterDestinationConfigA): any;
export declare function dataStackitTelemetryrouterDestinationConfigAToHclTerraform(struct?: DataStackitTelemetryrouterDestinationConfigA): any;
export declare class DataStackitTelemetryrouterDestinationConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitTelemetryrouterDestinationConfigA | undefined;
    set internalValue(value: DataStackitTelemetryrouterDestinationConfigA | undefined);
    get configType(): string;
    private _filter;
    get filter(): DataStackitTelemetryrouterDestinationConfigFilterOutputReference;
    putFilter(value: DataStackitTelemetryrouterDestinationConfigFilter): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataStackitTelemetryrouterDestinationConfigFilter | undefined;
    private _opentelemetry;
    get opentelemetry(): DataStackitTelemetryrouterDestinationConfigOpentelemetryOutputReference;
    putOpentelemetry(value: DataStackitTelemetryrouterDestinationConfigOpentelemetry): void;
    resetOpentelemetry(): void;
    get opentelemetryInput(): cdktf.IResolvable | DataStackitTelemetryrouterDestinationConfigOpentelemetry | undefined;
    private _s3;
    get s3(): DataStackitTelemetryrouterDestinationConfigS3OutputReference;
    putS3(value: DataStackitTelemetryrouterDestinationConfigS3): void;
    resetS3(): void;
    get s3Input(): cdktf.IResolvable | DataStackitTelemetryrouterDestinationConfigS3 | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination stackit_telemetryrouter_destination}
*/
export declare class DataStackitTelemetryrouterDestination extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_telemetryrouter_destination";
    /**
    * Generates CDKTF code for importing a DataStackitTelemetryrouterDestination resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitTelemetryrouterDestination to import
    * @param importFromId The id of the existing DataStackitTelemetryrouterDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitTelemetryrouterDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetryrouter_destination stackit_telemetryrouter_destination} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitTelemetryrouterDestinationConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitTelemetryrouterDestinationConfig);
    private _config;
    get config(): DataStackitTelemetryrouterDestinationConfigAOutputReference;
    get creationTime(): string;
    get credentialType(): string;
    get description(): string;
    private _destinationId?;
    get destinationId(): string;
    set destinationId(value: string);
    get destinationIdInput(): string | undefined;
    get displayName(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
