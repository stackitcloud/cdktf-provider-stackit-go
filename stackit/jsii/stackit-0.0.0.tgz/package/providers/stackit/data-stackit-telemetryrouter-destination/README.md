# `data_stackit_telemetryrouter_destination`

Refer to the Terraform Registry for docs: [`data_stackit_telemetryrouter_destination`](https://registry.terraform.io/providers/stackitcloud/stackit/0.103.0/docs/data-sources/telemetryrouter_destination).
