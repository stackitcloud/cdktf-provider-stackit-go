import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObservabilityInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list for this instance. Each entry is an IP address range that is permitted to access, in CIDR notation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#acl ObservabilityInstance#acl}
    */
    readonly acl?: string[];
    /**
    * Alert configuration for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#alert_config ObservabilityInstance#alert_config}
    */
    readonly alertConfig?: ObservabilityInstanceAlertConfig;
    /**
    * If true, a default Grafana server admin user is created. It's recommended to set this to false and use STACKIT SSO (Owner or Observability Grafana Server Admin role) instead. It is still possible to manually create a new Grafana admin user via the Grafana UI later.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#grafana_admin_enabled ObservabilityInstance#grafana_admin_enabled}
    */
    readonly grafanaAdminEnabled?: boolean | cdktf.IResolvable;
    /**
    * Specifies for how many days the logs are kept. Default is set to `7`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#logs_retention_days ObservabilityInstance#logs_retention_days}
    */
    readonly logsRetentionDays?: number;
    /**
    * Specifies for how many days the raw metrics are kept. Default is set to `90`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#metrics_retention_days ObservabilityInstance#metrics_retention_days}
    */
    readonly metricsRetentionDays?: number;
    /**
    * Specifies for how many days the 1h downsampled metrics are kept. must be less than the value of the 5m downsampling retention. Default is set to `90`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#metrics_retention_days_1h_downsampling ObservabilityInstance#metrics_retention_days_1h_downsampling}
    */
    readonly metricsRetentionDays1HDownsampling?: number;
    /**
    * Specifies for how many days the 5m downsampled metrics are kept. must be less than the value of the general retention. Default is set to `90`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#metrics_retention_days_5m_downsampling ObservabilityInstance#metrics_retention_days_5m_downsampling}
    */
    readonly metricsRetentionDays5MDownsampling?: number;
    /**
    * The name of the Observability instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#name ObservabilityInstance#name}
    */
    readonly name: string;
    /**
    * Additional parameters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#parameters ObservabilityInstance#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Specifies the Observability plan. E.g. `Observability-Monitoring-Medium-EU01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#plan_name ObservabilityInstance#plan_name}
    */
    readonly planName: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#project_id ObservabilityInstance#project_id}
    */
    readonly projectId: string;
    /**
    * Specifies for how many days the traces are kept. Default is set to `7`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#traces_retention_days ObservabilityInstance#traces_retention_days}
    */
    readonly tracesRetentionDays?: number;
}
export interface ObservabilityInstanceAlertConfigGlobal {
    /**
    * The API key for OpsGenie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#opsgenie_api_key ObservabilityInstance#opsgenie_api_key}
    */
    readonly opsgenieApiKey?: string;
    /**
    * The host to send OpsGenie API requests to. Must be a valid URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#opsgenie_api_url ObservabilityInstance#opsgenie_api_url}
    */
    readonly opsgenieApiUrl?: string;
    /**
    * The default value used by alertmanager if the alert does not include EndsAt. After this time passes, it can declare the alert as resolved if it has not been updated. This has no impact on alerts from Prometheus, as they always include EndsAt.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#resolve_timeout ObservabilityInstance#resolve_timeout}
    */
    readonly resolveTimeout?: string;
    /**
    * SMTP authentication information. Must be a valid email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smtp_auth_identity ObservabilityInstance#smtp_auth_identity}
    */
    readonly smtpAuthIdentity?: string;
    /**
    * SMTP Auth using LOGIN and PLAIN.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smtp_auth_password ObservabilityInstance#smtp_auth_password}
    */
    readonly smtpAuthPassword?: string;
    /**
    * SMTP Auth using CRAM-MD5, LOGIN and PLAIN. If empty, Alertmanager doesn't authenticate to the SMTP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smtp_auth_username ObservabilityInstance#smtp_auth_username}
    */
    readonly smtpAuthUsername?: string;
    /**
    * The default SMTP From header field. Must be a valid email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smtp_from ObservabilityInstance#smtp_from}
    */
    readonly smtpFrom?: string;
    /**
    * The default SMTP smarthost used for sending emails, including port number in format `host:port` (eg. `smtp.example.com:587`). Port number usually is 25, or 587 for SMTP over TLS (sometimes referred to as STARTTLS).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smtp_smart_host ObservabilityInstance#smtp_smart_host}
    */
    readonly smtpSmartHost?: string;
}
export declare function observabilityInstanceAlertConfigGlobalToTerraform(struct?: ObservabilityInstanceAlertConfigGlobal | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigGlobalToHclTerraform(struct?: ObservabilityInstanceAlertConfigGlobal | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigGlobalOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObservabilityInstanceAlertConfigGlobal | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigGlobal | cdktf.IResolvable | undefined);
    private _opsgenieApiKey?;
    get opsgenieApiKey(): string;
    set opsgenieApiKey(value: string);
    resetOpsgenieApiKey(): void;
    get opsgenieApiKeyInput(): string | undefined;
    private _opsgenieApiUrl?;
    get opsgenieApiUrl(): string;
    set opsgenieApiUrl(value: string);
    resetOpsgenieApiUrl(): void;
    get opsgenieApiUrlInput(): string | undefined;
    private _resolveTimeout?;
    get resolveTimeout(): string;
    set resolveTimeout(value: string);
    resetResolveTimeout(): void;
    get resolveTimeoutInput(): string | undefined;
    private _smtpAuthIdentity?;
    get smtpAuthIdentity(): string;
    set smtpAuthIdentity(value: string);
    resetSmtpAuthIdentity(): void;
    get smtpAuthIdentityInput(): string | undefined;
    private _smtpAuthPassword?;
    get smtpAuthPassword(): string;
    set smtpAuthPassword(value: string);
    resetSmtpAuthPassword(): void;
    get smtpAuthPasswordInput(): string | undefined;
    private _smtpAuthUsername?;
    get smtpAuthUsername(): string;
    set smtpAuthUsername(value: string);
    resetSmtpAuthUsername(): void;
    get smtpAuthUsernameInput(): string | undefined;
    private _smtpFrom?;
    get smtpFrom(): string;
    set smtpFrom(value: string);
    resetSmtpFrom(): void;
    get smtpFromInput(): string | undefined;
    private _smtpSmartHost?;
    get smtpSmartHost(): string;
    set smtpSmartHost(value: string);
    resetSmtpSmartHost(): void;
    get smtpSmartHostInput(): string | undefined;
}
export interface ObservabilityInstanceAlertConfigReceiversEmailConfigs {
    /**
    * SMTP authentication information. Must be a valid email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#auth_identity ObservabilityInstance#auth_identity}
    */
    readonly authIdentity?: string;
    /**
    * SMTP authentication password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#auth_password ObservabilityInstance#auth_password}
    */
    readonly authPassword?: string;
    /**
    * SMTP authentication username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#auth_username ObservabilityInstance#auth_username}
    */
    readonly authUsername?: string;
    /**
    * The sender email address. Must be a valid email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#from ObservabilityInstance#from}
    */
    readonly from?: string;
    /**
    * Whether to notify about resolved alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#send_resolved ObservabilityInstance#send_resolved}
    */
    readonly sendResolved?: boolean | cdktf.IResolvable;
    /**
    * The SMTP host through which emails are sent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#smart_host ObservabilityInstance#smart_host}
    */
    readonly smartHost?: string;
    /**
    * The email address to send notifications to. Must be a valid email address
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#to ObservabilityInstance#to}
    */
    readonly to?: string;
}
export declare function observabilityInstanceAlertConfigReceiversEmailConfigsToTerraform(struct?: ObservabilityInstanceAlertConfigReceiversEmailConfigs | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigReceiversEmailConfigsToHclTerraform(struct?: ObservabilityInstanceAlertConfigReceiversEmailConfigs | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigReceiversEmailConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityInstanceAlertConfigReceiversEmailConfigs | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigReceiversEmailConfigs | cdktf.IResolvable | undefined);
    private _authIdentity?;
    get authIdentity(): string;
    set authIdentity(value: string);
    resetAuthIdentity(): void;
    get authIdentityInput(): string | undefined;
    private _authPassword?;
    get authPassword(): string;
    set authPassword(value: string);
    resetAuthPassword(): void;
    get authPasswordInput(): string | undefined;
    private _authUsername?;
    get authUsername(): string;
    set authUsername(value: string);
    resetAuthUsername(): void;
    get authUsernameInput(): string | undefined;
    private _from?;
    get from(): string;
    set from(value: string);
    resetFrom(): void;
    get fromInput(): string | undefined;
    private _sendResolved?;
    get sendResolved(): boolean | cdktf.IResolvable;
    set sendResolved(value: boolean | cdktf.IResolvable);
    resetSendResolved(): void;
    get sendResolvedInput(): boolean | cdktf.IResolvable | undefined;
    private _smartHost?;
    get smartHost(): string;
    set smartHost(value: string);
    resetSmartHost(): void;
    get smartHostInput(): string | undefined;
    private _to?;
    get to(): string;
    set to(value: string);
    resetTo(): void;
    get toInput(): string | undefined;
}
export declare class ObservabilityInstanceAlertConfigReceiversEmailConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityInstanceAlertConfigReceiversEmailConfigs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityInstanceAlertConfigReceiversEmailConfigsOutputReference;
}
export interface ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs {
    /**
    * The API key for OpsGenie.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#api_key ObservabilityInstance#api_key}
    */
    readonly apiKey?: string;
    /**
    * The host to send OpsGenie API requests to. Must be a valid URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#api_url ObservabilityInstance#api_url}
    */
    readonly apiUrl?: string;
    /**
    * Priority of the alert. Possible values are: `P1`, `P2`, `P3`, `P4`, `P5`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#priority ObservabilityInstance#priority}
    */
    readonly priority?: string;
    /**
    * Whether to notify about resolved alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#send_resolved ObservabilityInstance#send_resolved}
    */
    readonly sendResolved?: boolean | cdktf.IResolvable;
    /**
    * Comma separated list of tags attached to the notifications.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#tags ObservabilityInstance#tags}
    */
    readonly tags?: string;
}
export declare function observabilityInstanceAlertConfigReceiversOpsgenieConfigsToTerraform(struct?: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigReceiversOpsgenieConfigsToHclTerraform(struct?: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigReceiversOpsgenieConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs | cdktf.IResolvable | undefined);
    private _apiKey?;
    get apiKey(): string;
    set apiKey(value: string);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _apiUrl?;
    get apiUrl(): string;
    set apiUrl(value: string);
    resetApiUrl(): void;
    get apiUrlInput(): string | undefined;
    private _priority?;
    get priority(): string;
    set priority(value: string);
    resetPriority(): void;
    get priorityInput(): string | undefined;
    private _sendResolved?;
    get sendResolved(): boolean | cdktf.IResolvable;
    set sendResolved(value: boolean | cdktf.IResolvable);
    resetSendResolved(): void;
    get sendResolvedInput(): boolean | cdktf.IResolvable | undefined;
    private _tags?;
    get tags(): string;
    set tags(value: string);
    resetTags(): void;
    get tagsInput(): string | undefined;
}
export declare class ObservabilityInstanceAlertConfigReceiversOpsgenieConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityInstanceAlertConfigReceiversOpsgenieConfigsOutputReference;
}
export interface ObservabilityInstanceAlertConfigReceiversWebhooksConfigs {
    /**
    * Google Chat webhooks require special handling, set this to true if the webhook is for Google Chat.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#google_chat ObservabilityInstance#google_chat}
    */
    readonly googleChat?: boolean | cdktf.IResolvable;
    /**
    * Microsoft Teams webhooks require special handling, set this to true if the webhook is for Microsoft Teams.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#ms_teams ObservabilityInstance#ms_teams}
    */
    readonly msTeams?: boolean | cdktf.IResolvable;
    /**
    * Whether to notify about resolved alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#send_resolved ObservabilityInstance#send_resolved}
    */
    readonly sendResolved?: boolean | cdktf.IResolvable;
    /**
    * The endpoint to send HTTP POST requests to. Must be a valid URL
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#url ObservabilityInstance#url}
    */
    readonly url?: string;
}
export declare function observabilityInstanceAlertConfigReceiversWebhooksConfigsToTerraform(struct?: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigReceiversWebhooksConfigsToHclTerraform(struct?: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigReceiversWebhooksConfigsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityInstanceAlertConfigReceiversWebhooksConfigs | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs | cdktf.IResolvable | undefined);
    private _googleChat?;
    get googleChat(): boolean | cdktf.IResolvable;
    set googleChat(value: boolean | cdktf.IResolvable);
    resetGoogleChat(): void;
    get googleChatInput(): boolean | cdktf.IResolvable | undefined;
    private _msTeams?;
    get msTeams(): boolean | cdktf.IResolvable;
    set msTeams(value: boolean | cdktf.IResolvable);
    resetMsTeams(): void;
    get msTeamsInput(): boolean | cdktf.IResolvable | undefined;
    private _sendResolved?;
    get sendResolved(): boolean | cdktf.IResolvable;
    set sendResolved(value: boolean | cdktf.IResolvable);
    resetSendResolved(): void;
    get sendResolvedInput(): boolean | cdktf.IResolvable | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
}
export declare class ObservabilityInstanceAlertConfigReceiversWebhooksConfigsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityInstanceAlertConfigReceiversWebhooksConfigsOutputReference;
}
export interface ObservabilityInstanceAlertConfigReceivers {
    /**
    * List of email configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#email_configs ObservabilityInstance#email_configs}
    */
    readonly emailConfigs?: ObservabilityInstanceAlertConfigReceiversEmailConfigs[] | cdktf.IResolvable;
    /**
    * Name of the receiver.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#name ObservabilityInstance#name}
    */
    readonly name: string;
    /**
    * List of OpsGenie configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#opsgenie_configs ObservabilityInstance#opsgenie_configs}
    */
    readonly opsgenieConfigs?: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs[] | cdktf.IResolvable;
    /**
    * List of Webhooks configurations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#webhooks_configs ObservabilityInstance#webhooks_configs}
    */
    readonly webhooksConfigs?: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs[] | cdktf.IResolvable;
}
export declare function observabilityInstanceAlertConfigReceiversToTerraform(struct?: ObservabilityInstanceAlertConfigReceivers | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigReceiversToHclTerraform(struct?: ObservabilityInstanceAlertConfigReceivers | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigReceiversOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityInstanceAlertConfigReceivers | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigReceivers | cdktf.IResolvable | undefined);
    private _emailConfigs;
    get emailConfigs(): ObservabilityInstanceAlertConfigReceiversEmailConfigsList;
    putEmailConfigs(value: ObservabilityInstanceAlertConfigReceiversEmailConfigs[] | cdktf.IResolvable): void;
    resetEmailConfigs(): void;
    get emailConfigsInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigReceiversEmailConfigs[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _opsgenieConfigs;
    get opsgenieConfigs(): ObservabilityInstanceAlertConfigReceiversOpsgenieConfigsList;
    putOpsgenieConfigs(value: ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs[] | cdktf.IResolvable): void;
    resetOpsgenieConfigs(): void;
    get opsgenieConfigsInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigReceiversOpsgenieConfigs[] | undefined;
    private _webhooksConfigs;
    get webhooksConfigs(): ObservabilityInstanceAlertConfigReceiversWebhooksConfigsList;
    putWebhooksConfigs(value: ObservabilityInstanceAlertConfigReceiversWebhooksConfigs[] | cdktf.IResolvable): void;
    resetWebhooksConfigs(): void;
    get webhooksConfigsInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigReceiversWebhooksConfigs[] | undefined;
}
export declare class ObservabilityInstanceAlertConfigReceiversList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityInstanceAlertConfigReceivers[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityInstanceAlertConfigReceiversOutputReference;
}
export interface ObservabilityInstanceAlertConfigRouteRoutes {
    /**
    * Whether an alert should continue matching subsequent sibling nodes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#continue ObservabilityInstance#continue}
    */
    readonly continue?: boolean | cdktf.IResolvable;
    /**
    * The labels by which incoming alerts are grouped together. For example, multiple alerts coming in for cluster=A and alertname=LatencyHigh would be batched into a single group. To aggregate by all possible labels use the special value '...' as the sole label name, for example: group_by: ['...']. This effectively disables aggregation entirely, passing through all alerts as-is. This is unlikely to be what you want, unless you have a very low alert volume or your upstream notification system performs its own grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_by ObservabilityInstance#group_by}
    */
    readonly groupBy?: string[];
    /**
    * How long to wait before sending a notification about new alerts that are added to a group of alerts for which an initial notification has already been sent. (Usually ~5m or more.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_interval ObservabilityInstance#group_interval}
    */
    readonly groupInterval?: string;
    /**
    * How long to initially wait to send a notification for a group of alerts. Allows to wait for an inhibiting alert to arrive or collect more initial alerts for the same group. (Usually ~0s to few minutes.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_wait ObservabilityInstance#group_wait}
    */
    readonly groupWait?: string;
    /**
    * A set of equality matchers an alert has to fulfill to match the node. This field is deprecated and will be removed after 10th March 2026, use `matchers` in the `routes` instead
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#match ObservabilityInstance#match}
    */
    readonly match?: {
        [key: string]: string;
    };
    /**
    * A set of regex-matchers an alert has to fulfill to match the node. This field is deprecated and will be removed after 10th March 2026, use `matchers` in the `routes` instead
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#match_regex ObservabilityInstance#match_regex}
    */
    readonly matchRegex?: {
        [key: string]: string;
    };
    /**
    * A list of matchers that an alert has to fulfill to match the node. A matcher is a string with a syntax inspired by PromQL and OpenMetrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#matchers ObservabilityInstance#matchers}
    */
    readonly matchers?: string[];
    /**
    * The name of the receiver to route the alerts to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#receiver ObservabilityInstance#receiver}
    */
    readonly receiver: string;
    /**
    * How long to wait before sending a notification again if it has already been sent successfully for an alert. (Usually ~3h or more).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#repeat_interval ObservabilityInstance#repeat_interval}
    */
    readonly repeatInterval?: string;
}
export declare function observabilityInstanceAlertConfigRouteRoutesToTerraform(struct?: ObservabilityInstanceAlertConfigRouteRoutes | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigRouteRoutesToHclTerraform(struct?: ObservabilityInstanceAlertConfigRouteRoutes | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigRouteRoutesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityInstanceAlertConfigRouteRoutes | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigRouteRoutes | cdktf.IResolvable | undefined);
    private _continue?;
    get continue(): boolean | cdktf.IResolvable;
    set continue(value: boolean | cdktf.IResolvable);
    resetContinue(): void;
    get continueInput(): boolean | cdktf.IResolvable | undefined;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _groupInterval?;
    get groupInterval(): string;
    set groupInterval(value: string);
    resetGroupInterval(): void;
    get groupIntervalInput(): string | undefined;
    private _groupWait?;
    get groupWait(): string;
    set groupWait(value: string);
    resetGroupWait(): void;
    get groupWaitInput(): string | undefined;
    private _match?;
    get match(): {
        [key: string]: string;
    };
    set match(value: {
        [key: string]: string;
    });
    resetMatch(): void;
    get matchInput(): {
        [key: string]: string;
    } | undefined;
    private _matchRegex?;
    get matchRegex(): {
        [key: string]: string;
    };
    set matchRegex(value: {
        [key: string]: string;
    });
    resetMatchRegex(): void;
    get matchRegexInput(): {
        [key: string]: string;
    } | undefined;
    private _matchers?;
    get matchers(): string[];
    set matchers(value: string[]);
    resetMatchers(): void;
    get matchersInput(): string[] | undefined;
    private _receiver?;
    get receiver(): string;
    set receiver(value: string);
    get receiverInput(): string | undefined;
    private _repeatInterval?;
    get repeatInterval(): string;
    set repeatInterval(value: string);
    resetRepeatInterval(): void;
    get repeatIntervalInput(): string | undefined;
}
export declare class ObservabilityInstanceAlertConfigRouteRoutesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityInstanceAlertConfigRouteRoutes[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityInstanceAlertConfigRouteRoutesOutputReference;
}
export interface ObservabilityInstanceAlertConfigRoute {
    /**
    * The labels by which incoming alerts are grouped together. For example, multiple alerts coming in for cluster=A and alertname=LatencyHigh would be batched into a single group. To aggregate by all possible labels use the special value '...' as the sole label name, for example: group_by: ['...']. This effectively disables aggregation entirely, passing through all alerts as-is. This is unlikely to be what you want, unless you have a very low alert volume or your upstream notification system performs its own grouping.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_by ObservabilityInstance#group_by}
    */
    readonly groupBy?: string[];
    /**
    * How long to wait before sending a notification about new alerts that are added to a group of alerts for which an initial notification has already been sent. (Usually ~5m or more.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_interval ObservabilityInstance#group_interval}
    */
    readonly groupInterval?: string;
    /**
    * How long to initially wait to send a notification for a group of alerts. Allows to wait for an inhibiting alert to arrive or collect more initial alerts for the same group. (Usually ~0s to few minutes.)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#group_wait ObservabilityInstance#group_wait}
    */
    readonly groupWait?: string;
    /**
    * The name of the receiver to route the alerts to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#receiver ObservabilityInstance#receiver}
    */
    readonly receiver: string;
    /**
    * How long to wait before sending a notification again if it has already been sent successfully for an alert. (Usually ~3h or more).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#repeat_interval ObservabilityInstance#repeat_interval}
    */
    readonly repeatInterval?: string;
    /**
    * List of child routes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#routes ObservabilityInstance#routes}
    */
    readonly routes?: ObservabilityInstanceAlertConfigRouteRoutes[] | cdktf.IResolvable;
}
export declare function observabilityInstanceAlertConfigRouteToTerraform(struct?: ObservabilityInstanceAlertConfigRoute | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigRouteToHclTerraform(struct?: ObservabilityInstanceAlertConfigRoute | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigRouteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObservabilityInstanceAlertConfigRoute | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfigRoute | cdktf.IResolvable | undefined);
    get continue(): cdktf.IResolvable;
    private _groupBy?;
    get groupBy(): string[];
    set groupBy(value: string[]);
    resetGroupBy(): void;
    get groupByInput(): string[] | undefined;
    private _groupInterval?;
    get groupInterval(): string;
    set groupInterval(value: string);
    resetGroupInterval(): void;
    get groupIntervalInput(): string | undefined;
    private _groupWait?;
    get groupWait(): string;
    set groupWait(value: string);
    resetGroupWait(): void;
    get groupWaitInput(): string | undefined;
    private _receiver?;
    get receiver(): string;
    set receiver(value: string);
    get receiverInput(): string | undefined;
    private _repeatInterval?;
    get repeatInterval(): string;
    set repeatInterval(value: string);
    resetRepeatInterval(): void;
    get repeatIntervalInput(): string | undefined;
    private _routes;
    get routes(): ObservabilityInstanceAlertConfigRouteRoutesList;
    putRoutes(value: ObservabilityInstanceAlertConfigRouteRoutes[] | cdktf.IResolvable): void;
    resetRoutes(): void;
    get routesInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigRouteRoutes[] | undefined;
}
export interface ObservabilityInstanceAlertConfig {
    /**
    * Global configuration for the alerts. If nothing passed the default argus config will be used. It is only possible to update the entire global part, not individual attributes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#global ObservabilityInstance#global}
    */
    readonly global?: ObservabilityInstanceAlertConfigGlobal;
    /**
    * List of alert receivers.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#receivers ObservabilityInstance#receivers}
    */
    readonly receivers: ObservabilityInstanceAlertConfigReceivers[] | cdktf.IResolvable;
    /**
    * Route configuration for the alerts.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#route ObservabilityInstance#route}
    */
    readonly route: ObservabilityInstanceAlertConfigRoute;
}
export declare function observabilityInstanceAlertConfigToTerraform(struct?: ObservabilityInstanceAlertConfig | cdktf.IResolvable): any;
export declare function observabilityInstanceAlertConfigToHclTerraform(struct?: ObservabilityInstanceAlertConfig | cdktf.IResolvable): any;
export declare class ObservabilityInstanceAlertConfigOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObservabilityInstanceAlertConfig | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityInstanceAlertConfig | cdktf.IResolvable | undefined);
    private _global;
    get global(): ObservabilityInstanceAlertConfigGlobalOutputReference;
    putGlobal(value: ObservabilityInstanceAlertConfigGlobal): void;
    resetGlobal(): void;
    get globalInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigGlobal | undefined;
    private _receivers;
    get receivers(): ObservabilityInstanceAlertConfigReceiversList;
    putReceivers(value: ObservabilityInstanceAlertConfigReceivers[] | cdktf.IResolvable): void;
    get receiversInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigReceivers[] | undefined;
    private _route;
    get route(): ObservabilityInstanceAlertConfigRouteOutputReference;
    putRoute(value: ObservabilityInstanceAlertConfigRoute): void;
    get routeInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfigRoute | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance stackit_observability_instance}
*/
export declare class ObservabilityInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_observability_instance";
    /**
    * Generates CDKTF code for importing a ObservabilityInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityInstance to import
    * @param importFromId The id of the existing ObservabilityInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/observability_instance stackit_observability_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityInstanceConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityInstanceConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    resetAcl(): void;
    get aclInput(): string[] | undefined;
    private _alertConfig;
    get alertConfig(): ObservabilityInstanceAlertConfigOutputReference;
    putAlertConfig(value: ObservabilityInstanceAlertConfig): void;
    resetAlertConfig(): void;
    get alertConfigInput(): cdktf.IResolvable | ObservabilityInstanceAlertConfig | undefined;
    get alertingUrl(): string;
    get dashboardUrl(): string;
    private _grafanaAdminEnabled?;
    get grafanaAdminEnabled(): boolean | cdktf.IResolvable;
    set grafanaAdminEnabled(value: boolean | cdktf.IResolvable);
    resetGrafanaAdminEnabled(): void;
    get grafanaAdminEnabledInput(): boolean | cdktf.IResolvable | undefined;
    get grafanaInitialAdminPassword(): string;
    get grafanaInitialAdminUser(): string;
    get grafanaPublicReadAccess(): cdktf.IResolvable;
    get grafanaUrl(): string;
    get id(): string;
    get instanceId(): string;
    get isUpdatable(): cdktf.IResolvable;
    get jaegerTracesUrl(): string;
    get jaegerUiUrl(): string;
    get logsPushUrl(): string;
    private _logsRetentionDays?;
    get logsRetentionDays(): number;
    set logsRetentionDays(value: number);
    resetLogsRetentionDays(): void;
    get logsRetentionDaysInput(): number | undefined;
    get logsUrl(): string;
    get metricsPushUrl(): string;
    private _metricsRetentionDays?;
    get metricsRetentionDays(): number;
    set metricsRetentionDays(value: number);
    resetMetricsRetentionDays(): void;
    get metricsRetentionDaysInput(): number | undefined;
    private _metricsRetentionDays1HDownsampling?;
    get metricsRetentionDays1HDownsampling(): number;
    set metricsRetentionDays1HDownsampling(value: number);
    resetMetricsRetentionDays1HDownsampling(): void;
    get metricsRetentionDays1HDownsamplingInput(): number | undefined;
    private _metricsRetentionDays5MDownsampling?;
    get metricsRetentionDays5MDownsampling(): number;
    set metricsRetentionDays5MDownsampling(value: number);
    resetMetricsRetentionDays5MDownsampling(): void;
    get metricsRetentionDays5MDownsamplingInput(): number | undefined;
    get metricsUrl(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get otlpTracesUrl(): string;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    get planId(): string;
    private _planName?;
    get planName(): string;
    set planName(value: string);
    get planNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get targetsUrl(): string;
    private _tracesRetentionDays?;
    get tracesRetentionDays(): number;
    set tracesRetentionDays(value: number);
    resetTracesRetentionDays(): void;
    get tracesRetentionDaysInput(): number | undefined;
    get zipkinSpansUrl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
