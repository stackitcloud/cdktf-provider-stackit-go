# `stackit_observability_instance`

Refer to the Terraform Registry for docs: [`stackit_observability_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/observability_instance).
