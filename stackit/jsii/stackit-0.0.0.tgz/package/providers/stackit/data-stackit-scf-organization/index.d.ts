import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitScfOrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the Cloud Foundry Organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization#org_id DataStackitScfOrganization#org_id}
    */
    readonly orgId: string;
    /**
    * The ID of the project associated with the organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization#project_id DataStackitScfOrganization#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization#region DataStackitScfOrganization#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization stackit_scf_organization}
*/
export declare class DataStackitScfOrganization extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_scf_organization";
    /**
    * Generates CDKTF code for importing a DataStackitScfOrganization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitScfOrganization to import
    * @param importFromId The id of the existing DataStackitScfOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitScfOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/scf_organization stackit_scf_organization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitScfOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitScfOrganizationConfig);
    get createdAt(): string;
    get id(): string;
    get name(): string;
    private _orgId?;
    get orgId(): string;
    set orgId(value: string);
    get orgIdInput(): string | undefined;
    get platformId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get quotaId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get suspended(): cdktf.IResolvable;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
