import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SfsExportPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the export policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#name SfsExportPolicy#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the export policy is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#project_id SfsExportPolicy#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#region SfsExportPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#rules SfsExportPolicy#rules}
    */
    readonly rules?: SfsExportPolicyRules[] | cdktf.IResolvable;
}
export interface SfsExportPolicyRules {
    /**
    * Description of the Rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#description SfsExportPolicy#description}
    */
    readonly description?: string;
    /**
    * IP access control list; IPs must have a subnet mask (e.g. "172.16.0.0/24" for a range of IPs, or "172.16.0.250/32" for a specific IP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#ip_acl SfsExportPolicy#ip_acl}
    */
    readonly ipAcl: string[];
    /**
    * Order of the rule within a Share Export Policy. The order is used so that when a client IP matches multiple rules, the first rule is applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#order SfsExportPolicy#order}
    */
    readonly order: number;
    /**
    * Flag to indicate if client IPs matching this rule can only mount the share in read only mode
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#read_only SfsExportPolicy#read_only}
    */
    readonly readOnly?: boolean | cdktf.IResolvable;
    /**
    * Flag to honor set UUID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#set_uuid SfsExportPolicy#set_uuid}
    */
    readonly setUuid?: boolean | cdktf.IResolvable;
    /**
    * Flag to indicate if client IPs matching this rule have root access on the Share
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#super_user SfsExportPolicy#super_user}
    */
    readonly superUser?: boolean | cdktf.IResolvable;
}
export declare function sfsExportPolicyRulesToTerraform(struct?: SfsExportPolicyRules | cdktf.IResolvable): any;
export declare function sfsExportPolicyRulesToHclTerraform(struct?: SfsExportPolicyRules | cdktf.IResolvable): any;
export declare class SfsExportPolicyRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SfsExportPolicyRules | cdktf.IResolvable | undefined;
    set internalValue(value: SfsExportPolicyRules | cdktf.IResolvable | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _ipAcl?;
    get ipAcl(): string[];
    set ipAcl(value: string[]);
    get ipAclInput(): string[] | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    get orderInput(): number | undefined;
    private _readOnly?;
    get readOnly(): boolean | cdktf.IResolvable;
    set readOnly(value: boolean | cdktf.IResolvable);
    resetReadOnly(): void;
    get readOnlyInput(): boolean | cdktf.IResolvable | undefined;
    private _setUuid?;
    get setUuid(): boolean | cdktf.IResolvable;
    set setUuid(value: boolean | cdktf.IResolvable);
    resetSetUuid(): void;
    get setUuidInput(): boolean | cdktf.IResolvable | undefined;
    private _superUser?;
    get superUser(): boolean | cdktf.IResolvable;
    set superUser(value: boolean | cdktf.IResolvable);
    resetSuperUser(): void;
    get superUserInput(): boolean | cdktf.IResolvable | undefined;
}
export declare class SfsExportPolicyRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: SfsExportPolicyRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SfsExportPolicyRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy stackit_sfs_export_policy}
*/
export declare class SfsExportPolicy extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_sfs_export_policy";
    /**
    * Generates CDKTF code for importing a SfsExportPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SfsExportPolicy to import
    * @param importFromId The id of the existing SfsExportPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SfsExportPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/sfs_export_policy stackit_sfs_export_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SfsExportPolicyConfig
    */
    constructor(scope: Construct, id: string, config: SfsExportPolicyConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): SfsExportPolicyRulesList;
    putRules(value: SfsExportPolicyRules[] | cdktf.IResolvable): void;
    resetRules(): void;
    get rulesInput(): cdktf.IResolvable | SfsExportPolicyRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
