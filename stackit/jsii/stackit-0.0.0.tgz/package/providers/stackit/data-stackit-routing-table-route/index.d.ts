import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitRoutingTableRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#network_area_id DataStackitRoutingTableRoute#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#organization_id DataStackitRoutingTableRoute#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#region DataStackitRoutingTableRoute#region}
    */
    readonly region?: string;
    /**
    * Route ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#route_id DataStackitRoutingTableRoute#route_id}
    */
    readonly routeId: string;
    /**
    * The routing tables ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#routing_table_id DataStackitRoutingTableRoute#routing_table_id}
    */
    readonly routingTableId: string;
}
export interface DataStackitRoutingTableRouteDestination {
}
export declare function dataStackitRoutingTableRouteDestinationToTerraform(struct?: DataStackitRoutingTableRouteDestination): any;
export declare function dataStackitRoutingTableRouteDestinationToHclTerraform(struct?: DataStackitRoutingTableRouteDestination): any;
export declare class DataStackitRoutingTableRouteDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitRoutingTableRouteDestination | undefined;
    set internalValue(value: DataStackitRoutingTableRouteDestination | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitRoutingTableRouteNextHop {
}
export declare function dataStackitRoutingTableRouteNextHopToTerraform(struct?: DataStackitRoutingTableRouteNextHop): any;
export declare function dataStackitRoutingTableRouteNextHopToHclTerraform(struct?: DataStackitRoutingTableRouteNextHop): any;
export declare class DataStackitRoutingTableRouteNextHopOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitRoutingTableRouteNextHop | undefined;
    set internalValue(value: DataStackitRoutingTableRouteNextHop | undefined);
    get type(): string;
    get value(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route stackit_routing_table_route}
*/
export declare class DataStackitRoutingTableRoute extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_routing_table_route";
    /**
    * Generates CDKTF code for importing a DataStackitRoutingTableRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitRoutingTableRoute to import
    * @param importFromId The id of the existing DataStackitRoutingTableRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitRoutingTableRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/routing_table_route stackit_routing_table_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitRoutingTableRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitRoutingTableRouteConfig);
    get createdAt(): string;
    private _destination;
    get destination(): DataStackitRoutingTableRouteDestinationOutputReference;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _nextHop;
    get nextHop(): DataStackitRoutingTableRouteNextHopOutputReference;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routeId?;
    get routeId(): string;
    set routeId(value: string);
    get routeIdInput(): string | undefined;
    private _routingTableId?;
    get routingTableId(): string;
    set routingTableId(value: string);
    get routingTableIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
