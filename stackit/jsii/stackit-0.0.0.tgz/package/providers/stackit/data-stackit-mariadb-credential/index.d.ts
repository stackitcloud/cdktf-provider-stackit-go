import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitMariadbCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credential's ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential#credential_id DataStackitMariadbCredential#credential_id}
    */
    readonly credentialId: string;
    /**
    * ID of the MariaDB instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential#instance_id DataStackitMariadbCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential#project_id DataStackitMariadbCredential#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential#region DataStackitMariadbCredential#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential stackit_mariadb_credential}
*/
export declare class DataStackitMariadbCredential extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_mariadb_credential";
    /**
    * Generates CDKTF code for importing a DataStackitMariadbCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitMariadbCredential to import
    * @param importFromId The id of the existing DataStackitMariadbCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitMariadbCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/mariadb_credential stackit_mariadb_credential} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitMariadbCredentialConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitMariadbCredentialConfig);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    get credentialIdInput(): string | undefined;
    get host(): string;
    get hosts(): string[];
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get uri(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
