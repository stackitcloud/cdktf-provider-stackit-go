# `stackit_mongodbflex_user`

Refer to the Terraform Registry for docs: [`stackit_mongodbflex_user`](https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/resources/mongodbflex_user).
