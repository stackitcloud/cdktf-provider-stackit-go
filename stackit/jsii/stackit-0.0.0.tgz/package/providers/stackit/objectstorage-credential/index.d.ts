import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObjectstorageCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credential group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential#credentials_group_id ObjectstorageCredential#credentials_group_id}
    */
    readonly credentialsGroupId: string;
    /**
    * Expiration timestamp, in RFC339 format without fractional seconds. Example: "2025-01-01T00:00:00Z". If not set, the credential never expires.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential#expiration_timestamp ObjectstorageCredential#expiration_timestamp}
    */
    readonly expirationTimestamp?: string;
    /**
    * STACKIT Project ID to which the credential group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential#project_id ObjectstorageCredential#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential#region ObjectstorageCredential#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential stackit_objectstorage_credential}
*/
export declare class ObjectstorageCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_objectstorage_credential";
    /**
    * Generates CDKTF code for importing a ObjectstorageCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObjectstorageCredential to import
    * @param importFromId The id of the existing ObjectstorageCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObjectstorageCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/objectstorage_credential stackit_objectstorage_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObjectstorageCredentialConfig
    */
    constructor(scope: Construct, id: string, config: ObjectstorageCredentialConfig);
    get accessKey(): string;
    get credentialId(): string;
    private _credentialsGroupId?;
    get credentialsGroupId(): string;
    set credentialsGroupId(value: string);
    get credentialsGroupIdInput(): string | undefined;
    private _expirationTimestamp?;
    get expirationTimestamp(): string;
    set expirationTimestamp(value: string);
    resetExpirationTimestamp(): void;
    get expirationTimestampInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secretAccessKey(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
