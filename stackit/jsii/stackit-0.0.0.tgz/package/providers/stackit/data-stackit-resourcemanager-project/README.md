# `data_stackit_resourcemanager_project`

Refer to the Terraform Registry for docs: [`data_stackit_resourcemanager_project`](https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/resourcemanager_project).
