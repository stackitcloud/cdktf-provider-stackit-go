import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitResourcemanagerProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Project container ID. Globally unique, user-friendly identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/resourcemanager_project#container_id DataStackitResourcemanagerProject#container_id}
    */
    readonly containerId?: string;
    /**
    * Project UUID identifier. This is the ID that can be used in most of the other resources to identify the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/resourcemanager_project#project_id DataStackitResourcemanagerProject#project_id}
    */
    readonly projectId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/resourcemanager_project stackit_resourcemanager_project}
*/
export declare class DataStackitResourcemanagerProject extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_resourcemanager_project";
    /**
    * Generates CDKTF code for importing a DataStackitResourcemanagerProject resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitResourcemanagerProject to import
    * @param importFromId The id of the existing DataStackitResourcemanagerProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/resourcemanager_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitResourcemanagerProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/resourcemanager_project stackit_resourcemanager_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitResourcemanagerProjectConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataStackitResourcemanagerProjectConfig);
    private _containerId?;
    get containerId(): string;
    set containerId(value: string);
    resetContainerId(): void;
    get containerIdInput(): string | undefined;
    get creationTime(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    get parentContainerId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    resetProjectId(): void;
    get projectIdInput(): string | undefined;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
