import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitPostgresflexDatabaseConfig extends cdktf.TerraformMetaArguments {
    /**
    * Database ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database#database_id DataStackitPostgresflexDatabase#database_id}
    */
    readonly databaseId: string;
    /**
    * ID of the Postgres Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database#instance_id DataStackitPostgresflexDatabase#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database#project_id DataStackitPostgresflexDatabase#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database#region DataStackitPostgresflexDatabase#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database stackit_postgresflex_database}
*/
export declare class DataStackitPostgresflexDatabase extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_postgresflex_database";
    /**
    * Generates CDKTF code for importing a DataStackitPostgresflexDatabase resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitPostgresflexDatabase to import
    * @param importFromId The id of the existing DataStackitPostgresflexDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitPostgresflexDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/data-sources/postgresflex_database stackit_postgresflex_database} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitPostgresflexDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitPostgresflexDatabaseConfig);
    private _databaseId?;
    get databaseId(): string;
    set databaseId(value: string);
    get databaseIdInput(): string | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    get owner(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
