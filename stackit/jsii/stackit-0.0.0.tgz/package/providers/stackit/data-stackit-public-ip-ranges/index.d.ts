import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitPublicIpRangesConfig extends cdktf.TerraformMetaArguments {
}
export interface DataStackitPublicIpRangesPublicIpRanges {
}
export declare function dataStackitPublicIpRangesPublicIpRangesToTerraform(struct?: DataStackitPublicIpRangesPublicIpRanges): any;
export declare function dataStackitPublicIpRangesPublicIpRangesToHclTerraform(struct?: DataStackitPublicIpRangesPublicIpRanges): any;
export declare class DataStackitPublicIpRangesPublicIpRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitPublicIpRangesPublicIpRanges | undefined;
    set internalValue(value: DataStackitPublicIpRangesPublicIpRanges | undefined);
    get cidr(): string;
}
export declare class DataStackitPublicIpRangesPublicIpRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitPublicIpRangesPublicIpRangesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/public_ip_ranges stackit_public_ip_ranges}
*/
export declare class DataStackitPublicIpRanges extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_public_ip_ranges";
    /**
    * Generates CDKTF code for importing a DataStackitPublicIpRanges resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitPublicIpRanges to import
    * @param importFromId The id of the existing DataStackitPublicIpRanges that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/public_ip_ranges#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitPublicIpRanges to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/public_ip_ranges stackit_public_ip_ranges} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitPublicIpRangesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataStackitPublicIpRangesConfig);
    get cidrList(): string[];
    get id(): string;
    private _publicIpRanges;
    get publicIpRanges(): DataStackitPublicIpRangesPublicIpRangesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
