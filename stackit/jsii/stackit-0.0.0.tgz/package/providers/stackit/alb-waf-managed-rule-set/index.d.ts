import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlbWafManagedRuleSetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Rule modes to set, keyed by group ID (e.g. `911`) and rule ID (e.g. `911100`). Only the listed rules are managed; every other rule keeps the mode the API gives it. A rule removed from the configuration is set back to `MODE_ENABLED`, even if its mode was changed outside Terraform in the meantime. The resulting state of all rules is available in `groups`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#configured_groups AlbWafManagedRuleSet#configured_groups}
    */
    readonly configuredGroups?: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroups;
    } | cdktf.IResolvable;
    /**
    * Managed Rule Set configuration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#name AlbWafManagedRuleSet#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the ALB WAF Managed Rule Set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#project_id AlbWafManagedRuleSet#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#region AlbWafManagedRuleSet#region}
    */
    readonly region?: string;
    /**
    * Type of the Managed Rule Set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#type AlbWafManagedRuleSet#type}
    */
    readonly type: string;
}
export interface AlbWafManagedRuleSetConfiguredGroupsRules {
    /**
    * The mode of the rule. Possible values are: `MODE_ENABLED`, `MODE_DISABLED`, `MODE_LOG_ONLY`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#mode AlbWafManagedRuleSet#mode}
    */
    readonly mode: string;
}
export declare function albWafManagedRuleSetConfiguredGroupsRulesToTerraform(struct?: AlbWafManagedRuleSetConfiguredGroupsRules | cdktf.IResolvable): any;
export declare function albWafManagedRuleSetConfiguredGroupsRulesToHclTerraform(struct?: AlbWafManagedRuleSetConfiguredGroupsRules | cdktf.IResolvable): any;
export declare class AlbWafManagedRuleSetConfiguredGroupsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AlbWafManagedRuleSetConfiguredGroupsRules | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafManagedRuleSetConfiguredGroupsRules | cdktf.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export declare class AlbWafManagedRuleSetConfiguredGroupsRulesMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroupsRules;
    } | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AlbWafManagedRuleSetConfiguredGroupsRulesOutputReference;
}
export interface AlbWafManagedRuleSetConfiguredGroups {
    /**
    * Rules of the rule group, keyed by rule ID (e.g. `911100`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#rules AlbWafManagedRuleSet#rules}
    */
    readonly rules: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroupsRules;
    } | cdktf.IResolvable;
}
export declare function albWafManagedRuleSetConfiguredGroupsToTerraform(struct?: AlbWafManagedRuleSetConfiguredGroups | cdktf.IResolvable): any;
export declare function albWafManagedRuleSetConfiguredGroupsToHclTerraform(struct?: AlbWafManagedRuleSetConfiguredGroups | cdktf.IResolvable): any;
export declare class AlbWafManagedRuleSetConfiguredGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AlbWafManagedRuleSetConfiguredGroups | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafManagedRuleSetConfiguredGroups | cdktf.IResolvable | undefined);
    private _rules;
    get rules(): AlbWafManagedRuleSetConfiguredGroupsRulesMap;
    putRules(value: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroupsRules;
    } | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | {
        [key: string]: AlbWafManagedRuleSetConfiguredGroupsRules;
    } | undefined;
}
export declare class AlbWafManagedRuleSetConfiguredGroupsMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    internalValue?: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroups;
    } | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AlbWafManagedRuleSetConfiguredGroupsOutputReference;
}
export interface AlbWafManagedRuleSetGroupsRules {
}
export declare function albWafManagedRuleSetGroupsRulesToTerraform(struct?: AlbWafManagedRuleSetGroupsRules): any;
export declare function albWafManagedRuleSetGroupsRulesToHclTerraform(struct?: AlbWafManagedRuleSetGroupsRules): any;
export declare class AlbWafManagedRuleSetGroupsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AlbWafManagedRuleSetGroupsRules | undefined;
    set internalValue(value: AlbWafManagedRuleSetGroupsRules | undefined);
    get description(): string;
    get mode(): string;
    get severity(): string;
}
export declare class AlbWafManagedRuleSetGroupsRulesMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AlbWafManagedRuleSetGroupsRulesOutputReference;
}
export interface AlbWafManagedRuleSetGroups {
}
export declare function albWafManagedRuleSetGroupsToTerraform(struct?: AlbWafManagedRuleSetGroups): any;
export declare function albWafManagedRuleSetGroupsToHclTerraform(struct?: AlbWafManagedRuleSetGroups): any;
export declare class AlbWafManagedRuleSetGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): AlbWafManagedRuleSetGroups | undefined;
    set internalValue(value: AlbWafManagedRuleSetGroups | undefined);
    get description(): string;
    get groupName(): string;
    private _rules;
    get rules(): AlbWafManagedRuleSetGroupsRulesMap;
}
export declare class AlbWafManagedRuleSetGroupsMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): AlbWafManagedRuleSetGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set stackit_alb_waf_managed_rule_set}
*/
export declare class AlbWafManagedRuleSet extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_alb_waf_managed_rule_set";
    /**
    * Generates CDKTF code for importing a AlbWafManagedRuleSet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlbWafManagedRuleSet to import
    * @param importFromId The id of the existing AlbWafManagedRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlbWafManagedRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/alb_waf_managed_rule_set stackit_alb_waf_managed_rule_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlbWafManagedRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: AlbWafManagedRuleSetConfig);
    private _configuredGroups;
    get configuredGroups(): AlbWafManagedRuleSetConfiguredGroupsMap;
    putConfiguredGroups(value: {
        [key: string]: AlbWafManagedRuleSetConfiguredGroups;
    } | cdktf.IResolvable): void;
    resetConfiguredGroups(): void;
    get configuredGroupsInput(): cdktf.IResolvable | {
        [key: string]: AlbWafManagedRuleSetConfiguredGroups;
    } | undefined;
    private _groups;
    get groups(): AlbWafManagedRuleSetGroupsMap;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
