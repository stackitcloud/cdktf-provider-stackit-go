import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsShareConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the share is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share#project_id DataStackitSfsShare#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. Read-only attribute that reflects the provider region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share#region DataStackitSfsShare#region}
    */
    readonly region?: string;
    /**
    * The ID of the resource pool for the SFS share.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share#resource_pool_id DataStackitSfsShare#resource_pool_id}
    */
    readonly resourcePoolId: string;
    /**
    * share ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share#share_id DataStackitSfsShare#share_id}
    */
    readonly shareId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share stackit_sfs_share}
*/
export declare class DataStackitSfsShare extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_share";
    /**
    * Generates CDKTF code for importing a DataStackitSfsShare resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsShare to import
    * @param importFromId The id of the existing DataStackitSfsShare that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsShare to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/data-sources/sfs_share stackit_sfs_share} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsShareConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsShareConfig);
    get exportPolicy(): string;
    get id(): string;
    get mountPath(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcePoolId?;
    get resourcePoolId(): string;
    set resourcePoolId(value: string);
    get resourcePoolIdInput(): string | undefined;
    private _shareId?;
    get shareId(): string;
    set shareId(value: string);
    get shareIdInput(): string | undefined;
    get spaceHardLimitGigabytes(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
