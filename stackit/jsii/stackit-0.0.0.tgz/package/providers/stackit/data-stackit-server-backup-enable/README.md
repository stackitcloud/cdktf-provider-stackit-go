# `data_stackit_server_backup_enable`

Refer to the Terraform Registry for docs: [`data_stackit_server_backup_enable`](https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/server_backup_enable).
