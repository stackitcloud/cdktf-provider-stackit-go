# `data_stackit_security_group`

Refer to the Terraform Registry for docs: [`data_stackit_security_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.116.0/docs/data-sources/security_group).
