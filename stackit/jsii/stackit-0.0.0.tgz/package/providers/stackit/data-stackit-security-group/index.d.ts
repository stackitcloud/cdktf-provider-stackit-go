import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSecurityGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the security group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group#project_id DataStackitSecurityGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group#region DataStackitSecurityGroup#region}
    */
    readonly region?: string;
    /**
    * The security group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group#security_group_id DataStackitSecurityGroup#security_group_id}
    */
    readonly securityGroupId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group stackit_security_group}
*/
export declare class DataStackitSecurityGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_security_group";
    /**
    * Generates CDKTF code for importing a DataStackitSecurityGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSecurityGroup to import
    * @param importFromId The id of the existing DataStackitSecurityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSecurityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/security_group stackit_security_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSecurityGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSecurityGroupConfig);
    get description(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    get stateful(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
