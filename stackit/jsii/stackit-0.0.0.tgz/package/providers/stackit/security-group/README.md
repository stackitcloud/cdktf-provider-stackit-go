# `stackit_security_group`

Refer to the Terraform Registry for docs: [`stackit_security_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/security_group).
