import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecurityGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the security group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#description SecurityGroup#description}
    */
    readonly description?: string;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#labels SecurityGroup#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the security group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#name SecurityGroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the security group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#project_id SecurityGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#region SecurityGroup#region}
    */
    readonly region?: string;
    /**
    * Configures if a security group is stateful or stateless. There can only be one type of security groups per network interface/server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#stateful SecurityGroup#stateful}
    */
    readonly stateful?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group stackit_security_group}
*/
export declare class SecurityGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_security_group";
    /**
    * Generates CDKTF code for importing a SecurityGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityGroup to import
    * @param importFromId The id of the existing SecurityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/security_group stackit_security_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityGroupConfig
    */
    constructor(scope: Construct, id: string, config: SecurityGroupConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroupId(): string;
    private _stateful?;
    get stateful(): boolean | cdktf.IResolvable;
    set stateful(value: boolean | cdktf.IResolvable);
    resetStateful(): void;
    get statefulInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
