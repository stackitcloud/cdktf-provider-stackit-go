import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecretsmanagerInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list for this instance. Each entry is an IP or IP range that is permitted to access, in CIDR notation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance#acls SecretsmanagerInstance#acls}
    */
    readonly acls?: string[];
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance#name SecretsmanagerInstance#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance#project_id SecretsmanagerInstance#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance stackit_secretsmanager_instance}
*/
export declare class SecretsmanagerInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_secretsmanager_instance";
    /**
    * Generates CDKTF code for importing a SecretsmanagerInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsmanagerInstance to import
    * @param importFromId The id of the existing SecretsmanagerInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsmanagerInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/secretsmanager_instance stackit_secretsmanager_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsmanagerInstanceConfig
    */
    constructor(scope: Construct, id: string, config: SecretsmanagerInstanceConfig);
    private _acls?;
    get acls(): string[];
    set acls(value: string[]);
    resetAcls(): void;
    get aclsInput(): string[] | undefined;
    get id(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
