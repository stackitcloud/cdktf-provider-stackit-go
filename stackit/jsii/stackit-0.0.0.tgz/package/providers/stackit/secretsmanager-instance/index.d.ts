import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecretsmanagerInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access control list for this instance. Each entry is an IP or IP range that is permitted to access, in CIDR notation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#acls SecretsmanagerInstance#acls}
    */
    readonly acls?: string[];
    /**
    * The STACKIT-KMS key for secret encryption and decryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#kms_key SecretsmanagerInstance#kms_key}
    */
    readonly kmsKey?: SecretsmanagerInstanceKmsKey;
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#name SecretsmanagerInstance#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#project_id SecretsmanagerInstance#project_id}
    */
    readonly projectId: string;
}
export interface SecretsmanagerInstanceKmsKey {
    /**
    * UUID of the key within the STACKIT-KMS to use for the encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#key_id SecretsmanagerInstance#key_id}
    */
    readonly keyId: string;
    /**
    * UUID of the keyring where the key is located within the STACKTI-KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#key_ring_id SecretsmanagerInstance#key_ring_id}
    */
    readonly keyRingId: string;
    /**
    * Version of the key within the STACKIT-KMS to use for the encryption.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#key_version SecretsmanagerInstance#key_version}
    */
    readonly keyVersion: number;
    /**
    * Service-Account linked to the Key within the STACKIT-KMS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#service_account_email SecretsmanagerInstance#service_account_email}
    */
    readonly serviceAccountEmail: string;
}
export declare function secretsmanagerInstanceKmsKeyToTerraform(struct?: SecretsmanagerInstanceKmsKey | cdktf.IResolvable): any;
export declare function secretsmanagerInstanceKmsKeyToHclTerraform(struct?: SecretsmanagerInstanceKmsKey | cdktf.IResolvable): any;
export declare class SecretsmanagerInstanceKmsKeyOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecretsmanagerInstanceKmsKey | cdktf.IResolvable | undefined;
    set internalValue(value: SecretsmanagerInstanceKmsKey | cdktf.IResolvable | undefined);
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _keyRingId?;
    get keyRingId(): string;
    set keyRingId(value: string);
    get keyRingIdInput(): string | undefined;
    private _keyVersion?;
    get keyVersion(): number;
    set keyVersion(value: number);
    get keyVersionInput(): number | undefined;
    private _serviceAccountEmail?;
    get serviceAccountEmail(): string;
    set serviceAccountEmail(value: string);
    get serviceAccountEmailInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance stackit_secretsmanager_instance}
*/
export declare class SecretsmanagerInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_secretsmanager_instance";
    /**
    * Generates CDKTF code for importing a SecretsmanagerInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecretsmanagerInstance to import
    * @param importFromId The id of the existing SecretsmanagerInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecretsmanagerInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/secretsmanager_instance stackit_secretsmanager_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecretsmanagerInstanceConfig
    */
    constructor(scope: Construct, id: string, config: SecretsmanagerInstanceConfig);
    private _acls?;
    get acls(): string[];
    set acls(value: string[]);
    resetAcls(): void;
    get aclsInput(): string[] | undefined;
    get id(): string;
    get instanceId(): string;
    private _kmsKey;
    get kmsKey(): SecretsmanagerInstanceKmsKeyOutputReference;
    putKmsKey(value: SecretsmanagerInstanceKmsKey): void;
    resetKmsKey(): void;
    get kmsKeyInput(): cdktf.IResolvable | SecretsmanagerInstanceKmsKey | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
