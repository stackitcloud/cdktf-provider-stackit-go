# `data_stackit_network_interface`

Refer to the Terraform Registry for docs: [`data_stackit_network_interface`](https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/data-sources/network_interface).
