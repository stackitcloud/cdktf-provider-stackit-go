import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitNetworkInterfaceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network ID to which the network interface is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface#network_id DataStackitNetworkInterface#network_id}
    */
    readonly networkId: string;
    /**
    * The network interface ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface#network_interface_id DataStackitNetworkInterface#network_interface_id}
    */
    readonly networkInterfaceId: string;
    /**
    * STACKIT project ID to which the network interface is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface#project_id DataStackitNetworkInterface#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface#region DataStackitNetworkInterface#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface stackit_network_interface}
*/
export declare class DataStackitNetworkInterface extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_network_interface";
    /**
    * Generates CDKTF code for importing a DataStackitNetworkInterface resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitNetworkInterface to import
    * @param importFromId The id of the existing DataStackitNetworkInterface that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitNetworkInterface to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_interface stackit_network_interface} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitNetworkInterfaceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitNetworkInterfaceConfig);
    get allowedAddresses(): string[];
    get device(): string;
    get id(): string;
    get ipv4(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get mac(): string;
    get name(): string;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _networkInterfaceId?;
    get networkInterfaceId(): string;
    set networkInterfaceId(value: string);
    get networkInterfaceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get security(): cdktf.IResolvable;
    get securityGroupIds(): string[];
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
