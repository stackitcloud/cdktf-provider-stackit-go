import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObservabilityAlertgroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability instance ID to which the alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup#instance_id DataStackitObservabilityAlertgroup#instance_id}
    */
    readonly instanceId: string;
    /**
    * The name of the alert group. Is the identifier and must be unique in the group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup#name DataStackitObservabilityAlertgroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the alert group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup#project_id DataStackitObservabilityAlertgroup#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitObservabilityAlertgroupRules {
}
export declare function dataStackitObservabilityAlertgroupRulesToTerraform(struct?: DataStackitObservabilityAlertgroupRules): any;
export declare function dataStackitObservabilityAlertgroupRulesToHclTerraform(struct?: DataStackitObservabilityAlertgroupRules): any;
export declare class DataStackitObservabilityAlertgroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityAlertgroupRules | undefined;
    set internalValue(value: DataStackitObservabilityAlertgroupRules | undefined);
    get alert(): string;
    private _annotations;
    get annotations(): cdktf.StringMap;
    get expression(): string;
    get for(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get record(): string;
}
export declare class DataStackitObservabilityAlertgroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityAlertgroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup stackit_observability_alertgroup}
*/
export declare class DataStackitObservabilityAlertgroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_observability_alertgroup";
    /**
    * Generates CDKTF code for importing a DataStackitObservabilityAlertgroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObservabilityAlertgroup to import
    * @param importFromId The id of the existing DataStackitObservabilityAlertgroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObservabilityAlertgroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.101.0/docs/data-sources/observability_alertgroup stackit_observability_alertgroup} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObservabilityAlertgroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObservabilityAlertgroupConfig);
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get interval(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _rules;
    get rules(): DataStackitObservabilityAlertgroupRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
