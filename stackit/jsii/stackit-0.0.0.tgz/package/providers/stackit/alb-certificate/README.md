# `stackit_alb_certificate`

Refer to the Terraform Registry for docs: [`stackit_alb_certificate`](https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/resources/alb_certificate).
