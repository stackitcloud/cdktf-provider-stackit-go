import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlbCertificateConfig extends cdktf.TerraformMetaArguments {
    /**
    * Certificate name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#name AlbCertificate#name}
    */
    readonly name: string;
    /**
    * The PEM encoded private key part
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#private_key AlbCertificate#private_key}
    */
    readonly privateKey: string;
    /**
    * STACKIT project ID to which the certificate is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#project_id AlbCertificate#project_id}
    */
    readonly projectId: string;
    /**
    * The PEM encoded public key part
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#public_key AlbCertificate#public_key}
    */
    readonly publicKey: string;
    /**
    * The resource region (e.g. eu01). If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#region AlbCertificate#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate stackit_alb_certificate}
*/
export declare class AlbCertificate extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_alb_certificate";
    /**
    * Generates CDKTF code for importing a AlbCertificate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlbCertificate to import
    * @param importFromId The id of the existing AlbCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlbCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/resources/alb_certificate stackit_alb_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlbCertificateConfig
    */
    constructor(scope: Construct, id: string, config: AlbCertificateConfig);
    get certId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    get privateKeyInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
