import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KmsKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The access scope of the key. Default is `PUBLIC`. Possible values are: `PUBLIC`, `SNA`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#access_scope KmsKey#access_scope}
    */
    readonly accessScope?: string;
    /**
    * The encryption algorithm that the key will use to encrypt data. Possible values are: `aes_256_gcm`, `rsa_2048_oaep_sha256`, `rsa_3072_oaep_sha256`, `rsa_4096_oaep_sha256`, `rsa_4096_oaep_sha512`, `hmac_sha256`, `hmac_sha384`, `hmac_sha512`, `ecdsa_p256_sha256`, `ecdsa_p384_sha384`, `ecdsa_p521_sha512`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#algorithm KmsKey#algorithm}
    */
    readonly algorithm: string;
    /**
    * A user chosen description to distinguish multiple keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#description KmsKey#description}
    */
    readonly description?: string;
    /**
    * The display name to distinguish multiple keys
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#display_name KmsKey#display_name}
    */
    readonly displayName: string;
    /**
    * States whether versions can be created or only imported.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#import_only KmsKey#import_only}
    */
    readonly importOnly?: boolean | cdktf.IResolvable;
    /**
    * The ID of the associated keyring
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#keyring_id KmsKey#keyring_id}
    */
    readonly keyringId: string;
    /**
    * STACKIT project ID to which the key is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#project_id KmsKey#project_id}
    */
    readonly projectId: string;
    /**
    * The underlying system that is responsible for protecting the key material. Possible values are: `software`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#protection KmsKey#protection}
    */
    readonly protection: string;
    /**
    * The purpose for which the key will be used. Possible values are: `symmetric_encrypt_decrypt`, `asymmetric_encrypt_decrypt`, `message_authentication_code`, `asymmetric_sign_verify`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#purpose KmsKey#purpose}
    */
    readonly purpose: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#region KmsKey#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key stackit_kms_key}
*/
export declare class KmsKey extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_kms_key";
    /**
    * Generates CDKTF code for importing a KmsKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmsKey to import
    * @param importFromId The id of the existing KmsKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmsKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/kms_key stackit_kms_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmsKeyConfig
    */
    constructor(scope: Construct, id: string, config: KmsKeyConfig);
    private _accessScope?;
    get accessScope(): string;
    set accessScope(value: string);
    resetAccessScope(): void;
    get accessScopeInput(): string | undefined;
    private _algorithm?;
    get algorithm(): string;
    set algorithm(value: string);
    get algorithmInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    private _importOnly?;
    get importOnly(): boolean | cdktf.IResolvable;
    set importOnly(value: boolean | cdktf.IResolvable);
    resetImportOnly(): void;
    get importOnlyInput(): boolean | cdktf.IResolvable | undefined;
    get keyId(): string;
    private _keyringId?;
    get keyringId(): string;
    set keyringId(value: string);
    get keyringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protection?;
    get protection(): string;
    set protection(value: string);
    get protectionInput(): string | undefined;
    private _purpose?;
    get purpose(): string;
    set purpose(value: string);
    get purposeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
