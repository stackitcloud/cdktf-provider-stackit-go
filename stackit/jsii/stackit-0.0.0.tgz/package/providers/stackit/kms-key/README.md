# `stackit_kms_key`

Refer to the Terraform Registry for docs: [`stackit_kms_key`](https://registry.terraform.io/providers/stackitcloud/stackit/0.122.0/docs/resources/kms_key).
