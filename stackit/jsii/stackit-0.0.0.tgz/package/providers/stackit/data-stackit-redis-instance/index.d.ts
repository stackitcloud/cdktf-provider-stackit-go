import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitRedisInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Redis instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/redis_instance#instance_id DataStackitRedisInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/redis_instance#project_id DataStackitRedisInstance#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitRedisInstanceParameters {
}
export declare function dataStackitRedisInstanceParametersToTerraform(struct?: DataStackitRedisInstanceParameters): any;
export declare function dataStackitRedisInstanceParametersToHclTerraform(struct?: DataStackitRedisInstanceParameters): any;
export declare class DataStackitRedisInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitRedisInstanceParameters | undefined;
    set internalValue(value: DataStackitRedisInstanceParameters | undefined);
    get downAfterMilliseconds(): number;
    get enableMonitoring(): cdktf.IResolvable;
    get failoverTimeout(): number;
    get graphite(): string;
    get lazyfreeLazyEviction(): string;
    get lazyfreeLazyExpire(): string;
    get luaTimeLimit(): number;
    get maxDiskThreshold(): number;
    get maxclients(): number;
    get maxmemoryPolicy(): string;
    get maxmemorySamples(): number;
    get metricsFrequency(): number;
    get metricsPrefix(): string;
    get minReplicasMaxLag(): number;
    get monitoringInstanceId(): string;
    get notifyKeyspaceEvents(): string;
    get sgwAcl(): string;
    get snapshot(): string;
    get syslog(): string[];
    get tlsCiphers(): string[];
    get tlsCiphersuites(): string;
    get tlsProtocols(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/redis_instance stackit_redis_instance}
*/
export declare class DataStackitRedisInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_redis_instance";
    /**
    * Generates CDKTF code for importing a DataStackitRedisInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitRedisInstance to import
    * @param importFromId The id of the existing DataStackitRedisInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/redis_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitRedisInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/data-sources/redis_instance stackit_redis_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitRedisInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitRedisInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _parameters;
    get parameters(): DataStackitRedisInstanceParametersOutputReference;
    get planId(): string;
    get planName(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
