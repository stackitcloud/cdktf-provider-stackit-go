import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAlbWafConfigurationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the WAF Configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration#name DataStackitAlbWafConfiguration#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the WAF Configuration is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration#project_id DataStackitAlbWafConfiguration#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region (e.g. eu01). If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration#region DataStackitAlbWafConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration stackit_alb_waf_configuration}
*/
export declare class DataStackitAlbWafConfiguration extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_alb_waf_configuration";
    /**
    * Generates CDKTF code for importing a DataStackitAlbWafConfiguration resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAlbWafConfiguration to import
    * @param importFromId The id of the existing DataStackitAlbWafConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAlbWafConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/data-sources/alb_waf_configuration stackit_alb_waf_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAlbWafConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAlbWafConfigurationConfig);
    get customRuleGroupName(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get managedRuleSetName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
