# `stackit_telemetryrouter_instance`

Refer to the Terraform Registry for docs: [`stackit_telemetryrouter_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/telemetryrouter_instance).
