import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObjectstorageComplianceLockConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID to which the compliance lock is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/objectstorage_compliance_lock#project_id DataStackitObjectstorageComplianceLock#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/objectstorage_compliance_lock#region DataStackitObjectstorageComplianceLock#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/objectstorage_compliance_lock stackit_objectstorage_compliance_lock}
*/
export declare class DataStackitObjectstorageComplianceLock extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_objectstorage_compliance_lock";
    /**
    * Generates CDKTF code for importing a DataStackitObjectstorageComplianceLock resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObjectstorageComplianceLock to import
    * @param importFromId The id of the existing DataStackitObjectstorageComplianceLock that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/objectstorage_compliance_lock#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObjectstorageComplianceLock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/data-sources/objectstorage_compliance_lock stackit_objectstorage_compliance_lock} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObjectstorageComplianceLockConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObjectstorageComplianceLockConfig);
    get id(): string;
    get maxRetentionDays(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
