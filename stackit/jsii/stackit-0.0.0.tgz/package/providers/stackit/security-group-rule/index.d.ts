import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SecurityGroupRuleConfig extends cdktf.TerraformMetaArguments {
    /**
    * The rule description.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#description SecurityGroupRule#description}
    */
    readonly description?: string;
    /**
    * The direction of the traffic which the rule should match. Some of the possible values are: Possible values are: `ingress`, `egress`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#direction SecurityGroupRule#direction}
    */
    readonly direction: string;
    /**
    * The ethertype which the rule should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#ether_type SecurityGroupRule#ether_type}
    */
    readonly etherType?: string;
    /**
    * ICMP Parameters. These parameters should only be provided if the protocol is ICMP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#icmp_parameters SecurityGroupRule#icmp_parameters}
    */
    readonly icmpParameters?: SecurityGroupRuleIcmpParameters;
    /**
    * The remote IP range which the rule should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#ip_range SecurityGroupRule#ip_range}
    */
    readonly ipRange?: string;
    /**
    * The range of ports. This should only be provided if the protocol is not ICMP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#port_range SecurityGroupRule#port_range}
    */
    readonly portRange?: SecurityGroupRulePortRange;
    /**
    * STACKIT project ID to which the security group rule is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#project_id SecurityGroupRule#project_id}
    */
    readonly projectId: string;
    /**
    * The internet protocol which the rule should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#protocol SecurityGroupRule#protocol}
    */
    readonly protocol?: SecurityGroupRuleProtocol;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#region SecurityGroupRule#region}
    */
    readonly region?: string;
    /**
    * The remote security group which the rule should match.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#remote_security_group_id SecurityGroupRule#remote_security_group_id}
    */
    readonly remoteSecurityGroupId?: string;
    /**
    * The security group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#security_group_id SecurityGroupRule#security_group_id}
    */
    readonly securityGroupId: string;
}
export interface SecurityGroupRuleIcmpParameters {
    /**
    * ICMP code. Can be set if the protocol is ICMP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#code SecurityGroupRule#code}
    */
    readonly code: number;
    /**
    * ICMP type. Can be set if the protocol is ICMP.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#type SecurityGroupRule#type}
    */
    readonly type: number;
}
export declare function securityGroupRuleIcmpParametersToTerraform(struct?: SecurityGroupRuleIcmpParameters | cdktf.IResolvable): any;
export declare function securityGroupRuleIcmpParametersToHclTerraform(struct?: SecurityGroupRuleIcmpParameters | cdktf.IResolvable): any;
export declare class SecurityGroupRuleIcmpParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityGroupRuleIcmpParameters | cdktf.IResolvable | undefined;
    set internalValue(value: SecurityGroupRuleIcmpParameters | cdktf.IResolvable | undefined);
    private _code?;
    get code(): number;
    set code(value: number);
    get codeInput(): number | undefined;
    private _type?;
    get type(): number;
    set type(value: number);
    get typeInput(): number | undefined;
}
export interface SecurityGroupRulePortRange {
    /**
    * The maximum port number. Should be greater or equal to the minimum.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#max SecurityGroupRule#max}
    */
    readonly max: number;
    /**
    * The minimum port number. Should be less or equal to the maximum.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#min SecurityGroupRule#min}
    */
    readonly min: number;
}
export declare function securityGroupRulePortRangeToTerraform(struct?: SecurityGroupRulePortRange | cdktf.IResolvable): any;
export declare function securityGroupRulePortRangeToHclTerraform(struct?: SecurityGroupRulePortRange | cdktf.IResolvable): any;
export declare class SecurityGroupRulePortRangeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityGroupRulePortRange | cdktf.IResolvable | undefined;
    set internalValue(value: SecurityGroupRulePortRange | cdktf.IResolvable | undefined);
    private _max?;
    get max(): number;
    set max(value: number);
    get maxInput(): number | undefined;
    private _min?;
    get min(): number;
    set min(value: number);
    get minInput(): number | undefined;
}
export interface SecurityGroupRuleProtocol {
    /**
    * The protocol name which the rule should match. Either `name` or `number` must be provided. Possible values are: `ah`, `dccp`, `egp`, `esp`, `gre`, `icmp`, `igmp`, `ipip`, `ipv6-encap`, `ipv6-frag`, `ipv6-icmp`, `ipv6-nonxt`, `ipv6-opts`, `ipv6-route`, `ospf`, `pgm`, `rsvp`, `sctp`, `tcp`, `udp`, `udplite`, `vrrp`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#name SecurityGroupRule#name}
    */
    readonly name?: string;
    /**
    * The protocol number which the rule should match. Either `name` or `number` must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#number SecurityGroupRule#number}
    */
    readonly number?: number;
}
export declare function securityGroupRuleProtocolToTerraform(struct?: SecurityGroupRuleProtocol | cdktf.IResolvable): any;
export declare function securityGroupRuleProtocolToHclTerraform(struct?: SecurityGroupRuleProtocol | cdktf.IResolvable): any;
export declare class SecurityGroupRuleProtocolOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SecurityGroupRuleProtocol | cdktf.IResolvable | undefined;
    set internalValue(value: SecurityGroupRuleProtocol | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _number?;
    get number(): number;
    set number(value: number);
    resetNumber(): void;
    get numberInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule stackit_security_group_rule}
*/
export declare class SecurityGroupRule extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_security_group_rule";
    /**
    * Generates CDKTF code for importing a SecurityGroupRule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SecurityGroupRule to import
    * @param importFromId The id of the existing SecurityGroupRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SecurityGroupRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/security_group_rule stackit_security_group_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SecurityGroupRuleConfig
    */
    constructor(scope: Construct, id: string, config: SecurityGroupRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _direction?;
    get direction(): string;
    set direction(value: string);
    get directionInput(): string | undefined;
    private _etherType?;
    get etherType(): string;
    set etherType(value: string);
    resetEtherType(): void;
    get etherTypeInput(): string | undefined;
    private _icmpParameters;
    get icmpParameters(): SecurityGroupRuleIcmpParametersOutputReference;
    putIcmpParameters(value: SecurityGroupRuleIcmpParameters): void;
    resetIcmpParameters(): void;
    get icmpParametersInput(): cdktf.IResolvable | SecurityGroupRuleIcmpParameters | undefined;
    get id(): string;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    resetIpRange(): void;
    get ipRangeInput(): string | undefined;
    private _portRange;
    get portRange(): SecurityGroupRulePortRangeOutputReference;
    putPortRange(value: SecurityGroupRulePortRange): void;
    resetPortRange(): void;
    get portRangeInput(): cdktf.IResolvable | SecurityGroupRulePortRange | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _protocol;
    get protocol(): SecurityGroupRuleProtocolOutputReference;
    putProtocol(value: SecurityGroupRuleProtocol): void;
    resetProtocol(): void;
    get protocolInput(): cdktf.IResolvable | SecurityGroupRuleProtocol | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _remoteSecurityGroupId?;
    get remoteSecurityGroupId(): string;
    set remoteSecurityGroupId(value: string);
    resetRemoteSecurityGroupId(): void;
    get remoteSecurityGroupIdInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    get securityGroupRuleId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
