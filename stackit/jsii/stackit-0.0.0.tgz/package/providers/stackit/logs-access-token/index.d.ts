import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface LogsAccessTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#description LogsAccessToken#description}
    */
    readonly description?: string;
    /**
    * The displayed name of the access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#display_name LogsAccessToken#display_name}
    */
    readonly displayName: string;
    /**
    * The Logs instance ID associated with the access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#instance_id LogsAccessToken#instance_id}
    */
    readonly instanceId: string;
    /**
    * A lifetime period for an access token in days. If unset the token will not expire.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#lifetime LogsAccessToken#lifetime}
    */
    readonly lifetime?: number;
    /**
    * The access permissions granted to the access token. Possible values: `read`, `write`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#permissions LogsAccessToken#permissions}
    */
    readonly permissions: string[];
    /**
    * STACKIT project ID associated with the Logs access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#project_id LogsAccessToken#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#region LogsAccessToken#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token stackit_logs_access_token}
*/
export declare class LogsAccessToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_logs_access_token";
    /**
    * Generates CDKTF code for importing a LogsAccessToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogsAccessToken to import
    * @param importFromId The id of the existing LogsAccessToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogsAccessToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/logs_access_token stackit_logs_access_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogsAccessTokenConfig
    */
    constructor(scope: Construct, id: string, config: LogsAccessTokenConfig);
    get accessToken(): string;
    get accessTokenId(): string;
    get creator(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get expires(): cdktf.IResolvable;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _lifetime?;
    get lifetime(): number;
    set lifetime(value: number);
    resetLifetime(): void;
    get lifetimeInput(): number | undefined;
    private _permissions?;
    get permissions(): string[];
    set permissions(value: string[]);
    get permissionsInput(): string[] | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get validUntil(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
