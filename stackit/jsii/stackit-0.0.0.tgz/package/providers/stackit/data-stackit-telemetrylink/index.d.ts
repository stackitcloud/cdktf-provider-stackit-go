import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitTelemetrylinkConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink#region DataStackitTelemetrylink#region}
    */
    readonly region?: string;
    /**
    * STACKIT project ID, folder ID, or organization ID associated with the Telemetry Link resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink#resource_id DataStackitTelemetrylink#resource_id}
    */
    readonly resourceId: string;
    /**
    * The resource type of the TelemetryLink resource, possible values: Possible values are: `organization`, `folder`, `project`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink#resource_type DataStackitTelemetrylink#resource_type}
    */
    readonly resourceType: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink stackit_telemetrylink}
*/
export declare class DataStackitTelemetrylink extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_telemetrylink";
    /**
    * Generates CDKTF code for importing a DataStackitTelemetrylink resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitTelemetrylink to import
    * @param importFromId The id of the existing DataStackitTelemetrylink that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitTelemetrylink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/telemetrylink stackit_telemetrylink} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitTelemetrylinkConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitTelemetrylinkConfig);
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    get status(): string;
    get telemetryRouterId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
