# `data_stackit_telemetrylink`

Refer to the Terraform Registry for docs: [`data_stackit_telemetrylink`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/data-sources/telemetrylink).
