# `data_stackit_service_accounts`

Refer to the Terraform Registry for docs: [`data_stackit_service_accounts`](https://registry.terraform.io/providers/stackitcloud/stackit/0.113.0/docs/data-sources/service_accounts).
