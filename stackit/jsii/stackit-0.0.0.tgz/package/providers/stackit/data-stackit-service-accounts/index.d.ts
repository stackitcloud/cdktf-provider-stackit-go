import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServiceAccountsConfig extends cdktf.TerraformMetaArguments {
    /**
    * Optional regular expression to filter service accounts by email.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts#email_regex DataStackitServiceAccounts#email_regex}
    */
    readonly emailRegex?: string;
    /**
    * Optional suffix to filter service accounts by email (e.g.,`@sa.stackit.cloud`, `@ske.sa.stackit.cloud`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts#email_suffix DataStackitServiceAccounts#email_suffix}
    */
    readonly emailSuffix?: string;
    /**
    * STACKIT project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts#project_id DataStackitServiceAccounts#project_id}
    */
    readonly projectId: string;
    /**
    * If set to `true`, service accounts are sorted in ascending lexicographical order by email. Defaults to `false` (descending).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts#sort_ascending DataStackitServiceAccounts#sort_ascending}
    */
    readonly sortAscending?: boolean | cdktf.IResolvable;
}
export interface DataStackitServiceAccountsItems {
}
export declare function dataStackitServiceAccountsItemsToTerraform(struct?: DataStackitServiceAccountsItems): any;
export declare function dataStackitServiceAccountsItemsToHclTerraform(struct?: DataStackitServiceAccountsItems): any;
export declare class DataStackitServiceAccountsItemsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitServiceAccountsItems | undefined;
    set internalValue(value: DataStackitServiceAccountsItems | undefined);
    get email(): string;
    get name(): string;
    get serviceAccountId(): string;
}
export declare class DataStackitServiceAccountsItemsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitServiceAccountsItemsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts stackit_service_accounts}
*/
export declare class DataStackitServiceAccounts extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_service_accounts";
    /**
    * Generates CDKTF code for importing a DataStackitServiceAccounts resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServiceAccounts to import
    * @param importFromId The id of the existing DataStackitServiceAccounts that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServiceAccounts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/service_accounts stackit_service_accounts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServiceAccountsConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServiceAccountsConfig);
    private _emailRegex?;
    get emailRegex(): string;
    set emailRegex(value: string);
    resetEmailRegex(): void;
    get emailRegexInput(): string | undefined;
    private _emailSuffix?;
    get emailSuffix(): string;
    set emailSuffix(value: string);
    resetEmailSuffix(): void;
    get emailSuffixInput(): string | undefined;
    get id(): string;
    private _items;
    get items(): DataStackitServiceAccountsItemsList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _sortAscending?;
    get sortAscending(): boolean | cdktf.IResolvable;
    set sortAscending(value: boolean | cdktf.IResolvable);
    resetSortAscending(): void;
    get sortAscendingInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
