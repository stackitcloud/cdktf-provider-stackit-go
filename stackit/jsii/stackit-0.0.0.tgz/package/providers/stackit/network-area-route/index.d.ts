import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkAreaRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * Destination of the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#destination NetworkAreaRoute#destination}
    */
    readonly destination: NetworkAreaRouteDestination;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#labels NetworkAreaRoute#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The network area ID to which the network area route is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#network_area_id NetworkAreaRoute#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * Next hop destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#next_hop NetworkAreaRoute#next_hop}
    */
    readonly nextHop: NetworkAreaRouteNextHop;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#organization_id NetworkAreaRoute#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#region NetworkAreaRoute#region}
    */
    readonly region?: string;
}
export interface NetworkAreaRouteDestination {
    /**
    * CIDRV type. Possible values are: `cidrv4`, `cidrv6`. Only `cidrv4` is supported currently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#type NetworkAreaRoute#type}
    */
    readonly type: string;
    /**
    * An CIDR string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#value NetworkAreaRoute#value}
    */
    readonly value: string;
}
export declare function networkAreaRouteDestinationToTerraform(struct?: NetworkAreaRouteDestination | cdktf.IResolvable): any;
export declare function networkAreaRouteDestinationToHclTerraform(struct?: NetworkAreaRouteDestination | cdktf.IResolvable): any;
export declare class NetworkAreaRouteDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkAreaRouteDestination | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkAreaRouteDestination | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface NetworkAreaRouteNextHop {
    /**
    * Type of the next hop. Possible values are: `blackhole`, `internet`, `ipv4`, `ipv6`. Only `ipv4` supported currently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#type NetworkAreaRoute#type}
    */
    readonly type: string;
    /**
    * Either IPv4 or IPv6 (not set for blackhole and internet). Only IPv4 supported currently.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#value NetworkAreaRoute#value}
    */
    readonly value?: string;
}
export declare function networkAreaRouteNextHopToTerraform(struct?: NetworkAreaRouteNextHop | cdktf.IResolvable): any;
export declare function networkAreaRouteNextHopToHclTerraform(struct?: NetworkAreaRouteNextHop | cdktf.IResolvable): any;
export declare class NetworkAreaRouteNextHopOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NetworkAreaRouteNextHop | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkAreaRouteNextHop | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route stackit_network_area_route}
*/
export declare class NetworkAreaRoute extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_network_area_route";
    /**
    * Generates CDKTF code for importing a NetworkAreaRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkAreaRoute to import
    * @param importFromId The id of the existing NetworkAreaRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkAreaRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/network_area_route stackit_network_area_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkAreaRouteConfig
    */
    constructor(scope: Construct, id: string, config: NetworkAreaRouteConfig);
    private _destination;
    get destination(): NetworkAreaRouteDestinationOutputReference;
    putDestination(value: NetworkAreaRouteDestination): void;
    get destinationInput(): cdktf.IResolvable | NetworkAreaRouteDestination | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    get networkAreaRouteId(): string;
    private _nextHop;
    get nextHop(): NetworkAreaRouteNextHopOutputReference;
    putNextHop(value: NetworkAreaRouteNextHop): void;
    get nextHopInput(): cdktf.IResolvable | NetworkAreaRouteNextHop | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
