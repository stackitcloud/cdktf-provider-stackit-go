import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsProjectLockConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT Project ID to which the project lock is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/sfs_project_lock#project_id DataStackitSfsProjectLock#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/sfs_project_lock#region DataStackitSfsProjectLock#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/sfs_project_lock stackit_sfs_project_lock}
*/
export declare class DataStackitSfsProjectLock extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_project_lock";
    /**
    * Generates CDKTF code for importing a DataStackitSfsProjectLock resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsProjectLock to import
    * @param importFromId The id of the existing DataStackitSfsProjectLock that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/sfs_project_lock#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsProjectLock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/sfs_project_lock stackit_sfs_project_lock} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsProjectLockConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsProjectLockConfig);
    get id(): string;
    get lockId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
