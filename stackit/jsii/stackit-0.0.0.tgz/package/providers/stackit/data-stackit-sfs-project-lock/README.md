# `data_stackit_sfs_project_lock`

Refer to the Terraform Registry for docs: [`data_stackit_sfs_project_lock`](https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/sfs_project_lock).
