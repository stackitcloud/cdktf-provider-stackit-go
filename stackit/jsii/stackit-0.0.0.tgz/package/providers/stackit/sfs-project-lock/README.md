# `stackit_sfs_project_lock`

Refer to the Terraform Registry for docs: [`stackit_sfs_project_lock`](https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/resources/sfs_project_lock).
