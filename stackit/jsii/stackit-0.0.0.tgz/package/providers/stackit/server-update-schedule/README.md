# `stackit_server_update_schedule`

Refer to the Terraform Registry for docs: [`stackit_server_update_schedule`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/server_update_schedule).
