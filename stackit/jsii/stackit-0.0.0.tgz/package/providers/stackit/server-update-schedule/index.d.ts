import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerUpdateScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Is the update schedule enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#enabled ServerUpdateSchedule#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * Maintenance window [1..24]. Updates start within the defined hourly window. Depending on the updates, the process may exceed this timeframe and require an automatic restart.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#maintenance_window ServerUpdateSchedule#maintenance_window}
    */
    readonly maintenanceWindow: number;
    /**
    * The schedule name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#name ServerUpdateSchedule#name}
    */
    readonly name: string;
    /**
    * STACKIT Project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#project_id ServerUpdateSchedule#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#region ServerUpdateSchedule#region}
    */
    readonly region?: string;
    /**
    * An `rrule` (Recurrence Rule) is a standardized string format used in iCalendar (RFC 5545) to define repeating events, and you can generate one by using a dedicated library or by using online generator tools to specify parameters like frequency, interval, and end dates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#rrule ServerUpdateSchedule#rrule}
    */
    readonly rrule: string;
    /**
    * Server ID for the update schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#server_id ServerUpdateSchedule#server_id}
    */
    readonly serverId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule stackit_server_update_schedule}
*/
export declare class ServerUpdateSchedule extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_update_schedule";
    /**
    * Generates CDKTF code for importing a ServerUpdateSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerUpdateSchedule to import
    * @param importFromId The id of the existing ServerUpdateSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerUpdateSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/server_update_schedule stackit_server_update_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerUpdateScheduleConfig
    */
    constructor(scope: Construct, id: string, config: ServerUpdateScheduleConfig);
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _maintenanceWindow?;
    get maintenanceWindow(): number;
    set maintenanceWindow(value: number);
    get maintenanceWindowInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    get rruleInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    get updateScheduleId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
