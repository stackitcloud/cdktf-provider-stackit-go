# `stackit_vpc_region`

Refer to the Terraform Registry for docs: [`stackit_vpc_region`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/vpc_region).
