import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ScfOrganizationConfig extends cdktf.TerraformMetaArguments {
    /**
    * The name of the organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#name ScfOrganization#name}
    */
    readonly name: string;
    /**
    * The ID of the platform associated with the organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#platform_id ScfOrganization#platform_id}
    */
    readonly platformId?: string;
    /**
    * The ID of the project associated with the organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#project_id ScfOrganization#project_id}
    */
    readonly projectId: string;
    /**
    * The ID of the quota associated with the organization
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#quota_id ScfOrganization#quota_id}
    */
    readonly quotaId?: string;
    /**
    * The resource region. If not defined, the provider region is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#region ScfOrganization#region}
    */
    readonly region?: string;
    /**
    * A boolean indicating whether the organization is suspended
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#suspended ScfOrganization#suspended}
    */
    readonly suspended?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization stackit_scf_organization}
*/
export declare class ScfOrganization extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_scf_organization";
    /**
    * Generates CDKTF code for importing a ScfOrganization resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ScfOrganization to import
    * @param importFromId The id of the existing ScfOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ScfOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/scf_organization stackit_scf_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ScfOrganizationConfig
    */
    constructor(scope: Construct, id: string, config: ScfOrganizationConfig);
    get createdAt(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get orgId(): string;
    private _platformId?;
    get platformId(): string;
    set platformId(value: string);
    resetPlatformId(): void;
    get platformIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _quotaId?;
    get quotaId(): string;
    set quotaId(value: string);
    resetQuotaId(): void;
    get quotaIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _suspended?;
    get suspended(): boolean | cdktf.IResolvable;
    set suspended(value: boolean | cdktf.IResolvable);
    resetSuspended(): void;
    get suspendedInput(): boolean | cdktf.IResolvable | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
