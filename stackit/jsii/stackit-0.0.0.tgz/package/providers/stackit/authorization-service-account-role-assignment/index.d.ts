import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AuthorizationServiceAccountRoleAssignmentConfig extends cdktf.TerraformMetaArguments {
    /**
    * Service-account Resource to assign the role to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment#resource_id AuthorizationServiceAccountRoleAssignment#resource_id}
    */
    readonly resourceId: string;
    /**
    * Role to be assigned. Available roles can be queried using stackit-cli: `stackit curl https://authorization.api.stackit.cloud/v2/permissions`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment#role AuthorizationServiceAccountRoleAssignment#role}
    */
    readonly role: string;
    /**
    * Identifier of user, service account or client. Usually email address or name in case of clients. All letters must be lowercased.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment#subject AuthorizationServiceAccountRoleAssignment#subject}
    */
    readonly subject: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment stackit_authorization_service_account_role_assignment}
*/
export declare class AuthorizationServiceAccountRoleAssignment extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_authorization_service_account_role_assignment";
    /**
    * Generates CDKTF code for importing a AuthorizationServiceAccountRoleAssignment resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthorizationServiceAccountRoleAssignment to import
    * @param importFromId The id of the existing AuthorizationServiceAccountRoleAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthorizationServiceAccountRoleAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/authorization_service_account_role_assignment stackit_authorization_service_account_role_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthorizationServiceAccountRoleAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AuthorizationServiceAccountRoleAssignmentConfig);
    get id(): string;
    private _resourceId?;
    get resourceId(): string;
    set resourceId(value: string);
    get resourceIdInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
