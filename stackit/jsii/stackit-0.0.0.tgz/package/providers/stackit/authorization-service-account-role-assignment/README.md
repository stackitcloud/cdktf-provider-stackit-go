# `stackit_authorization_service_account_role_assignment`

Refer to the Terraform Registry for docs: [`stackit_authorization_service_account_role_assignment`](https://registry.terraform.io/providers/stackitcloud/stackit/0.104.0/docs/resources/authorization_service_account_role_assignment).
