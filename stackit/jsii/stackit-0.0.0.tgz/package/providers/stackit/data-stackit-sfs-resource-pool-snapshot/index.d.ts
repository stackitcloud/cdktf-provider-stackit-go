import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsResourcePoolSnapshotConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the resource pool snapshot is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot#project_id DataStackitSfsResourcePoolSnapshot#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. Read-only attribute that reflects the provider region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot#region DataStackitSfsResourcePoolSnapshot#region}
    */
    readonly region?: string;
    /**
    * Resource pool ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot#resource_pool_id DataStackitSfsResourcePoolSnapshot#resource_pool_id}
    */
    readonly resourcePoolId: string;
}
export interface DataStackitSfsResourcePoolSnapshotSnapshots {
}
export declare function dataStackitSfsResourcePoolSnapshotSnapshotsToTerraform(struct?: DataStackitSfsResourcePoolSnapshotSnapshots): any;
export declare function dataStackitSfsResourcePoolSnapshotSnapshotsToHclTerraform(struct?: DataStackitSfsResourcePoolSnapshotSnapshots): any;
export declare class DataStackitSfsResourcePoolSnapshotSnapshotsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSfsResourcePoolSnapshotSnapshots | undefined;
    set internalValue(value: DataStackitSfsResourcePoolSnapshotSnapshots | undefined);
    get comment(): string;
    get createdAt(): string;
    get logicalSizeGigabytes(): number;
    get resourcePoolId(): string;
    get sizeGigabytes(): number;
    get snapshotName(): string;
}
export declare class DataStackitSfsResourcePoolSnapshotSnapshotsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSfsResourcePoolSnapshotSnapshotsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot stackit_sfs_resource_pool_snapshot}
*/
export declare class DataStackitSfsResourcePoolSnapshot extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_resource_pool_snapshot";
    /**
    * Generates CDKTF code for importing a DataStackitSfsResourcePoolSnapshot resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsResourcePoolSnapshot to import
    * @param importFromId The id of the existing DataStackitSfsResourcePoolSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsResourcePoolSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/sfs_resource_pool_snapshot stackit_sfs_resource_pool_snapshot} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsResourcePoolSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsResourcePoolSnapshotConfig);
    get id(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcePoolId?;
    get resourcePoolId(): string;
    set resourcePoolId(value: string);
    get resourcePoolIdInput(): string | undefined;
    private _snapshots;
    get snapshots(): DataStackitSfsResourcePoolSnapshotSnapshotsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
