# `data_stackit_sfs_resource_pool_snapshot`

Refer to the Terraform Registry for docs: [`data_stackit_sfs_resource_pool_snapshot`](https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/data-sources/sfs_resource_pool_snapshot).
