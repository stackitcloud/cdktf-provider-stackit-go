# `stackit_image`

Refer to the Terraform Registry for docs: [`stackit_image`](https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/image).
