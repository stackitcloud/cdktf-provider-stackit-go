# `stackit_image`

Refer to the Terraform Registry for docs: [`stackit_image`](https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/resources/image).
