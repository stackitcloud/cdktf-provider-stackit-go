import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ImageConfig extends cdktf.TerraformMetaArguments {
    /**
    * Properties to set hardware and scheduling settings for an image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#config Image#config}
    */
    readonly config?: ImageConfigA;
    /**
    * The disk format of the image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#disk_format Image#disk_format}
    */
    readonly diskFormat: string;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#labels Image#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The filepath of the raw image file to be uploaded.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#local_file_path Image#local_file_path}
    */
    readonly localFilePath: string;
    /**
    * The minimum disk size of the image in GB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#min_disk_size Image#min_disk_size}
    */
    readonly minDiskSize?: number;
    /**
    * The minimum RAM of the image in MB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#min_ram Image#min_ram}
    */
    readonly minRam?: number;
    /**
    * The name of the image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#name Image#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the image is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#project_id Image#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#region Image#region}
    */
    readonly region?: string;
}
export interface ImageChecksum {
}
export declare function imageChecksumToTerraform(struct?: ImageChecksum): any;
export declare function imageChecksumToHclTerraform(struct?: ImageChecksum): any;
export declare class ImageChecksumOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ImageChecksum | undefined;
    set internalValue(value: ImageChecksum | undefined);
    get algorithm(): string;
    get digest(): string;
}
export interface ImageConfigA {
    /**
    * Enables the BIOS bootmenu.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#boot_menu Image#boot_menu}
    */
    readonly bootMenu?: boolean | cdktf.IResolvable;
    /**
    * Sets CDROM bus controller type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#cdrom_bus Image#cdrom_bus}
    */
    readonly cdromBus?: string;
    /**
    * Sets Disk bus controller type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#disk_bus Image#disk_bus}
    */
    readonly diskBus?: string;
    /**
    * Sets virtual network interface model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#nic_model Image#nic_model}
    */
    readonly nicModel?: string;
    /**
    * Enables operating system specific optimizations.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#operating_system Image#operating_system}
    */
    readonly operatingSystem?: string;
    /**
    * Operating system distribution.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#operating_system_distro Image#operating_system_distro}
    */
    readonly operatingSystemDistro?: string;
    /**
    * Version of the operating system.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#operating_system_version Image#operating_system_version}
    */
    readonly operatingSystemVersion?: string;
    /**
    * Sets the device bus when the image is used as a rescue image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#rescue_bus Image#rescue_bus}
    */
    readonly rescueBus?: string;
    /**
    * Sets the device when the image is used as a rescue image.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#rescue_device Image#rescue_device}
    */
    readonly rescueDevice?: string;
    /**
    * Enables Secure Boot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#secure_boot Image#secure_boot}
    */
    readonly secureBoot?: boolean | cdktf.IResolvable;
    /**
    * Enables UEFI boot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#uefi Image#uefi}
    */
    readonly uefi?: boolean | cdktf.IResolvable;
    /**
    * Sets Graphic device model.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#video_model Image#video_model}
    */
    readonly videoModel?: string;
    /**
    * Enables the use of VirtIO SCSI to provide block device access. By default instances use VirtIO Block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#virtio_scsi Image#virtio_scsi}
    */
    readonly virtioScsi?: boolean | cdktf.IResolvable;
}
export declare function imageConfigAToTerraform(struct?: ImageConfigA | cdktf.IResolvable): any;
export declare function imageConfigAToHclTerraform(struct?: ImageConfigA | cdktf.IResolvable): any;
export declare class ImageConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ImageConfigA | cdktf.IResolvable | undefined;
    set internalValue(value: ImageConfigA | cdktf.IResolvable | undefined);
    private _bootMenu?;
    get bootMenu(): boolean | cdktf.IResolvable;
    set bootMenu(value: boolean | cdktf.IResolvable);
    resetBootMenu(): void;
    get bootMenuInput(): boolean | cdktf.IResolvable | undefined;
    private _cdromBus?;
    get cdromBus(): string;
    set cdromBus(value: string);
    resetCdromBus(): void;
    get cdromBusInput(): string | undefined;
    private _diskBus?;
    get diskBus(): string;
    set diskBus(value: string);
    resetDiskBus(): void;
    get diskBusInput(): string | undefined;
    private _nicModel?;
    get nicModel(): string;
    set nicModel(value: string);
    resetNicModel(): void;
    get nicModelInput(): string | undefined;
    private _operatingSystem?;
    get operatingSystem(): string;
    set operatingSystem(value: string);
    resetOperatingSystem(): void;
    get operatingSystemInput(): string | undefined;
    private _operatingSystemDistro?;
    get operatingSystemDistro(): string;
    set operatingSystemDistro(value: string);
    resetOperatingSystemDistro(): void;
    get operatingSystemDistroInput(): string | undefined;
    private _operatingSystemVersion?;
    get operatingSystemVersion(): string;
    set operatingSystemVersion(value: string);
    resetOperatingSystemVersion(): void;
    get operatingSystemVersionInput(): string | undefined;
    private _rescueBus?;
    get rescueBus(): string;
    set rescueBus(value: string);
    resetRescueBus(): void;
    get rescueBusInput(): string | undefined;
    private _rescueDevice?;
    get rescueDevice(): string;
    set rescueDevice(value: string);
    resetRescueDevice(): void;
    get rescueDeviceInput(): string | undefined;
    private _secureBoot?;
    get secureBoot(): boolean | cdktf.IResolvable;
    set secureBoot(value: boolean | cdktf.IResolvable);
    resetSecureBoot(): void;
    get secureBootInput(): boolean | cdktf.IResolvable | undefined;
    private _uefi?;
    get uefi(): boolean | cdktf.IResolvable;
    set uefi(value: boolean | cdktf.IResolvable);
    resetUefi(): void;
    get uefiInput(): boolean | cdktf.IResolvable | undefined;
    private _videoModel?;
    get videoModel(): string;
    set videoModel(value: string);
    resetVideoModel(): void;
    get videoModelInput(): string | undefined;
    private _virtioScsi?;
    get virtioScsi(): boolean | cdktf.IResolvable;
    set virtioScsi(value: boolean | cdktf.IResolvable);
    resetVirtioScsi(): void;
    get virtioScsiInput(): boolean | cdktf.IResolvable | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image stackit_image}
*/
export declare class Image extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_image";
    /**
    * Generates CDKTF code for importing a Image resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Image to import
    * @param importFromId The id of the existing Image that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Image to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/image stackit_image} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ImageConfig
    */
    constructor(scope: Construct, id: string, config: ImageConfig);
    private _checksum;
    get checksum(): ImageChecksumOutputReference;
    private _config;
    get config(): ImageConfigAOutputReference;
    putConfig(value: ImageConfigA): void;
    resetConfig(): void;
    get configInput(): cdktf.IResolvable | ImageConfigA | undefined;
    private _diskFormat?;
    get diskFormat(): string;
    set diskFormat(value: string);
    get diskFormatInput(): string | undefined;
    get id(): string;
    get imageId(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _localFilePath?;
    get localFilePath(): string;
    set localFilePath(value: string);
    get localFilePathInput(): string | undefined;
    private _minDiskSize?;
    get minDiskSize(): number;
    set minDiskSize(value: number);
    resetMinDiskSize(): void;
    get minDiskSizeInput(): number | undefined;
    private _minRam?;
    get minRam(): number;
    set minRam(value: number);
    resetMinRam(): void;
    get minRamInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get protected(): cdktf.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scope(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
