# `stackit_redis_instance`

Refer to the Terraform Registry for docs: [`stackit_redis_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/redis_instance).
