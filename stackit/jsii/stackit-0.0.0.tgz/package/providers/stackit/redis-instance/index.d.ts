import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RedisInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#name RedisInstance#name}
    */
    readonly name: string;
    /**
    * Configuration parameters. Please note that removing a previously configured field from your Terraform configuration won't replace its value in the API. To update a previously configured field, explicitly set a new value for it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#parameters RedisInstance#parameters}
    */
    readonly parameters?: RedisInstanceParameters;
    /**
    * The selected plan name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#plan_name RedisInstance#plan_name}
    */
    readonly planName: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#project_id RedisInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The service version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#version RedisInstance#version}
    */
    readonly version: string;
}
export interface RedisInstanceParameters {
    /**
    * The number of milliseconds after which the instance is considered down.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#down_after_milliseconds RedisInstance#down_after_milliseconds}
    */
    readonly downAfterMilliseconds?: number;
    /**
    * Enable monitoring.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#enable_monitoring RedisInstance#enable_monitoring}
    */
    readonly enableMonitoring?: boolean | cdktf.IResolvable;
    /**
    * The failover timeout in milliseconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#failover_timeout RedisInstance#failover_timeout}
    */
    readonly failoverTimeout?: number;
    /**
    * Graphite server URL (host and port). If set, monitoring with Graphite will be enabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#graphite RedisInstance#graphite}
    */
    readonly graphite?: string;
    /**
    * The lazy eviction enablement (yes or no).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#lazyfree_lazy_eviction RedisInstance#lazyfree_lazy_eviction}
    */
    readonly lazyfreeLazyEviction?: string;
    /**
    * The lazy expire enablement (yes or no).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#lazyfree_lazy_expire RedisInstance#lazyfree_lazy_expire}
    */
    readonly lazyfreeLazyExpire?: string;
    /**
    * The Lua time limit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#lua_time_limit RedisInstance#lua_time_limit}
    */
    readonly luaTimeLimit?: number;
    /**
    * The maximum disk threshold in MB. If the disk usage exceeds this threshold, the instance will be stopped.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#max_disk_threshold RedisInstance#max_disk_threshold}
    */
    readonly maxDiskThreshold?: number;
    /**
    * The maximum number of clients.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#maxclients RedisInstance#maxclients}
    */
    readonly maxclients?: number;
    /**
    * The policy to handle the maximum memory (volatile-lru, noeviction, etc).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#maxmemory_policy RedisInstance#maxmemory_policy}
    */
    readonly maxmemoryPolicy?: string;
    /**
    * The maximum memory samples.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#maxmemory_samples RedisInstance#maxmemory_samples}
    */
    readonly maxmemorySamples?: number;
    /**
    * The frequency in seconds at which metrics are emitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#metrics_frequency RedisInstance#metrics_frequency}
    */
    readonly metricsFrequency?: number;
    /**
    * The prefix for the metrics. Could be useful when using Graphite monitoring to prefix the metrics with a certain value, like an API key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#metrics_prefix RedisInstance#metrics_prefix}
    */
    readonly metricsPrefix?: string;
    /**
    * The minimum replicas maximum lag.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#min_replicas_max_lag RedisInstance#min_replicas_max_lag}
    */
    readonly minReplicasMaxLag?: number;
    /**
    * The ID of the STACKIT monitoring instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#monitoring_instance_id RedisInstance#monitoring_instance_id}
    */
    readonly monitoringInstanceId?: string;
    /**
    * The notify keyspace events.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#notify_keyspace_events RedisInstance#notify_keyspace_events}
    */
    readonly notifyKeyspaceEvents?: string;
    /**
    * Comma separated list of IP networks in CIDR notation which are allowed to access this instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#sgw_acl RedisInstance#sgw_acl}
    */
    readonly sgwAcl?: string;
    /**
    * The snapshot configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#snapshot RedisInstance#snapshot}
    */
    readonly snapshot?: string;
    /**
    * List of syslog servers to send logs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#syslog RedisInstance#syslog}
    */
    readonly syslog?: string[];
    /**
    * List of TLS ciphers to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#tls_ciphers RedisInstance#tls_ciphers}
    */
    readonly tlsCiphers?: string[];
    /**
    * TLS cipher suites to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#tls_ciphersuites RedisInstance#tls_ciphersuites}
    */
    readonly tlsCiphersuites?: string;
    /**
    * TLS protocol to use.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#tls_protocols RedisInstance#tls_protocols}
    */
    readonly tlsProtocols?: string;
}
export declare function redisInstanceParametersToTerraform(struct?: RedisInstanceParameters | cdktf.IResolvable): any;
export declare function redisInstanceParametersToHclTerraform(struct?: RedisInstanceParameters | cdktf.IResolvable): any;
export declare class RedisInstanceParametersOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RedisInstanceParameters | cdktf.IResolvable | undefined;
    set internalValue(value: RedisInstanceParameters | cdktf.IResolvable | undefined);
    private _downAfterMilliseconds?;
    get downAfterMilliseconds(): number;
    set downAfterMilliseconds(value: number);
    resetDownAfterMilliseconds(): void;
    get downAfterMillisecondsInput(): number | undefined;
    private _enableMonitoring?;
    get enableMonitoring(): boolean | cdktf.IResolvable;
    set enableMonitoring(value: boolean | cdktf.IResolvable);
    resetEnableMonitoring(): void;
    get enableMonitoringInput(): boolean | cdktf.IResolvable | undefined;
    private _failoverTimeout?;
    get failoverTimeout(): number;
    set failoverTimeout(value: number);
    resetFailoverTimeout(): void;
    get failoverTimeoutInput(): number | undefined;
    private _graphite?;
    get graphite(): string;
    set graphite(value: string);
    resetGraphite(): void;
    get graphiteInput(): string | undefined;
    private _lazyfreeLazyEviction?;
    get lazyfreeLazyEviction(): string;
    set lazyfreeLazyEviction(value: string);
    resetLazyfreeLazyEviction(): void;
    get lazyfreeLazyEvictionInput(): string | undefined;
    private _lazyfreeLazyExpire?;
    get lazyfreeLazyExpire(): string;
    set lazyfreeLazyExpire(value: string);
    resetLazyfreeLazyExpire(): void;
    get lazyfreeLazyExpireInput(): string | undefined;
    private _luaTimeLimit?;
    get luaTimeLimit(): number;
    set luaTimeLimit(value: number);
    resetLuaTimeLimit(): void;
    get luaTimeLimitInput(): number | undefined;
    private _maxDiskThreshold?;
    get maxDiskThreshold(): number;
    set maxDiskThreshold(value: number);
    resetMaxDiskThreshold(): void;
    get maxDiskThresholdInput(): number | undefined;
    private _maxclients?;
    get maxclients(): number;
    set maxclients(value: number);
    resetMaxclients(): void;
    get maxclientsInput(): number | undefined;
    private _maxmemoryPolicy?;
    get maxmemoryPolicy(): string;
    set maxmemoryPolicy(value: string);
    resetMaxmemoryPolicy(): void;
    get maxmemoryPolicyInput(): string | undefined;
    private _maxmemorySamples?;
    get maxmemorySamples(): number;
    set maxmemorySamples(value: number);
    resetMaxmemorySamples(): void;
    get maxmemorySamplesInput(): number | undefined;
    private _metricsFrequency?;
    get metricsFrequency(): number;
    set metricsFrequency(value: number);
    resetMetricsFrequency(): void;
    get metricsFrequencyInput(): number | undefined;
    private _metricsPrefix?;
    get metricsPrefix(): string;
    set metricsPrefix(value: string);
    resetMetricsPrefix(): void;
    get metricsPrefixInput(): string | undefined;
    private _minReplicasMaxLag?;
    get minReplicasMaxLag(): number;
    set minReplicasMaxLag(value: number);
    resetMinReplicasMaxLag(): void;
    get minReplicasMaxLagInput(): number | undefined;
    private _monitoringInstanceId?;
    get monitoringInstanceId(): string;
    set monitoringInstanceId(value: string);
    resetMonitoringInstanceId(): void;
    get monitoringInstanceIdInput(): string | undefined;
    private _notifyKeyspaceEvents?;
    get notifyKeyspaceEvents(): string;
    set notifyKeyspaceEvents(value: string);
    resetNotifyKeyspaceEvents(): void;
    get notifyKeyspaceEventsInput(): string | undefined;
    private _sgwAcl?;
    get sgwAcl(): string;
    set sgwAcl(value: string);
    resetSgwAcl(): void;
    get sgwAclInput(): string | undefined;
    private _snapshot?;
    get snapshot(): string;
    set snapshot(value: string);
    resetSnapshot(): void;
    get snapshotInput(): string | undefined;
    private _syslog?;
    get syslog(): string[];
    set syslog(value: string[]);
    resetSyslog(): void;
    get syslogInput(): string[] | undefined;
    private _tlsCiphers?;
    get tlsCiphers(): string[];
    set tlsCiphers(value: string[]);
    resetTlsCiphers(): void;
    get tlsCiphersInput(): string[] | undefined;
    private _tlsCiphersuites?;
    get tlsCiphersuites(): string;
    set tlsCiphersuites(value: string);
    resetTlsCiphersuites(): void;
    get tlsCiphersuitesInput(): string | undefined;
    private _tlsProtocols?;
    get tlsProtocols(): string;
    set tlsProtocols(value: string);
    resetTlsProtocols(): void;
    get tlsProtocolsInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance stackit_redis_instance}
*/
export declare class RedisInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_redis_instance";
    /**
    * Generates CDKTF code for importing a RedisInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RedisInstance to import
    * @param importFromId The id of the existing RedisInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RedisInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/redis_instance stackit_redis_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RedisInstanceConfig
    */
    constructor(scope: Construct, id: string, config: RedisInstanceConfig);
    get cfGuid(): string;
    get cfOrganizationGuid(): string;
    get cfSpaceGuid(): string;
    get dashboardUrl(): string;
    get id(): string;
    get imageUrl(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): RedisInstanceParametersOutputReference;
    putParameters(value: RedisInstanceParameters): void;
    resetParameters(): void;
    get parametersInput(): cdktf.IResolvable | RedisInstanceParameters | undefined;
    get planId(): string;
    private _planName?;
    get planName(): string;
    set planName(value: string);
    get planNameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
