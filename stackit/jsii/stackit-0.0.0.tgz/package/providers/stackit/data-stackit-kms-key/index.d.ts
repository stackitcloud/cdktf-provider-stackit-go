import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitKmsKeyConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the key
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key#key_id DataStackitKmsKey#key_id}
    */
    readonly keyId: string;
    /**
    * The ID of the associated key ring
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key#keyring_id DataStackitKmsKey#keyring_id}
    */
    readonly keyringId: string;
    /**
    * STACKIT project ID to which the key is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key#project_id DataStackitKmsKey#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key#region DataStackitKmsKey#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key stackit_kms_key}
*/
export declare class DataStackitKmsKey extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_kms_key";
    /**
    * Generates CDKTF code for importing a DataStackitKmsKey resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitKmsKey to import
    * @param importFromId The id of the existing DataStackitKmsKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitKmsKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/kms_key stackit_kms_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitKmsKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitKmsKeyConfig);
    get accessScope(): string;
    get algorithm(): string;
    get description(): string;
    get displayName(): string;
    get id(): string;
    get importOnly(): cdktf.IResolvable;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _keyringId?;
    get keyringId(): string;
    set keyringId(value: string);
    get keyringIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get protection(): string;
    get purpose(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
