import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitOpensearchCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credential's ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential#credential_id DataStackitOpensearchCredential#credential_id}
    */
    readonly credentialId: string;
    /**
    * ID of the OpenSearch instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential#instance_id DataStackitOpensearchCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential#project_id DataStackitOpensearchCredential#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential stackit_opensearch_credential}
*/
export declare class DataStackitOpensearchCredential extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_opensearch_credential";
    /**
    * Generates CDKTF code for importing a DataStackitOpensearchCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitOpensearchCredential to import
    * @param importFromId The id of the existing DataStackitOpensearchCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitOpensearchCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/opensearch_credential stackit_opensearch_credential} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitOpensearchCredentialConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitOpensearchCredentialConfig);
    private _credentialId?;
    get credentialId(): string;
    set credentialId(value: string);
    get credentialIdInput(): string | undefined;
    get host(): string;
    get hosts(): string[];
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get scheme(): string;
    get uri(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
