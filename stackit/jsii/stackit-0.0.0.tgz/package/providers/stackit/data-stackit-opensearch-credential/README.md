# `data_stackit_opensearch_credential`

Refer to the Terraform Registry for docs: [`data_stackit_opensearch_credential`](https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/opensearch_credential).
