import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitImageV2Config extends cdktf.TerraformMetaArguments {
    /**
    * Additional filtering options based on image properties. Can be used independently or in conjunction with `name` or `name_regex`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#filter DataStackitImageV2#filter}
    */
    readonly filter?: DataStackitImageV2Filter;
    /**
    * Image ID to fetch directly
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#image_id DataStackitImageV2#image_id}
    */
    readonly imageId?: string;
    /**
    * Exact image name to match. Optionally applies a `filter` block to further refine results in case multiple images share the same name. The first match is returned, optionally sorted by name in ascending order. Cannot be used together with `name_regex`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#name DataStackitImageV2#name}
    */
    readonly name?: string;
    /**
    * Regular expression to match against image names. Optionally applies a `filter` block to narrow down results when multiple image names match the regex. The first match is returned, optionally sorted by name in ascending order. Cannot be used together with `name`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#name_regex DataStackitImageV2#name_regex}
    */
    readonly nameRegex?: string;
    /**
    * STACKIT project ID to which the image is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#project_id DataStackitImageV2#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#region DataStackitImageV2#region}
    */
    readonly region?: string;
    /**
    * If set to `true`, images are sorted in ascending lexicographical order by image name (such as `Ubuntu 18.04`, `Ubuntu 20.04`, `Ubuntu 22.04`) before selecting the first match. Defaults to `false` (descending such as `Ubuntu 22.04`, `Ubuntu 20.04`, `Ubuntu 18.04`).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#sort_ascending DataStackitImageV2#sort_ascending}
    */
    readonly sortAscending?: boolean | cdktf.IResolvable;
}
export interface DataStackitImageV2Checksum {
}
export declare function dataStackitImageV2ChecksumToTerraform(struct?: DataStackitImageV2Checksum): any;
export declare function dataStackitImageV2ChecksumToHclTerraform(struct?: DataStackitImageV2Checksum): any;
export declare class DataStackitImageV2ChecksumOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitImageV2Checksum | undefined;
    set internalValue(value: DataStackitImageV2Checksum | undefined);
    get algorithm(): string;
    get digest(): string;
}
export interface DataStackitImageV2ConfigA {
}
export declare function dataStackitImageV2ConfigAToTerraform(struct?: DataStackitImageV2ConfigA): any;
export declare function dataStackitImageV2ConfigAToHclTerraform(struct?: DataStackitImageV2ConfigA): any;
export declare class DataStackitImageV2ConfigAOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitImageV2ConfigA | undefined;
    set internalValue(value: DataStackitImageV2ConfigA | undefined);
    get bootMenu(): cdktf.IResolvable;
    get cdromBus(): string;
    get diskBus(): string;
    get nicModel(): string;
    get operatingSystem(): string;
    get operatingSystemDistro(): string;
    get operatingSystemVersion(): string;
    get rescueBus(): string;
    get rescueDevice(): string;
    get secureBoot(): cdktf.IResolvable;
    get uefi(): cdktf.IResolvable;
    get videoModel(): string;
    get virtioScsi(): cdktf.IResolvable;
}
export interface DataStackitImageV2Filter {
    /**
    * Filter images by operating system distribution. For example: `ubuntu`, `ubuntu-arm64`, `debian`, `rhel`, etc.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#distro DataStackitImageV2#distro}
    */
    readonly distro?: string;
    /**
    * Filter images by operating system type, such as `linux` or `windows`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#os DataStackitImageV2#os}
    */
    readonly os?: string;
    /**
    * Filter images with Secure Boot support. Set to `true` to match images that support Secure Boot.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#secure_boot DataStackitImageV2#secure_boot}
    */
    readonly secureBoot?: boolean | cdktf.IResolvable;
    /**
    * Filter images based on UEFI support. Set to `true` to match images that support UEFI.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#uefi DataStackitImageV2#uefi}
    */
    readonly uefi?: boolean | cdktf.IResolvable;
    /**
    * Filter images by OS distribution version, such as `22.04`, `11`, or `9.1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#version DataStackitImageV2#version}
    */
    readonly version?: string;
}
export declare function dataStackitImageV2FilterToTerraform(struct?: DataStackitImageV2Filter | cdktf.IResolvable): any;
export declare function dataStackitImageV2FilterToHclTerraform(struct?: DataStackitImageV2Filter | cdktf.IResolvable): any;
export declare class DataStackitImageV2FilterOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitImageV2Filter | cdktf.IResolvable | undefined;
    set internalValue(value: DataStackitImageV2Filter | cdktf.IResolvable | undefined);
    private _distro?;
    get distro(): string;
    set distro(value: string);
    resetDistro(): void;
    get distroInput(): string | undefined;
    private _os?;
    get os(): string;
    set os(value: string);
    resetOs(): void;
    get osInput(): string | undefined;
    private _secureBoot?;
    get secureBoot(): boolean | cdktf.IResolvable;
    set secureBoot(value: boolean | cdktf.IResolvable);
    resetSecureBoot(): void;
    get secureBootInput(): boolean | cdktf.IResolvable | undefined;
    private _uefi?;
    get uefi(): boolean | cdktf.IResolvable;
    set uefi(value: boolean | cdktf.IResolvable);
    resetUefi(): void;
    get uefiInput(): boolean | cdktf.IResolvable | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2 stackit_image_v2}
*/
export declare class DataStackitImageV2 extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_image_v2";
    /**
    * Generates CDKTF code for importing a DataStackitImageV2 resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitImageV2 to import
    * @param importFromId The id of the existing DataStackitImageV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitImageV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/image_v2 stackit_image_v2} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitImageV2Config
    */
    constructor(scope: Construct, id: string, config: DataStackitImageV2Config);
    private _checksum;
    get checksum(): DataStackitImageV2ChecksumOutputReference;
    private _config;
    get config(): DataStackitImageV2ConfigAOutputReference;
    get diskFormat(): string;
    private _filter;
    get filter(): DataStackitImageV2FilterOutputReference;
    putFilter(value: DataStackitImageV2Filter): void;
    resetFilter(): void;
    get filterInput(): cdktf.IResolvable | DataStackitImageV2Filter | undefined;
    get id(): string;
    private _imageId?;
    get imageId(): string;
    set imageId(value: string);
    resetImageId(): void;
    get imageIdInput(): string | undefined;
    private _labels;
    get labels(): cdktf.StringMap;
    get minDiskSize(): number;
    get minRam(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _nameRegex?;
    get nameRegex(): string;
    set nameRegex(value: string);
    resetNameRegex(): void;
    get nameRegexInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get protected(): cdktf.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scope(): string;
    private _sortAscending?;
    get sortAscending(): boolean | cdktf.IResolvable;
    set sortAscending(value: boolean | cdktf.IResolvable);
    resetSortAscending(): void;
    get sortAscendingInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
