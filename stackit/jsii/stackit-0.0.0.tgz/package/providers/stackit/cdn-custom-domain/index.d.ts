import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface CdnCustomDomainConfig extends cdktf.TerraformMetaArguments {
    /**
    * The TLS certificate for the custom domain. If omitted, a managed certificate will be used. If the block is specified, a custom certificate is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#certificate CdnCustomDomain#certificate}
    */
    readonly certificate?: CdnCustomDomainCertificate;
    /**
    * CDN distribution ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#distribution_id CdnCustomDomain#distribution_id}
    */
    readonly distributionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#name CdnCustomDomain#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the distribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#project_id CdnCustomDomain#project_id}
    */
    readonly projectId: string;
}
export interface CdnCustomDomainCertificate {
    /**
    * The PEM-encoded TLS certificate. Required for custom certificates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#certificate CdnCustomDomain#certificate}
    */
    readonly certificate?: string;
    /**
    * The PEM-encoded private key for the certificate. Required for custom certificates. The certificate will be updated if this field is changed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#private_key CdnCustomDomain#private_key}
    */
    readonly privateKey?: string;
}
export declare function cdnCustomDomainCertificateToTerraform(struct?: CdnCustomDomainCertificate | cdktf.IResolvable): any;
export declare function cdnCustomDomainCertificateToHclTerraform(struct?: CdnCustomDomainCertificate | cdktf.IResolvable): any;
export declare class CdnCustomDomainCertificateOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnCustomDomainCertificate | cdktf.IResolvable | undefined;
    set internalValue(value: CdnCustomDomainCertificate | cdktf.IResolvable | undefined);
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    get version(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain stackit_cdn_custom_domain}
*/
export declare class CdnCustomDomain extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_cdn_custom_domain";
    /**
    * Generates CDKTF code for importing a CdnCustomDomain resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnCustomDomain to import
    * @param importFromId The id of the existing CdnCustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnCustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/resources/cdn_custom_domain stackit_cdn_custom_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnCustomDomainConfig
    */
    constructor(scope: Construct, id: string, config: CdnCustomDomainConfig);
    private _certificate;
    get certificate(): CdnCustomDomainCertificateOutputReference;
    putCertificate(value: CdnCustomDomainCertificate): void;
    resetCertificate(): void;
    get certificateInput(): cdktf.IResolvable | CdnCustomDomainCertificate | undefined;
    private _distributionId?;
    get distributionId(): string;
    set distributionId(value: string);
    get distributionIdInput(): string | undefined;
    get errors(): string[];
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
