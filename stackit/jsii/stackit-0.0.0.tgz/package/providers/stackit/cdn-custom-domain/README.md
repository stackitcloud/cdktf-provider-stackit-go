# `stackit_cdn_custom_domain`

Refer to the Terraform Registry for docs: [`stackit_cdn_custom_domain`](https://registry.terraform.io/providers/stackitcloud/stackit/0.118.0/docs/resources/cdn_custom_domain).
