import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAlbWafManagedRuleSetConfig extends cdktf.TerraformMetaArguments {
    /**
    * Managed Rule Set configuration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set#name DataStackitAlbWafManagedRuleSet#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the ALB WAF Managed Rule Set.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set#project_id DataStackitAlbWafManagedRuleSet#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set#region DataStackitAlbWafManagedRuleSet#region}
    */
    readonly region?: string;
}
export interface DataStackitAlbWafManagedRuleSetGroupsRules {
}
export declare function dataStackitAlbWafManagedRuleSetGroupsRulesToTerraform(struct?: DataStackitAlbWafManagedRuleSetGroupsRules): any;
export declare function dataStackitAlbWafManagedRuleSetGroupsRulesToHclTerraform(struct?: DataStackitAlbWafManagedRuleSetGroupsRules): any;
export declare class DataStackitAlbWafManagedRuleSetGroupsRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataStackitAlbWafManagedRuleSetGroupsRules | undefined;
    set internalValue(value: DataStackitAlbWafManagedRuleSetGroupsRules | undefined);
    get description(): string;
    get mode(): string;
    get severity(): string;
}
export declare class DataStackitAlbWafManagedRuleSetGroupsRulesMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataStackitAlbWafManagedRuleSetGroupsRulesOutputReference;
}
export interface DataStackitAlbWafManagedRuleSetGroups {
}
export declare function dataStackitAlbWafManagedRuleSetGroupsToTerraform(struct?: DataStackitAlbWafManagedRuleSetGroups): any;
export declare function dataStackitAlbWafManagedRuleSetGroupsToHclTerraform(struct?: DataStackitAlbWafManagedRuleSetGroups): any;
export declare class DataStackitAlbWafManagedRuleSetGroupsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectKey the key of this item in the map
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectKey: string);
    get internalValue(): DataStackitAlbWafManagedRuleSetGroups | undefined;
    set internalValue(value: DataStackitAlbWafManagedRuleSetGroups | undefined);
    get description(): string;
    get groupName(): string;
    private _rules;
    get rules(): DataStackitAlbWafManagedRuleSetGroupsRulesMap;
}
export declare class DataStackitAlbWafManagedRuleSetGroupsMap extends cdktf.ComplexMap {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    /**
    * @param key the key of the item to return
    */
    get(key: string): DataStackitAlbWafManagedRuleSetGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set stackit_alb_waf_managed_rule_set}
*/
export declare class DataStackitAlbWafManagedRuleSet extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_alb_waf_managed_rule_set";
    /**
    * Generates CDKTF code for importing a DataStackitAlbWafManagedRuleSet resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAlbWafManagedRuleSet to import
    * @param importFromId The id of the existing DataStackitAlbWafManagedRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAlbWafManagedRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.111.0/docs/data-sources/alb_waf_managed_rule_set stackit_alb_waf_managed_rule_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAlbWafManagedRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAlbWafManagedRuleSetConfig);
    private _groups;
    get groups(): DataStackitAlbWafManagedRuleSetGroupsMap;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get type(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
