import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSfsExportPolicyConfig extends cdktf.TerraformMetaArguments {
    /**
    * Export policy ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy#policy_id DataStackitSfsExportPolicy#policy_id}
    */
    readonly policyId: string;
    /**
    * STACKIT project ID to which the export policy is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy#project_id DataStackitSfsExportPolicy#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy#region DataStackitSfsExportPolicy#region}
    */
    readonly region?: string;
}
export interface DataStackitSfsExportPolicyRules {
    /**
    * Description of the Rule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy#description DataStackitSfsExportPolicy#description}
    */
    readonly description?: string;
}
export declare function dataStackitSfsExportPolicyRulesToTerraform(struct?: DataStackitSfsExportPolicyRules): any;
export declare function dataStackitSfsExportPolicyRulesToHclTerraform(struct?: DataStackitSfsExportPolicyRules): any;
export declare class DataStackitSfsExportPolicyRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitSfsExportPolicyRules | undefined;
    set internalValue(value: DataStackitSfsExportPolicyRules | undefined);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get ipAcl(): string[];
    get order(): number;
    get readOnly(): cdktf.IResolvable;
    get setUuid(): cdktf.IResolvable;
    get superUser(): cdktf.IResolvable;
}
export declare class DataStackitSfsExportPolicyRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: DataStackitSfsExportPolicyRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitSfsExportPolicyRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy stackit_sfs_export_policy}
*/
export declare class DataStackitSfsExportPolicy extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_sfs_export_policy";
    /**
    * Generates CDKTF code for importing a DataStackitSfsExportPolicy resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSfsExportPolicy to import
    * @param importFromId The id of the existing DataStackitSfsExportPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSfsExportPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.98.0/docs/data-sources/sfs_export_policy stackit_sfs_export_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSfsExportPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSfsExportPolicyConfig);
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    private _policyId?;
    get policyId(): string;
    set policyId(value: string);
    get policyIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): DataStackitSfsExportPolicyRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
