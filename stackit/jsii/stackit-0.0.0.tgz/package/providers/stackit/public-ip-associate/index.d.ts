import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PublicIpAssociateConfig extends cdktf.TerraformMetaArguments {
    /**
    * The ID of the network interface (or virtual IP) to which the public IP should be attached to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate#network_interface_id PublicIpAssociate#network_interface_id}
    */
    readonly networkInterfaceId: string;
    /**
    * STACKIT project ID to which the public IP is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate#project_id PublicIpAssociate#project_id}
    */
    readonly projectId: string;
    /**
    * The public IP ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate#public_ip_id PublicIpAssociate#public_ip_id}
    */
    readonly publicIpId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate#region PublicIpAssociate#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate stackit_public_ip_associate}
*/
export declare class PublicIpAssociate extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_public_ip_associate";
    /**
    * Generates CDKTF code for importing a PublicIpAssociate resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PublicIpAssociate to import
    * @param importFromId The id of the existing PublicIpAssociate that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PublicIpAssociate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/public_ip_associate stackit_public_ip_associate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PublicIpAssociateConfig
    */
    constructor(scope: Construct, id: string, config: PublicIpAssociateConfig);
    get id(): string;
    get ip(): string;
    private _networkInterfaceId?;
    get networkInterfaceId(): string;
    set networkInterfaceId(value: string);
    get networkInterfaceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _publicIpId?;
    get publicIpId(): string;
    set publicIpId(value: string);
    get publicIpIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
