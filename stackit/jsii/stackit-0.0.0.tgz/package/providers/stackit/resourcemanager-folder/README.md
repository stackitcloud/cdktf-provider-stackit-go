# `stackit_resourcemanager_folder`

Refer to the Terraform Registry for docs: [`stackit_resourcemanager_folder`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/resources/resourcemanager_folder).
