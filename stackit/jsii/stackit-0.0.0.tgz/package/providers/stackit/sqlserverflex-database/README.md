# `stackit_sqlserverflex_database`

Refer to the Terraform Registry for docs: [`stackit_sqlserverflex_database`](https://registry.terraform.io/providers/stackitcloud/stackit/0.113.0/docs/resources/sqlserverflex_database).
