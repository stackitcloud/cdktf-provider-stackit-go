import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitPostgresflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the PostgresFlex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance#instance_id DataStackitPostgresflexInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance#project_id DataStackitPostgresflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance#region DataStackitPostgresflexInstance#region}
    */
    readonly region?: string;
}
export interface DataStackitPostgresflexInstanceConnectionInfoWrite {
}
export declare function dataStackitPostgresflexInstanceConnectionInfoWriteToTerraform(struct?: DataStackitPostgresflexInstanceConnectionInfoWrite): any;
export declare function dataStackitPostgresflexInstanceConnectionInfoWriteToHclTerraform(struct?: DataStackitPostgresflexInstanceConnectionInfoWrite): any;
export declare class DataStackitPostgresflexInstanceConnectionInfoWriteOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceConnectionInfoWrite | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceConnectionInfoWrite | undefined);
    get host(): string;
    get port(): number;
}
export interface DataStackitPostgresflexInstanceConnectionInfo {
}
export declare function dataStackitPostgresflexInstanceConnectionInfoToTerraform(struct?: DataStackitPostgresflexInstanceConnectionInfo): any;
export declare function dataStackitPostgresflexInstanceConnectionInfoToHclTerraform(struct?: DataStackitPostgresflexInstanceConnectionInfo): any;
export declare class DataStackitPostgresflexInstanceConnectionInfoOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceConnectionInfo | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceConnectionInfo | undefined);
    private _write;
    get write(): DataStackitPostgresflexInstanceConnectionInfoWriteOutputReference;
}
export interface DataStackitPostgresflexInstanceEncryption {
}
export declare function dataStackitPostgresflexInstanceEncryptionToTerraform(struct?: DataStackitPostgresflexInstanceEncryption): any;
export declare function dataStackitPostgresflexInstanceEncryptionToHclTerraform(struct?: DataStackitPostgresflexInstanceEncryption): any;
export declare class DataStackitPostgresflexInstanceEncryptionOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceEncryption | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceEncryption | undefined);
    get kekKeyId(): string;
    get kekKeyVersion(): string;
    get kekKeyringId(): string;
    get serviceAccount(): string;
}
export interface DataStackitPostgresflexInstanceFlavor {
}
export declare function dataStackitPostgresflexInstanceFlavorToTerraform(struct?: DataStackitPostgresflexInstanceFlavor): any;
export declare function dataStackitPostgresflexInstanceFlavorToHclTerraform(struct?: DataStackitPostgresflexInstanceFlavor): any;
export declare class DataStackitPostgresflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceFlavor | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceFlavor | undefined);
    get cpu(): number;
    get description(): string;
    get id(): string;
    get nodeType(): string;
    get ram(): number;
}
export interface DataStackitPostgresflexInstanceNetwork {
}
export declare function dataStackitPostgresflexInstanceNetworkToTerraform(struct?: DataStackitPostgresflexInstanceNetwork): any;
export declare function dataStackitPostgresflexInstanceNetworkToHclTerraform(struct?: DataStackitPostgresflexInstanceNetwork): any;
export declare class DataStackitPostgresflexInstanceNetworkOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceNetwork | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceNetwork | undefined);
    get accessScope(): string;
    get acl(): string[];
    get instanceAddress(): string;
    get routerAddress(): string;
}
export interface DataStackitPostgresflexInstanceStorage {
}
export declare function dataStackitPostgresflexInstanceStorageToTerraform(struct?: DataStackitPostgresflexInstanceStorage): any;
export declare function dataStackitPostgresflexInstanceStorageToHclTerraform(struct?: DataStackitPostgresflexInstanceStorage): any;
export declare class DataStackitPostgresflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitPostgresflexInstanceStorage | undefined;
    set internalValue(value: DataStackitPostgresflexInstanceStorage | undefined);
    get class(): string;
    get size(): number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance stackit_postgresflex_instance}
*/
export declare class DataStackitPostgresflexInstance extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_postgresflex_instance";
    /**
    * Generates CDKTF code for importing a DataStackitPostgresflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitPostgresflexInstance to import
    * @param importFromId The id of the existing DataStackitPostgresflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitPostgresflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.105.0/docs/data-sources/postgresflex_instance stackit_postgresflex_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitPostgresflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitPostgresflexInstanceConfig);
    get acl(): string[];
    get backupSchedule(): string;
    private _connectionInfo;
    get connectionInfo(): DataStackitPostgresflexInstanceConnectionInfoOutputReference;
    private _encryption;
    get encryption(): DataStackitPostgresflexInstanceEncryptionOutputReference;
    private _flavor;
    get flavor(): DataStackitPostgresflexInstanceFlavorOutputReference;
    get flavorId(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get name(): string;
    private _network;
    get network(): DataStackitPostgresflexInstanceNetworkOutputReference;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicas(): number;
    get retentionDays(): number;
    private _storage;
    get storage(): DataStackitPostgresflexInstanceStorageOutputReference;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
