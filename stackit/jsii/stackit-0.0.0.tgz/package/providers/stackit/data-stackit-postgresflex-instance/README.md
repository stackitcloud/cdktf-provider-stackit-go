# `data_stackit_postgresflex_instance`

Refer to the Terraform Registry for docs: [`data_stackit_postgresflex_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/data-sources/postgresflex_instance).
