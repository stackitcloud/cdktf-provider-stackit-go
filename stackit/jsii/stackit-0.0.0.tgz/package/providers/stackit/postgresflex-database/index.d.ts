import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PostgresflexDatabaseConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Postgres Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#instance_id PostgresflexDatabase#instance_id}
    */
    readonly instanceId: string;
    /**
    * Database name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#name PostgresflexDatabase#name}
    */
    readonly name: string;
    /**
    * Username of the database owner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#owner PostgresflexDatabase#owner}
    */
    readonly owner: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#project_id PostgresflexDatabase#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#region PostgresflexDatabase#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database stackit_postgresflex_database}
*/
export declare class PostgresflexDatabase extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_postgresflex_database";
    /**
    * Generates CDKTF code for importing a PostgresflexDatabase resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresflexDatabase to import
    * @param importFromId The id of the existing PostgresflexDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresflexDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/postgresflex_database stackit_postgresflex_database} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresflexDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: PostgresflexDatabaseConfig);
    get databaseId(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _owner?;
    get owner(): string;
    set owner(value: string);
    get ownerInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
