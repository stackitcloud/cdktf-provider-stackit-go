import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitNetworkAreaRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID to which the network area route is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route#network_area_id DataStackitNetworkAreaRoute#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * The network area route ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route#network_area_route_id DataStackitNetworkAreaRoute#network_area_route_id}
    */
    readonly networkAreaRouteId: string;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route#organization_id DataStackitNetworkAreaRoute#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route#region DataStackitNetworkAreaRoute#region}
    */
    readonly region?: string;
}
export interface DataStackitNetworkAreaRouteDestination {
}
export declare function dataStackitNetworkAreaRouteDestinationToTerraform(struct?: DataStackitNetworkAreaRouteDestination): any;
export declare function dataStackitNetworkAreaRouteDestinationToHclTerraform(struct?: DataStackitNetworkAreaRouteDestination): any;
export declare class DataStackitNetworkAreaRouteDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitNetworkAreaRouteDestination | undefined;
    set internalValue(value: DataStackitNetworkAreaRouteDestination | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitNetworkAreaRouteNextHop {
}
export declare function dataStackitNetworkAreaRouteNextHopToTerraform(struct?: DataStackitNetworkAreaRouteNextHop): any;
export declare function dataStackitNetworkAreaRouteNextHopToHclTerraform(struct?: DataStackitNetworkAreaRouteNextHop): any;
export declare class DataStackitNetworkAreaRouteNextHopOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitNetworkAreaRouteNextHop | undefined;
    set internalValue(value: DataStackitNetworkAreaRouteNextHop | undefined);
    get type(): string;
    get value(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route stackit_network_area_route}
*/
export declare class DataStackitNetworkAreaRoute extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_network_area_route";
    /**
    * Generates CDKTF code for importing a DataStackitNetworkAreaRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitNetworkAreaRoute to import
    * @param importFromId The id of the existing DataStackitNetworkAreaRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitNetworkAreaRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/data-sources/network_area_route stackit_network_area_route} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitNetworkAreaRouteConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitNetworkAreaRouteConfig);
    private _destination;
    get destination(): DataStackitNetworkAreaRouteDestinationOutputReference;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _networkAreaRouteId?;
    get networkAreaRouteId(): string;
    set networkAreaRouteId(value: string);
    get networkAreaRouteIdInput(): string | undefined;
    private _nextHop;
    get nextHop(): DataStackitNetworkAreaRouteNextHopOutputReference;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
