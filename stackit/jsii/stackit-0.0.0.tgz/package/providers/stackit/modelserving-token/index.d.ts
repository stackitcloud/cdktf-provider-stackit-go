import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ModelservingTokenConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the AI model serving auth token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#description ModelservingToken#description}
    */
    readonly description?: string;
    /**
    * Name of the AI model serving auth token.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#name ModelservingToken#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the AI model serving auth token is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#project_id ModelservingToken#project_id}
    */
    readonly projectId: string;
    /**
    * Region to which the AI model serving auth token is associated. If not defined, the provider region is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#region ModelservingToken#region}
    */
    readonly region?: string;
    /**
    * A map of arbitrary key/value pairs that will force recreation of the token when they change, enabling token rotation based on external conditions such as a rotating timestamp. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#rotate_when_changed ModelservingToken#rotate_when_changed}
    */
    readonly rotateWhenChanged?: {
        [key: string]: string;
    };
    /**
    * The TTL duration of the AI model serving auth token. E.g. 5h30m40s,5h,5h30m,30m,30s
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#ttl_duration ModelservingToken#ttl_duration}
    */
    readonly ttlDuration?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token stackit_modelserving_token}
*/
export declare class ModelservingToken extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_modelserving_token";
    /**
    * Generates CDKTF code for importing a ModelservingToken resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ModelservingToken to import
    * @param importFromId The id of the existing ModelservingToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ModelservingToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/modelserving_token stackit_modelserving_token} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ModelservingTokenConfig
    */
    constructor(scope: Construct, id: string, config: ModelservingTokenConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rotateWhenChanged?;
    get rotateWhenChanged(): {
        [key: string]: string;
    };
    set rotateWhenChanged(value: {
        [key: string]: string;
    });
    resetRotateWhenChanged(): void;
    get rotateWhenChangedInput(): {
        [key: string]: string;
    } | undefined;
    get state(): string;
    get token(): string;
    get tokenId(): string;
    private _ttlDuration?;
    get ttlDuration(): string;
    set ttlDuration(value: string);
    resetTtlDuration(): void;
    get ttlDurationInput(): string | undefined;
    get validUntil(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
