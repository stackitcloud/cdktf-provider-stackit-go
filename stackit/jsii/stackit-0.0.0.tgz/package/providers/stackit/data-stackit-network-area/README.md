# `data_stackit_network_area`

Refer to the Terraform Registry for docs: [`data_stackit_network_area`](https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/data-sources/network_area).
