import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitNetworkAreaConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network area ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/network_area#network_area_id DataStackitNetworkArea#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/network_area#organization_id DataStackitNetworkArea#organization_id}
    */
    readonly organizationId: string;
}
export interface DataStackitNetworkAreaNetworkRanges {
}
export declare function dataStackitNetworkAreaNetworkRangesToTerraform(struct?: DataStackitNetworkAreaNetworkRanges): any;
export declare function dataStackitNetworkAreaNetworkRangesToHclTerraform(struct?: DataStackitNetworkAreaNetworkRanges): any;
export declare class DataStackitNetworkAreaNetworkRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitNetworkAreaNetworkRanges | undefined;
    set internalValue(value: DataStackitNetworkAreaNetworkRanges | undefined);
    get networkRangeId(): string;
    get prefix(): string;
}
export declare class DataStackitNetworkAreaNetworkRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitNetworkAreaNetworkRangesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/network_area stackit_network_area}
*/
export declare class DataStackitNetworkArea extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_network_area";
    /**
    * Generates CDKTF code for importing a DataStackitNetworkArea resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitNetworkArea to import
    * @param importFromId The id of the existing DataStackitNetworkArea that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/network_area#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitNetworkArea to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/network_area stackit_network_area} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitNetworkAreaConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitNetworkAreaConfig);
    get defaultNameservers(): string[];
    get defaultPrefixLength(): number;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get maxPrefixLength(): number;
    get minPrefixLength(): number;
    get name(): string;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _networkRanges;
    get networkRanges(): DataStackitNetworkAreaNetworkRangesList;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    get projectCount(): number;
    get transferNetwork(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
