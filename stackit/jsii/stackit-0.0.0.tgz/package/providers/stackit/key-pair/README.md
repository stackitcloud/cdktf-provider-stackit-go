# `stackit_key_pair`

Refer to the Terraform Registry for docs: [`stackit_key_pair`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/key_pair).
