import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KeyPairConfig extends cdktf.TerraformMetaArguments {
    /**
    * Labels are key-value string pairs which can be attached to a resource container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair#labels KeyPair#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the SSH key pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair#name KeyPair#name}
    */
    readonly name: string;
    /**
    * A string representation of the public SSH key. E.g., `ssh-rsa <key_data>` or `ssh-ed25519 <key-data>`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair#public_key KeyPair#public_key}
    */
    readonly publicKey: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair stackit_key_pair}
*/
export declare class KeyPair extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_key_pair";
    /**
    * Generates CDKTF code for importing a KeyPair resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KeyPair to import
    * @param importFromId The id of the existing KeyPair that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KeyPair to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.91.0/docs/resources/key_pair stackit_key_pair} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KeyPairConfig
    */
    constructor(scope: Construct, id: string, config: KeyPairConfig);
    get fingerprint(): string;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _publicKey?;
    get publicKey(): string;
    set publicKey(value: string);
    get publicKeyInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
