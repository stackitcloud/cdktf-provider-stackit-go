import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerNetworkInterfaceAttachConfig extends cdktf.TerraformMetaArguments {
    /**
    * The network interface ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach#network_interface_id ServerNetworkInterfaceAttach#network_interface_id}
    */
    readonly networkInterfaceId: string;
    /**
    * STACKIT project ID to which the network interface attachment is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach#project_id ServerNetworkInterfaceAttach#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach#region ServerNetworkInterfaceAttach#region}
    */
    readonly region?: string;
    /**
    * The server ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach#server_id ServerNetworkInterfaceAttach#server_id}
    */
    readonly serverId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach stackit_server_network_interface_attach}
*/
export declare class ServerNetworkInterfaceAttach extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_network_interface_attach";
    /**
    * Generates CDKTF code for importing a ServerNetworkInterfaceAttach resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerNetworkInterfaceAttach to import
    * @param importFromId The id of the existing ServerNetworkInterfaceAttach that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerNetworkInterfaceAttach to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.87.0/docs/resources/server_network_interface_attach stackit_server_network_interface_attach} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerNetworkInterfaceAttachConfig
    */
    constructor(scope: Construct, id: string, config: ServerNetworkInterfaceAttachConfig);
    get id(): string;
    private _networkInterfaceId?;
    get networkInterfaceId(): string;
    set networkInterfaceId(value: string);
    get networkInterfaceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
