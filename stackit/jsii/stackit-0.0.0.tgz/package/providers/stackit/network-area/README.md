# `stackit_network_area`

Refer to the Terraform Registry for docs: [`stackit_network_area`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/network_area).
