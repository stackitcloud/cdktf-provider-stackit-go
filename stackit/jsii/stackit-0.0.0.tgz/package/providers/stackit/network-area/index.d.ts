import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkAreaConfig extends cdktf.TerraformMetaArguments {
    /**
    * List of DNS Servers/Nameservers for configuration of network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#default_nameservers NetworkArea#default_nameservers}
    */
    readonly defaultNameservers?: string[];
    /**
    * The default prefix length for networks in the network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#default_prefix_length NetworkArea#default_prefix_length}
    */
    readonly defaultPrefixLength?: number;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#labels NetworkArea#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The maximal prefix length for networks in the network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#max_prefix_length NetworkArea#max_prefix_length}
    */
    readonly maxPrefixLength?: number;
    /**
    * The minimal prefix length for networks in the network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#min_prefix_length NetworkArea#min_prefix_length}
    */
    readonly minPrefixLength?: number;
    /**
    * The name of the network area.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#name NetworkArea#name}
    */
    readonly name: string;
    /**
    * List of Network ranges for configuration of network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#network_ranges NetworkArea#network_ranges}
    */
    readonly networkRanges?: NetworkAreaNetworkRanges[] | cdktf.IResolvable;
    /**
    * STACKIT organization ID to which the network area is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#organization_id NetworkArea#organization_id}
    */
    readonly organizationId: string;
    /**
    * Classless Inter-Domain Routing (CIDR) for configuration of network area for region `eu01`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#transfer_network NetworkArea#transfer_network}
    */
    readonly transferNetwork?: string;
}
export interface NetworkAreaNetworkRanges {
    /**
    * Classless Inter-Domain Routing (CIDR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#prefix NetworkArea#prefix}
    */
    readonly prefix: string;
}
export declare function networkAreaNetworkRangesToTerraform(struct?: NetworkAreaNetworkRanges | cdktf.IResolvable): any;
export declare function networkAreaNetworkRangesToHclTerraform(struct?: NetworkAreaNetworkRanges | cdktf.IResolvable): any;
export declare class NetworkAreaNetworkRangesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): NetworkAreaNetworkRanges | cdktf.IResolvable | undefined;
    set internalValue(value: NetworkAreaNetworkRanges | cdktf.IResolvable | undefined);
    get networkRangeId(): string;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
}
export declare class NetworkAreaNetworkRangesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: NetworkAreaNetworkRanges[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): NetworkAreaNetworkRangesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area stackit_network_area}
*/
export declare class NetworkArea extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_network_area";
    /**
    * Generates CDKTF code for importing a NetworkArea resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NetworkArea to import
    * @param importFromId The id of the existing NetworkArea that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NetworkArea to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/network_area stackit_network_area} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkAreaConfig
    */
    constructor(scope: Construct, id: string, config: NetworkAreaConfig);
    private _defaultNameservers?;
    get defaultNameservers(): string[];
    set defaultNameservers(value: string[]);
    resetDefaultNameservers(): void;
    get defaultNameserversInput(): string[] | undefined;
    private _defaultPrefixLength?;
    get defaultPrefixLength(): number;
    set defaultPrefixLength(value: number);
    resetDefaultPrefixLength(): void;
    get defaultPrefixLengthInput(): number | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _maxPrefixLength?;
    get maxPrefixLength(): number;
    set maxPrefixLength(value: number);
    resetMaxPrefixLength(): void;
    get maxPrefixLengthInput(): number | undefined;
    private _minPrefixLength?;
    get minPrefixLength(): number;
    set minPrefixLength(value: number);
    resetMinPrefixLength(): void;
    get minPrefixLengthInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkAreaId(): string;
    private _networkRanges;
    get networkRanges(): NetworkAreaNetworkRangesList;
    putNetworkRanges(value: NetworkAreaNetworkRanges[] | cdktf.IResolvable): void;
    resetNetworkRanges(): void;
    get networkRangesInput(): cdktf.IResolvable | NetworkAreaNetworkRanges[] | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    get projectCount(): number;
    private _transferNetwork?;
    get transferNetwork(): string;
    set transferNetwork(value: string);
    resetTransferNetwork(): void;
    get transferNetworkInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
