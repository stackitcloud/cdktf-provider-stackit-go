# `stackit_sfs_resource_pool`

Refer to the Terraform Registry for docs: [`stackit_sfs_resource_pool`](https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/sfs_resource_pool).
