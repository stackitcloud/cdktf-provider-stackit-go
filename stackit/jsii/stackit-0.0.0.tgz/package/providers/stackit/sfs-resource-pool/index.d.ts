import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SfsResourcePoolConfig extends cdktf.TerraformMetaArguments {
    /**
    * Availability zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#availability_zone SfsResourcePool#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * List of IPs that can mount the resource pool in read-only; IPs must have a subnet mask (e.g. "172.16.0.0/24" for a range of IPs, or "172.16.0.250/32" for a specific IP).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#ip_acl SfsResourcePool#ip_acl}
    */
    readonly ipAcl: string[];
    /**
    * Name of the resource pool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#name SfsResourcePool#name}
    */
    readonly name: string;
    /**
    * Name of the performance class.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#performance_class SfsResourcePool#performance_class}
    */
    readonly performanceClass: string;
    /**
    * STACKIT project ID to which the resource pool is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#project_id SfsResourcePool#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#region SfsResourcePool#region}
    */
    readonly region?: string;
    /**
    * Size of the resource pool (unit: gigabytes)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#size_gigabytes SfsResourcePool#size_gigabytes}
    */
    readonly sizeGigabytes: number;
    /**
    * If set to true, snapshots are visible and accessible to users. (default: false)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#snapshots_are_visible SfsResourcePool#snapshots_are_visible}
    */
    readonly snapshotsAreVisible?: boolean | cdktf.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool stackit_sfs_resource_pool}
*/
export declare class SfsResourcePool extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_sfs_resource_pool";
    /**
    * Generates CDKTF code for importing a SfsResourcePool resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SfsResourcePool to import
    * @param importFromId The id of the existing SfsResourcePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SfsResourcePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/sfs_resource_pool stackit_sfs_resource_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SfsResourcePoolConfig
    */
    constructor(scope: Construct, id: string, config: SfsResourcePoolConfig);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    get id(): string;
    private _ipAcl?;
    get ipAcl(): string[];
    set ipAcl(value: string[]);
    get ipAclInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _performanceClass?;
    get performanceClass(): string;
    set performanceClass(value: string);
    get performanceClassInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourcePoolId(): string;
    private _sizeGigabytes?;
    get sizeGigabytes(): number;
    set sizeGigabytes(value: number);
    get sizeGigabytesInput(): number | undefined;
    private _snapshotsAreVisible?;
    get snapshotsAreVisible(): boolean | cdktf.IResolvable;
    set snapshotsAreVisible(value: boolean | cdktf.IResolvable);
    resetSnapshotsAreVisible(): void;
    get snapshotsAreVisibleInput(): boolean | cdktf.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
