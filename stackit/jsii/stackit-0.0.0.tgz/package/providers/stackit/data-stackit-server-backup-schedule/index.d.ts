import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServerBackupScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Backup schedule ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule#backup_schedule_id DataStackitServerBackupSchedule#backup_schedule_id}
    */
    readonly backupScheduleId: number;
    /**
    * STACKIT Project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule#project_id DataStackitServerBackupSchedule#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule#region DataStackitServerBackupSchedule#region}
    */
    readonly region?: string;
    /**
    * Server ID for the backup schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule#server_id DataStackitServerBackupSchedule#server_id}
    */
    readonly serverId: string;
}
export interface DataStackitServerBackupScheduleBackupProperties {
}
export declare function dataStackitServerBackupScheduleBackupPropertiesToTerraform(struct?: DataStackitServerBackupScheduleBackupProperties): any;
export declare function dataStackitServerBackupScheduleBackupPropertiesToHclTerraform(struct?: DataStackitServerBackupScheduleBackupProperties): any;
export declare class DataStackitServerBackupScheduleBackupPropertiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitServerBackupScheduleBackupProperties | undefined;
    set internalValue(value: DataStackitServerBackupScheduleBackupProperties | undefined);
    get name(): string;
    get retentionPeriod(): number;
    get volumeIds(): string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule stackit_server_backup_schedule}
*/
export declare class DataStackitServerBackupSchedule extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_server_backup_schedule";
    /**
    * Generates CDKTF code for importing a DataStackitServerBackupSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServerBackupSchedule to import
    * @param importFromId The id of the existing DataStackitServerBackupSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServerBackupSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/server_backup_schedule stackit_server_backup_schedule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServerBackupScheduleConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServerBackupScheduleConfig);
    private _backupProperties;
    get backupProperties(): DataStackitServerBackupScheduleBackupPropertiesOutputReference;
    private _backupScheduleId?;
    get backupScheduleId(): number;
    set backupScheduleId(value: number);
    get backupScheduleIdInput(): number | undefined;
    get enabled(): cdktf.IResolvable;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rrule(): string;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
