# `stackit_alb_waf_custom_rule_group`

Refer to the Terraform Registry for docs: [`stackit_alb_waf_custom_rule_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.116.0/docs/resources/alb_waf_custom_rule_group).
