import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface AlbWafCustomRuleGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Custom rule group configuration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#name AlbWafCustomRuleGroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the ALB WAF Custom Rule Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#project_id AlbWafCustomRuleGroup#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#region AlbWafCustomRuleGroup#region}
    */
    readonly region?: string;
    /**
    * Enriched rules containing auto-generated IDs and computed severity values.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#rules AlbWafCustomRuleGroup#rules}
    */
    readonly rules: AlbWafCustomRuleGroupRules[] | cdktf.IResolvable;
}
export interface AlbWafCustomRuleGroupRulesBehavior {
    /**
    * The protective stance action. ACTION_DENY forces a 403 status response code.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#action AlbWafCustomRuleGroup#action}
    */
    readonly action: string;
    /**
    * Determines whether an entry should be generated in the security ledger upon a rule hit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#log AlbWafCustomRuleGroup#log}
    */
    readonly log?: boolean | cdktf.IResolvable;
    /**
    * Custom notification message string mapped to underlying logdata contexts. Required if log is true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#log_msg AlbWafCustomRuleGroup#log_msg}
    */
    readonly logMsg?: string;
}
export declare function albWafCustomRuleGroupRulesBehaviorToTerraform(struct?: AlbWafCustomRuleGroupRulesBehavior | cdktf.IResolvable): any;
export declare function albWafCustomRuleGroupRulesBehaviorToHclTerraform(struct?: AlbWafCustomRuleGroupRulesBehavior | cdktf.IResolvable): any;
export declare class AlbWafCustomRuleGroupRulesBehaviorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlbWafCustomRuleGroupRulesBehavior | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafCustomRuleGroupRulesBehavior | cdktf.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _log?;
    get log(): boolean | cdktf.IResolvable;
    set log(value: boolean | cdktf.IResolvable);
    resetLog(): void;
    get logInput(): boolean | cdktf.IResolvable | undefined;
    private _logMsg?;
    get logMsg(): string;
    set logMsg(value: string);
    resetLogMsg(): void;
    get logMsgInput(): string | undefined;
    get severity(): string;
}
export interface AlbWafCustomRuleGroupRulesConditionsOperator {
    /**
    * The operational evaluation type definition macro.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#type AlbWafCustomRuleGroup#type}
    */
    readonly type: string;
    /**
    * The text or rule regex pattern arguments applied inside the operator execution loop.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#value AlbWafCustomRuleGroup#value}
    */
    readonly value?: string;
}
export declare function albWafCustomRuleGroupRulesConditionsOperatorToTerraform(struct?: AlbWafCustomRuleGroupRulesConditionsOperator | cdktf.IResolvable): any;
export declare function albWafCustomRuleGroupRulesConditionsOperatorToHclTerraform(struct?: AlbWafCustomRuleGroupRulesConditionsOperator | cdktf.IResolvable): any;
export declare class AlbWafCustomRuleGroupRulesConditionsOperatorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlbWafCustomRuleGroupRulesConditionsOperator | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafCustomRuleGroupRulesConditionsOperator | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AlbWafCustomRuleGroupRulesConditionsVariable {
    /**
    * The targeted validation engine variable macro.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#type AlbWafCustomRuleGroup#type}
    */
    readonly type: string;
    /**
    * Optional key element context for map variables (e.g., matching a 'Host' header key).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#value AlbWafCustomRuleGroup#value}
    */
    readonly value?: string;
}
export declare function albWafCustomRuleGroupRulesConditionsVariableToTerraform(struct?: AlbWafCustomRuleGroupRulesConditionsVariable | cdktf.IResolvable): any;
export declare function albWafCustomRuleGroupRulesConditionsVariableToHclTerraform(struct?: AlbWafCustomRuleGroupRulesConditionsVariable | cdktf.IResolvable): any;
export declare class AlbWafCustomRuleGroupRulesConditionsVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AlbWafCustomRuleGroupRulesConditionsVariable | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafCustomRuleGroupRulesConditionsVariable | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export interface AlbWafCustomRuleGroupRulesConditions {
    /**
    * The comparison logic executed against the transformed variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#operator AlbWafCustomRuleGroup#operator}
    */
    readonly operator: AlbWafCustomRuleGroupRulesConditionsOperator;
    /**
    * Ordered normalization steps applied before the operator runs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#transformations AlbWafCustomRuleGroup#transformations}
    */
    readonly transformations?: string[];
    /**
    * The part of the HTTP transaction to inspect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#variable AlbWafCustomRuleGroup#variable}
    */
    readonly variable: AlbWafCustomRuleGroupRulesConditionsVariable;
}
export declare function albWafCustomRuleGroupRulesConditionsToTerraform(struct?: AlbWafCustomRuleGroupRulesConditions | cdktf.IResolvable): any;
export declare function albWafCustomRuleGroupRulesConditionsToHclTerraform(struct?: AlbWafCustomRuleGroupRulesConditions | cdktf.IResolvable): any;
export declare class AlbWafCustomRuleGroupRulesConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlbWafCustomRuleGroupRulesConditions | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafCustomRuleGroupRulesConditions | cdktf.IResolvable | undefined);
    private _operator;
    get operator(): AlbWafCustomRuleGroupRulesConditionsOperatorOutputReference;
    putOperator(value: AlbWafCustomRuleGroupRulesConditionsOperator): void;
    get operatorInput(): cdktf.IResolvable | AlbWafCustomRuleGroupRulesConditionsOperator | undefined;
    private _transformations?;
    get transformations(): string[];
    set transformations(value: string[]);
    resetTransformations(): void;
    get transformationsInput(): string[] | undefined;
    private _variable;
    get variable(): AlbWafCustomRuleGroupRulesConditionsVariableOutputReference;
    putVariable(value: AlbWafCustomRuleGroupRulesConditionsVariable): void;
    get variableInput(): cdktf.IResolvable | AlbWafCustomRuleGroupRulesConditionsVariable | undefined;
}
export declare class AlbWafCustomRuleGroupRulesConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlbWafCustomRuleGroupRulesConditions[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlbWafCustomRuleGroupRulesConditionsOutputReference;
}
export interface AlbWafCustomRuleGroupRules {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#behavior AlbWafCustomRuleGroup#behavior}
    */
    readonly behavior: AlbWafCustomRuleGroupRulesBehavior;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#conditions AlbWafCustomRuleGroup#conditions}
    */
    readonly conditions: AlbWafCustomRuleGroupRulesConditions[] | cdktf.IResolvable;
    /**
    * A clear description explaining the threat vector or criteria addressed by this rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#description AlbWafCustomRuleGroup#description}
    */
    readonly description?: string;
}
export declare function albWafCustomRuleGroupRulesToTerraform(struct?: AlbWafCustomRuleGroupRules | cdktf.IResolvable): any;
export declare function albWafCustomRuleGroupRulesToHclTerraform(struct?: AlbWafCustomRuleGroupRules | cdktf.IResolvable): any;
export declare class AlbWafCustomRuleGroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AlbWafCustomRuleGroupRules | cdktf.IResolvable | undefined;
    set internalValue(value: AlbWafCustomRuleGroupRules | cdktf.IResolvable | undefined);
    private _behavior;
    get behavior(): AlbWafCustomRuleGroupRulesBehaviorOutputReference;
    putBehavior(value: AlbWafCustomRuleGroupRulesBehavior): void;
    get behaviorInput(): cdktf.IResolvable | AlbWafCustomRuleGroupRulesBehavior | undefined;
    private _conditions;
    get conditions(): AlbWafCustomRuleGroupRulesConditionsList;
    putConditions(value: AlbWafCustomRuleGroupRulesConditions[] | cdktf.IResolvable): void;
    get conditionsInput(): cdktf.IResolvable | AlbWafCustomRuleGroupRulesConditions[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): number;
}
export declare class AlbWafCustomRuleGroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: AlbWafCustomRuleGroupRules[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AlbWafCustomRuleGroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group stackit_alb_waf_custom_rule_group}
*/
export declare class AlbWafCustomRuleGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_alb_waf_custom_rule_group";
    /**
    * Generates CDKTF code for importing a AlbWafCustomRuleGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AlbWafCustomRuleGroup to import
    * @param importFromId The id of the existing AlbWafCustomRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AlbWafCustomRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.109.0/docs/resources/alb_waf_custom_rule_group stackit_alb_waf_custom_rule_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AlbWafCustomRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: AlbWafCustomRuleGroupConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): AlbWafCustomRuleGroupRulesList;
    putRules(value: AlbWafCustomRuleGroupRules[] | cdktf.IResolvable): void;
    get rulesInput(): cdktf.IResolvable | AlbWafCustomRuleGroupRules[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
