import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface MongodbflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Access Control List (ACL) for the MongoDB Flex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#acl MongodbflexInstance#acl}
    */
    readonly acl: string[];
    /**
    * The backup schedule. Should follow the cron scheduling system format (e.g. "0 0 * * *").
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#backup_schedule MongodbflexInstance#backup_schedule}
    */
    readonly backupSchedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#flavor MongodbflexInstance#flavor}
    */
    readonly flavor: MongodbflexInstanceFlavor;
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#name MongodbflexInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#options MongodbflexInstance#options}
    */
    readonly options: MongodbflexInstanceOptions;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#project_id MongodbflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#region MongodbflexInstance#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#replicas MongodbflexInstance#replicas}
    */
    readonly replicas: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#storage MongodbflexInstance#storage}
    */
    readonly storage: MongodbflexInstanceStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#version MongodbflexInstance#version}
    */
    readonly version: string;
}
export interface MongodbflexInstanceFlavor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#cpu MongodbflexInstance#cpu}
    */
    readonly cpu: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#ram MongodbflexInstance#ram}
    */
    readonly ram: number;
}
export declare function mongodbflexInstanceFlavorToTerraform(struct?: MongodbflexInstanceFlavor | cdktf.IResolvable): any;
export declare function mongodbflexInstanceFlavorToHclTerraform(struct?: MongodbflexInstanceFlavor | cdktf.IResolvable): any;
export declare class MongodbflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongodbflexInstanceFlavor | cdktf.IResolvable | undefined;
    set internalValue(value: MongodbflexInstanceFlavor | cdktf.IResolvable | undefined);
    private _cpu?;
    get cpu(): number;
    set cpu(value: number);
    get cpuInput(): number | undefined;
    get description(): string;
    get id(): string;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
}
export interface MongodbflexInstanceOptions {
    /**
    * The number of days that daily backups will be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#daily_snapshot_retention_days MongodbflexInstance#daily_snapshot_retention_days}
    */
    readonly dailySnapshotRetentionDays?: number;
    /**
    * The number of months that monthly backups will be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#monthly_snapshot_retention_months MongodbflexInstance#monthly_snapshot_retention_months}
    */
    readonly monthlySnapshotRetentionMonths?: number;
    /**
    * The number of hours back in time the point-in-time recovery feature will be able to recover.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#point_in_time_window_hours MongodbflexInstance#point_in_time_window_hours}
    */
    readonly pointInTimeWindowHours: number;
    /**
    * The number of days that continuous backups (controlled via the `backup_schedule`) will be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#snapshot_retention_days MongodbflexInstance#snapshot_retention_days}
    */
    readonly snapshotRetentionDays?: number;
    /**
    * Type of the MongoDB Flex instance. Possible values are: `Replica`, `Sharded`, `Single`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#type MongodbflexInstance#type}
    */
    readonly type: string;
    /**
    * The number of weeks that weekly backups will be retained.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#weekly_snapshot_retention_weeks MongodbflexInstance#weekly_snapshot_retention_weeks}
    */
    readonly weeklySnapshotRetentionWeeks?: number;
}
export declare function mongodbflexInstanceOptionsToTerraform(struct?: MongodbflexInstanceOptions | cdktf.IResolvable): any;
export declare function mongodbflexInstanceOptionsToHclTerraform(struct?: MongodbflexInstanceOptions | cdktf.IResolvable): any;
export declare class MongodbflexInstanceOptionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongodbflexInstanceOptions | cdktf.IResolvable | undefined;
    set internalValue(value: MongodbflexInstanceOptions | cdktf.IResolvable | undefined);
    private _dailySnapshotRetentionDays?;
    get dailySnapshotRetentionDays(): number;
    set dailySnapshotRetentionDays(value: number);
    resetDailySnapshotRetentionDays(): void;
    get dailySnapshotRetentionDaysInput(): number | undefined;
    private _monthlySnapshotRetentionMonths?;
    get monthlySnapshotRetentionMonths(): number;
    set monthlySnapshotRetentionMonths(value: number);
    resetMonthlySnapshotRetentionMonths(): void;
    get monthlySnapshotRetentionMonthsInput(): number | undefined;
    private _pointInTimeWindowHours?;
    get pointInTimeWindowHours(): number;
    set pointInTimeWindowHours(value: number);
    get pointInTimeWindowHoursInput(): number | undefined;
    private _snapshotRetentionDays?;
    get snapshotRetentionDays(): number;
    set snapshotRetentionDays(value: number);
    resetSnapshotRetentionDays(): void;
    get snapshotRetentionDaysInput(): number | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _weeklySnapshotRetentionWeeks?;
    get weeklySnapshotRetentionWeeks(): number;
    set weeklySnapshotRetentionWeeks(value: number);
    resetWeeklySnapshotRetentionWeeks(): void;
    get weeklySnapshotRetentionWeeksInput(): number | undefined;
}
export interface MongodbflexInstanceStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#class MongodbflexInstance#class}
    */
    readonly class: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#size MongodbflexInstance#size}
    */
    readonly size: number;
}
export declare function mongodbflexInstanceStorageToTerraform(struct?: MongodbflexInstanceStorage | cdktf.IResolvable): any;
export declare function mongodbflexInstanceStorageToHclTerraform(struct?: MongodbflexInstanceStorage | cdktf.IResolvable): any;
export declare class MongodbflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): MongodbflexInstanceStorage | cdktf.IResolvable | undefined;
    set internalValue(value: MongodbflexInstanceStorage | cdktf.IResolvable | undefined);
    private _class?;
    get class(): string;
    set class(value: string);
    get classInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance stackit_mongodbflex_instance}
*/
export declare class MongodbflexInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_mongodbflex_instance";
    /**
    * Generates CDKTF code for importing a MongodbflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the MongodbflexInstance to import
    * @param importFromId The id of the existing MongodbflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the MongodbflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/mongodbflex_instance stackit_mongodbflex_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options MongodbflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: MongodbflexInstanceConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    get aclInput(): string[] | undefined;
    private _backupSchedule?;
    get backupSchedule(): string;
    set backupSchedule(value: string);
    get backupScheduleInput(): string | undefined;
    private _flavor;
    get flavor(): MongodbflexInstanceFlavorOutputReference;
    putFlavor(value: MongodbflexInstanceFlavor): void;
    get flavorInput(): cdktf.IResolvable | MongodbflexInstanceFlavor | undefined;
    get id(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _options;
    get options(): MongodbflexInstanceOptionsOutputReference;
    putOptions(value: MongodbflexInstanceOptions): void;
    get optionsInput(): cdktf.IResolvable | MongodbflexInstanceOptions | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicas?;
    get replicas(): number;
    set replicas(value: number);
    get replicasInput(): number | undefined;
    private _storage;
    get storage(): MongodbflexInstanceStorageOutputReference;
    putStorage(value: MongodbflexInstanceStorage): void;
    get storageInput(): cdktf.IResolvable | MongodbflexInstanceStorage | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
