# `stackit_mongodbflex_instance`

Refer to the Terraform Registry for docs: [`stackit_mongodbflex_instance`](https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/mongodbflex_instance).
