# `stackit_redis_credential`

Refer to the Terraform Registry for docs: [`stackit_redis_credential`](https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/redis_credential).
