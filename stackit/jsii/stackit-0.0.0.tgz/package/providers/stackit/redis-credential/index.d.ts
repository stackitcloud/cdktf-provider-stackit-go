import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RedisCredentialConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Redis instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/redis_credential#instance_id RedisCredential#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/redis_credential#project_id RedisCredential#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/redis_credential stackit_redis_credential}
*/
export declare class RedisCredential extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_redis_credential";
    /**
    * Generates CDKTF code for importing a RedisCredential resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RedisCredential to import
    * @param importFromId The id of the existing RedisCredential that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/redis_credential#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RedisCredential to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.92.0/docs/resources/redis_credential stackit_redis_credential} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RedisCredentialConfig
    */
    constructor(scope: Construct, id: string, config: RedisCredentialConfig);
    get credentialId(): string;
    get host(): string;
    get hosts(): string[];
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get loadBalancedHost(): string;
    get password(): string;
    get port(): number;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get uri(): string;
    get username(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
