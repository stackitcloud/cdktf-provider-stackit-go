import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAffinityGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The affinity group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group#affinity_group_id DataStackitAffinityGroup#affinity_group_id}
    */
    readonly affinityGroupId: string;
    /**
    * STACKIT Project ID to which the affinity group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group#project_id DataStackitAffinityGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group#region DataStackitAffinityGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group stackit_affinity_group}
*/
export declare class DataStackitAffinityGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_affinity_group";
    /**
    * Generates CDKTF code for importing a DataStackitAffinityGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAffinityGroup to import
    * @param importFromId The id of the existing DataStackitAffinityGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAffinityGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/affinity_group stackit_affinity_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAffinityGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAffinityGroupConfig);
    private _affinityGroupId?;
    get affinityGroupId(): string;
    set affinityGroupId(value: string);
    get affinityGroupIdInput(): string | undefined;
    get id(): string;
    get members(): string[];
    get name(): string;
    get policy(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
