# `data_stackit_affinity_group`

Refer to the Terraform Registry for docs: [`data_stackit_affinity_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.120.0/docs/data-sources/affinity_group).
