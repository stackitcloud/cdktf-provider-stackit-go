import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ResourcemanagerProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * Labels are key-value string pairs which can be attached to a resource container. A label key must match the regex [A-ZÄÜÖa-zäüöß0-9_-]{1,64}. A label value must match the regex ^$|[A-ZÄÜÖa-zäüöß0-9_-]{1,64}.
    * To create a project within a STACKIT Network Area, setting the label `networkArea=<networkAreaID>` is required. This can not be changed after project creation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project#labels ResourcemanagerProject#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Project name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project#name ResourcemanagerProject#name}
    */
    readonly name: string;
    /**
    * Email address of the owner of the project. This value is only considered during creation. Changing it afterwards will have no effect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project#owner_email ResourcemanagerProject#owner_email}
    */
    readonly ownerEmail: string;
    /**
    * Parent resource identifier. Both container ID (user-friendly) and UUID are supported
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project#parent_container_id ResourcemanagerProject#parent_container_id}
    */
    readonly parentContainerId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project stackit_resourcemanager_project}
*/
export declare class ResourcemanagerProject extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_resourcemanager_project";
    /**
    * Generates CDKTF code for importing a ResourcemanagerProject resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ResourcemanagerProject to import
    * @param importFromId The id of the existing ResourcemanagerProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ResourcemanagerProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.84.0/docs/resources/resourcemanager_project stackit_resourcemanager_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ResourcemanagerProjectConfig
    */
    constructor(scope: Construct, id: string, config: ResourcemanagerProjectConfig);
    get containerId(): string;
    get creationTime(): string;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ownerEmail?;
    get ownerEmail(): string;
    set ownerEmail(value: string);
    get ownerEmailInput(): string | undefined;
    private _parentContainerId?;
    get parentContainerId(): string;
    set parentContainerId(value: string);
    get parentContainerIdInput(): string | undefined;
    get projectId(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
