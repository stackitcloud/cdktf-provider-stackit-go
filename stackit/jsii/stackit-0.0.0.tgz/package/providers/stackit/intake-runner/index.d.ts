import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface IntakeRunnerConfig extends cdktf.TerraformMetaArguments {
    /**
    * The description of the runner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#description IntakeRunner#description}
    */
    readonly description?: string;
    /**
    * User-defined labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#labels IntakeRunner#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The maximum message size in KiB.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#max_message_size_kib IntakeRunner#max_message_size_kib}
    */
    readonly maxMessageSizeKib: number;
    /**
    * The maximum number of messages per hour.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#max_messages_per_hour IntakeRunner#max_messages_per_hour}
    */
    readonly maxMessagesPerHour: number;
    /**
    * The name of the runner.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#name IntakeRunner#name}
    */
    readonly name: string;
    /**
    * STACKIT Project ID to which the runner is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#project_id IntakeRunner#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#region IntakeRunner#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner stackit_intake_runner}
*/
export declare class IntakeRunner extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_intake_runner";
    /**
    * Generates CDKTF code for importing a IntakeRunner resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the IntakeRunner to import
    * @param importFromId The id of the existing IntakeRunner that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the IntakeRunner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/resources/intake_runner stackit_intake_runner} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options IntakeRunnerConfig
    */
    constructor(scope: Construct, id: string, config: IntakeRunnerConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _maxMessageSizeKib?;
    get maxMessageSizeKib(): number;
    set maxMessageSizeKib(value: number);
    get maxMessageSizeKibInput(): number | undefined;
    private _maxMessagesPerHour?;
    get maxMessagesPerHour(): number;
    set maxMessagesPerHour(value: number);
    get maxMessagesPerHourInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get runnerId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
