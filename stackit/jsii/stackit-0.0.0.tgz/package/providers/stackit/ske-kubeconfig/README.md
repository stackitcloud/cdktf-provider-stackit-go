# `stackit_ske_kubeconfig`

Refer to the Terraform Registry for docs: [`stackit_ske_kubeconfig`](https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/ske_kubeconfig).
