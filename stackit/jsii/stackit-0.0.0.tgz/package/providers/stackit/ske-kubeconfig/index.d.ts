import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface SkeKubeconfigConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the SKE cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#cluster_name SkeKubeconfig#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Expiration time of the kubeconfig, in seconds. Defaults to `3600`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#expiration SkeKubeconfig#expiration}
    */
    readonly expiration?: number;
    /**
    * STACKIT project ID to which the cluster is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#project_id SkeKubeconfig#project_id}
    */
    readonly projectId: string;
    /**
    * If set to true, the provider will check if the kubeconfig has expired and will generated a new valid one in-place
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#refresh SkeKubeconfig#refresh}
    */
    readonly refresh?: boolean | cdktf.IResolvable;
    /**
    * Number of seconds before expiration to trigger refresh of the kubeconfig at. Only used if refresh is set to true.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#refresh_before SkeKubeconfig#refresh_before}
    */
    readonly refreshBefore?: number;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#region SkeKubeconfig#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig stackit_ske_kubeconfig}
*/
export declare class SkeKubeconfig extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_ske_kubeconfig";
    /**
    * Generates CDKTF code for importing a SkeKubeconfig resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SkeKubeconfig to import
    * @param importFromId The id of the existing SkeKubeconfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SkeKubeconfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/ske_kubeconfig stackit_ske_kubeconfig} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SkeKubeconfigConfig
    */
    constructor(scope: Construct, id: string, config: SkeKubeconfigConfig);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get creationTime(): string;
    private _expiration?;
    get expiration(): number;
    set expiration(value: number);
    resetExpiration(): void;
    get expirationInput(): number | undefined;
    get expiresAt(): string;
    get id(): string;
    get kubeConfig(): string;
    get kubeConfigId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _refresh?;
    get refresh(): boolean | cdktf.IResolvable;
    set refresh(value: boolean | cdktf.IResolvable);
    resetRefresh(): void;
    get refreshInput(): boolean | cdktf.IResolvable | undefined;
    private _refreshBefore?;
    get refreshBefore(): number;
    set refreshBefore(value: number);
    resetRefreshBefore(): void;
    get refreshBeforeInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
