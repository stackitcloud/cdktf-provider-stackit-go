import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitScfPlatformConfig extends cdktf.TerraformMetaArguments {
    /**
    * The unique id of the platform
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform#platform_id DataStackitScfPlatform#platform_id}
    */
    readonly platformId: string;
    /**
    * The ID of the project associated with the platform
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform#project_id DataStackitScfPlatform#project_id}
    */
    readonly projectId: string;
    /**
    * The region where the platform is located. If not defined, the provider region is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform#region DataStackitScfPlatform#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform stackit_scf_platform}
*/
export declare class DataStackitScfPlatform extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_scf_platform";
    /**
    * Generates CDKTF code for importing a DataStackitScfPlatform resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitScfPlatform to import
    * @param importFromId The id of the existing DataStackitScfPlatform that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitScfPlatform to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/scf_platform stackit_scf_platform} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitScfPlatformConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitScfPlatformConfig);
    get apiUrl(): string;
    get consoleUrl(): string;
    get displayName(): string;
    get id(): string;
    private _platformId?;
    get platformId(): string;
    set platformId(value: string);
    get platformIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get systemId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
