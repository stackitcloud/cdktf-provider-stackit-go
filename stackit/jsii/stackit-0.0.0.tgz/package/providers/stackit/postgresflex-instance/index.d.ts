import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface PostgresflexInstanceConfig extends cdktf.TerraformMetaArguments {
    /**
    * The Access Control List (ACL) for the PostgresFlex instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#acl PostgresflexInstance#acl}
    */
    readonly acl: string[];
    /**
    * The schedule for on what time and how often the database backup will be created. Must be a valid cron expression using numeric minute and hour values, e.g: '0 2 * * *'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#backup_schedule PostgresflexInstance#backup_schedule}
    */
    readonly backupSchedule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#flavor PostgresflexInstance#flavor}
    */
    readonly flavor: PostgresflexInstanceFlavor;
    /**
    * Instance name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#name PostgresflexInstance#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#project_id PostgresflexInstance#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#region PostgresflexInstance#region}
    */
    readonly region?: string;
    /**
    * How many replicas the instance should have. Valid values are 1 for single mode or 3 for replication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#replicas PostgresflexInstance#replicas}
    */
    readonly replicas: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#storage PostgresflexInstance#storage}
    */
    readonly storage: PostgresflexInstanceStorage;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#version PostgresflexInstance#version}
    */
    readonly version: string;
}
export interface PostgresflexInstanceFlavor {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#cpu PostgresflexInstance#cpu}
    */
    readonly cpu: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#ram PostgresflexInstance#ram}
    */
    readonly ram: number;
}
export declare function postgresflexInstanceFlavorToTerraform(struct?: PostgresflexInstanceFlavor | cdktf.IResolvable): any;
export declare function postgresflexInstanceFlavorToHclTerraform(struct?: PostgresflexInstanceFlavor | cdktf.IResolvable): any;
export declare class PostgresflexInstanceFlavorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresflexInstanceFlavor | cdktf.IResolvable | undefined;
    set internalValue(value: PostgresflexInstanceFlavor | cdktf.IResolvable | undefined);
    private _cpu?;
    get cpu(): number;
    set cpu(value: number);
    get cpuInput(): number | undefined;
    get description(): string;
    get id(): string;
    private _ram?;
    get ram(): number;
    set ram(value: number);
    get ramInput(): number | undefined;
}
export interface PostgresflexInstanceStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#class PostgresflexInstance#class}
    */
    readonly class: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#size PostgresflexInstance#size}
    */
    readonly size: number;
}
export declare function postgresflexInstanceStorageToTerraform(struct?: PostgresflexInstanceStorage | cdktf.IResolvable): any;
export declare function postgresflexInstanceStorageToHclTerraform(struct?: PostgresflexInstanceStorage | cdktf.IResolvable): any;
export declare class PostgresflexInstanceStorageOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PostgresflexInstanceStorage | cdktf.IResolvable | undefined;
    set internalValue(value: PostgresflexInstanceStorage | cdktf.IResolvable | undefined);
    private _class?;
    get class(): string;
    set class(value: string);
    get classInput(): string | undefined;
    private _size?;
    get size(): number;
    set size(value: number);
    get sizeInput(): number | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance stackit_postgresflex_instance}
*/
export declare class PostgresflexInstance extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_postgresflex_instance";
    /**
    * Generates CDKTF code for importing a PostgresflexInstance resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostgresflexInstance to import
    * @param importFromId The id of the existing PostgresflexInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostgresflexInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/postgresflex_instance stackit_postgresflex_instance} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostgresflexInstanceConfig
    */
    constructor(scope: Construct, id: string, config: PostgresflexInstanceConfig);
    private _acl?;
    get acl(): string[];
    set acl(value: string[]);
    get aclInput(): string[] | undefined;
    private _backupSchedule?;
    get backupSchedule(): string;
    set backupSchedule(value: string);
    get backupScheduleInput(): string | undefined;
    private _flavor;
    get flavor(): PostgresflexInstanceFlavorOutputReference;
    putFlavor(value: PostgresflexInstanceFlavor): void;
    get flavorInput(): cdktf.IResolvable | PostgresflexInstanceFlavor | undefined;
    get id(): string;
    get instanceId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicas?;
    get replicas(): number;
    set replicas(value: number);
    get replicasInput(): number | undefined;
    private _storage;
    get storage(): PostgresflexInstanceStorageOutputReference;
    putStorage(value: PostgresflexInstanceStorage): void;
    get storageInput(): cdktf.IResolvable | PostgresflexInstanceStorage | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
