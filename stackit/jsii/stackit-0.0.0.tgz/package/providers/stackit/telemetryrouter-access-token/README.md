# `stackit_telemetryrouter_access_token`

Refer to the Terraform Registry for docs: [`stackit_telemetryrouter_access_token`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/resources/telemetryrouter_access_token).
