# `stackit_telemetrylink`

Refer to the Terraform Registry for docs: [`stackit_telemetrylink`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/resources/telemetrylink).
