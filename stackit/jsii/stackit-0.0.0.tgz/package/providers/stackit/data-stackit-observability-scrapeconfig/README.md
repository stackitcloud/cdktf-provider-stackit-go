# `data_stackit_observability_scrapeconfig`

Refer to the Terraform Registry for docs: [`data_stackit_observability_scrapeconfig`](https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/data-sources/observability_scrapeconfig).
