import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObservabilityScrapeconfigConfig extends cdktf.TerraformMetaArguments {
    /**
    * Observability instance ID to which the scraping job is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig#instance_id DataStackitObservabilityScrapeconfig#instance_id}
    */
    readonly instanceId: string;
    /**
    * Specifies the name of the scraping job
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig#name DataStackitObservabilityScrapeconfig#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the scraping job is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig#project_id DataStackitObservabilityScrapeconfig#project_id}
    */
    readonly projectId: string;
}
export interface DataStackitObservabilityScrapeconfigBasicAuth {
}
export declare function dataStackitObservabilityScrapeconfigBasicAuthToTerraform(struct?: DataStackitObservabilityScrapeconfigBasicAuth): any;
export declare function dataStackitObservabilityScrapeconfigBasicAuthToHclTerraform(struct?: DataStackitObservabilityScrapeconfigBasicAuth): any;
export declare class DataStackitObservabilityScrapeconfigBasicAuthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitObservabilityScrapeconfigBasicAuth | undefined;
    set internalValue(value: DataStackitObservabilityScrapeconfigBasicAuth | undefined);
    get password(): string;
    get username(): string;
}
export interface DataStackitObservabilityScrapeconfigSaml2 {
}
export declare function dataStackitObservabilityScrapeconfigSaml2ToTerraform(struct?: DataStackitObservabilityScrapeconfigSaml2): any;
export declare function dataStackitObservabilityScrapeconfigSaml2ToHclTerraform(struct?: DataStackitObservabilityScrapeconfigSaml2): any;
export declare class DataStackitObservabilityScrapeconfigSaml2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitObservabilityScrapeconfigSaml2 | undefined;
    set internalValue(value: DataStackitObservabilityScrapeconfigSaml2 | undefined);
    get enableUrlParameters(): cdktf.IResolvable;
}
export interface DataStackitObservabilityScrapeconfigTargets {
}
export declare function dataStackitObservabilityScrapeconfigTargetsToTerraform(struct?: DataStackitObservabilityScrapeconfigTargets): any;
export declare function dataStackitObservabilityScrapeconfigTargetsToHclTerraform(struct?: DataStackitObservabilityScrapeconfigTargets): any;
export declare class DataStackitObservabilityScrapeconfigTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitObservabilityScrapeconfigTargets | undefined;
    set internalValue(value: DataStackitObservabilityScrapeconfigTargets | undefined);
    private _labels;
    get labels(): cdktf.StringMap;
    get urls(): string[];
}
export declare class DataStackitObservabilityScrapeconfigTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitObservabilityScrapeconfigTargetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig stackit_observability_scrapeconfig}
*/
export declare class DataStackitObservabilityScrapeconfig extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_observability_scrapeconfig";
    /**
    * Generates CDKTF code for importing a DataStackitObservabilityScrapeconfig resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObservabilityScrapeconfig to import
    * @param importFromId The id of the existing DataStackitObservabilityScrapeconfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObservabilityScrapeconfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/data-sources/observability_scrapeconfig stackit_observability_scrapeconfig} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObservabilityScrapeconfigConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObservabilityScrapeconfigConfig);
    private _basicAuth;
    get basicAuth(): DataStackitObservabilityScrapeconfigBasicAuthOutputReference;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get metricsPath(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _saml2;
    get saml2(): DataStackitObservabilityScrapeconfigSaml2OutputReference;
    get sampleLimit(): number;
    get scheme(): string;
    get scrapeInterval(): string;
    get scrapeTimeout(): string;
    private _targets;
    get targets(): DataStackitObservabilityScrapeconfigTargetsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
