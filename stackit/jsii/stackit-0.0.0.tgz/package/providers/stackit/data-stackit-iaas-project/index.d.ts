import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitIaasProjectConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/iaas_project#project_id DataStackitIaasProject#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/iaas_project stackit_iaas_project}
*/
export declare class DataStackitIaasProject extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_iaas_project";
    /**
    * Generates CDKTF code for importing a DataStackitIaasProject resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitIaasProject to import
    * @param importFromId The id of the existing DataStackitIaasProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/iaas_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitIaasProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/data-sources/iaas_project stackit_iaas_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitIaasProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitIaasProjectConfig);
    get areaId(): string;
    get createdAt(): string;
    get id(): string;
    get internetAccess(): cdktf.IResolvable;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get state(): string;
    get status(): string;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
