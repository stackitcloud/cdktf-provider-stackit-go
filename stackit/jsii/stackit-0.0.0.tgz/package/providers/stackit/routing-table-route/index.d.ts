import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface RoutingTableRouteConfig extends cdktf.TerraformMetaArguments {
    /**
    * Destination of the route.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#destination RoutingTableRoute#destination}
    */
    readonly destination: RoutingTableRouteDestination;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#labels RoutingTableRoute#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The network area ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#network_area_id RoutingTableRoute#network_area_id}
    */
    readonly networkAreaId: string;
    /**
    * Next hop destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#next_hop RoutingTableRoute#next_hop}
    */
    readonly nextHop: RoutingTableRouteNextHop;
    /**
    * STACKIT organization ID to which the routing table is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#organization_id RoutingTableRoute#organization_id}
    */
    readonly organizationId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#region RoutingTableRoute#region}
    */
    readonly region?: string;
    /**
    * The routing tables ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#routing_table_id RoutingTableRoute#routing_table_id}
    */
    readonly routingTableId: string;
}
export interface RoutingTableRouteDestination {
    /**
    * CIDRV type. Possible values are: `cidrv4`, `cidrv6`. Only `cidrv4` is supported during experimental stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#type RoutingTableRoute#type}
    */
    readonly type: string;
    /**
    * An CIDR string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#value RoutingTableRoute#value}
    */
    readonly value: string;
}
export declare function routingTableRouteDestinationToTerraform(struct?: RoutingTableRouteDestination | cdktf.IResolvable): any;
export declare function routingTableRouteDestinationToHclTerraform(struct?: RoutingTableRouteDestination | cdktf.IResolvable): any;
export declare class RoutingTableRouteDestinationOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RoutingTableRouteDestination | cdktf.IResolvable | undefined;
    set internalValue(value: RoutingTableRouteDestination | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export interface RoutingTableRouteNextHop {
    /**
    * Type of the next hop. Possible values are: `blackhole`, `internet`, `ipv4`, `ipv6`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#type RoutingTableRoute#type}
    */
    readonly type: string;
    /**
    * Either IPv4 or IPv6 (not set for blackhole and internet). Only IPv4 supported during experimental stage.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#value RoutingTableRoute#value}
    */
    readonly value?: string;
}
export declare function routingTableRouteNextHopToTerraform(struct?: RoutingTableRouteNextHop | cdktf.IResolvable): any;
export declare function routingTableRouteNextHopToHclTerraform(struct?: RoutingTableRouteNextHop | cdktf.IResolvable): any;
export declare class RoutingTableRouteNextHopOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): RoutingTableRouteNextHop | cdktf.IResolvable | undefined;
    set internalValue(value: RoutingTableRouteNextHop | cdktf.IResolvable | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route stackit_routing_table_route}
*/
export declare class RoutingTableRoute extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_routing_table_route";
    /**
    * Generates CDKTF code for importing a RoutingTableRoute resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the RoutingTableRoute to import
    * @param importFromId The id of the existing RoutingTableRoute that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the RoutingTableRoute to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.88.0/docs/resources/routing_table_route stackit_routing_table_route} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options RoutingTableRouteConfig
    */
    constructor(scope: Construct, id: string, config: RoutingTableRouteConfig);
    get createdAt(): string;
    private _destination;
    get destination(): RoutingTableRouteDestinationOutputReference;
    putDestination(value: RoutingTableRouteDestination): void;
    get destinationInput(): cdktf.IResolvable | RoutingTableRouteDestination | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _networkAreaId?;
    get networkAreaId(): string;
    set networkAreaId(value: string);
    get networkAreaIdInput(): string | undefined;
    private _nextHop;
    get nextHop(): RoutingTableRouteNextHopOutputReference;
    putNextHop(value: RoutingTableRouteNextHop): void;
    get nextHopInput(): cdktf.IResolvable | RoutingTableRouteNextHop | undefined;
    private _organizationId?;
    get organizationId(): string;
    set organizationId(value: string);
    get organizationIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routeId(): string;
    private _routingTableId?;
    get routingTableId(): string;
    set routingTableId(value: string);
    get routingTableIdInput(): string | undefined;
    get updatedAt(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
