import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServerBackupScheduleConfig extends cdktf.TerraformMetaArguments {
    /**
    * Backup schedule details for the backups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#backup_properties ServerBackupSchedule#backup_properties}
    */
    readonly backupProperties: ServerBackupScheduleBackupProperties;
    /**
    * Is the backup schedule enabled or disabled.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#enabled ServerBackupSchedule#enabled}
    */
    readonly enabled: boolean | cdktf.IResolvable;
    /**
    * The schedule name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#name ServerBackupSchedule#name}
    */
    readonly name: string;
    /**
    * STACKIT Project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#project_id ServerBackupSchedule#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#region ServerBackupSchedule#region}
    */
    readonly region?: string;
    /**
    * An `rrule` (Recurrence Rule) is a standardized string format used in iCalendar (RFC 5545) to define repeating events, and you can generate one by using a dedicated library or by using online generator tools to specify parameters like frequency, interval, and end dates.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#rrule ServerBackupSchedule#rrule}
    */
    readonly rrule: string;
    /**
    * Server ID for the backup schedule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#server_id ServerBackupSchedule#server_id}
    */
    readonly serverId: string;
}
export interface ServerBackupScheduleBackupProperties {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#name ServerBackupSchedule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#retention_period ServerBackupSchedule#retention_period}
    */
    readonly retentionPeriod: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#volume_ids ServerBackupSchedule#volume_ids}
    */
    readonly volumeIds?: string[];
}
export declare function serverBackupScheduleBackupPropertiesToTerraform(struct?: ServerBackupScheduleBackupProperties | cdktf.IResolvable): any;
export declare function serverBackupScheduleBackupPropertiesToHclTerraform(struct?: ServerBackupScheduleBackupProperties | cdktf.IResolvable): any;
export declare class ServerBackupScheduleBackupPropertiesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServerBackupScheduleBackupProperties | cdktf.IResolvable | undefined;
    set internalValue(value: ServerBackupScheduleBackupProperties | cdktf.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    get retentionPeriodInput(): number | undefined;
    private _volumeIds?;
    get volumeIds(): string[];
    set volumeIds(value: string[]);
    resetVolumeIds(): void;
    get volumeIdsInput(): string[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule stackit_server_backup_schedule}
*/
export declare class ServerBackupSchedule extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_server_backup_schedule";
    /**
    * Generates CDKTF code for importing a ServerBackupSchedule resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServerBackupSchedule to import
    * @param importFromId The id of the existing ServerBackupSchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServerBackupSchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.89.0/docs/resources/server_backup_schedule stackit_server_backup_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServerBackupScheduleConfig
    */
    constructor(scope: Construct, id: string, config: ServerBackupScheduleConfig);
    private _backupProperties;
    get backupProperties(): ServerBackupScheduleBackupPropertiesOutputReference;
    putBackupProperties(value: ServerBackupScheduleBackupProperties): void;
    get backupPropertiesInput(): cdktf.IResolvable | ServerBackupScheduleBackupProperties | undefined;
    get backupScheduleId(): number;
    private _enabled?;
    get enabled(): boolean | cdktf.IResolvable;
    set enabled(value: boolean | cdktf.IResolvable);
    get enabledInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rrule?;
    get rrule(): string;
    set rrule(value: string);
    get rruleInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
