import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface KmsKeyringConfig extends cdktf.TerraformMetaArguments {
    /**
    * A user chosen description to distinguish multiple keyrings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring#description KmsKeyring#description}
    */
    readonly description?: string;
    /**
    * The display name to distinguish multiple keyrings.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring#display_name KmsKeyring#display_name}
    */
    readonly displayName: string;
    /**
    * STACKIT project ID to which the keyring is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring#project_id KmsKeyring#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring#region KmsKeyring#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring stackit_kms_keyring}
*/
export declare class KmsKeyring extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_kms_keyring";
    /**
    * Generates CDKTF code for importing a KmsKeyring resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the KmsKeyring to import
    * @param importFromId The id of the existing KmsKeyring that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the KmsKeyring to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/kms_keyring stackit_kms_keyring} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options KmsKeyringConfig
    */
    constructor(scope: Construct, id: string, config: KmsKeyringConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    get id(): string;
    get keyringId(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
