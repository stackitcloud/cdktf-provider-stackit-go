import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ServiceAccountConfig extends cdktf.TerraformMetaArguments {
    /**
    * Name of the service account.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/service_account#name ServiceAccount#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the service account is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/service_account#project_id ServiceAccount#project_id}
    */
    readonly projectId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/service_account stackit_service_account}
*/
export declare class ServiceAccount extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_service_account";
    /**
    * Generates CDKTF code for importing a ServiceAccount resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServiceAccount to import
    * @param importFromId The id of the existing ServiceAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/service_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServiceAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.85.0/docs/resources/service_account stackit_service_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServiceAccountConfig
    */
    constructor(scope: Construct, id: string, config: ServiceAccountConfig);
    get email(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get serviceAccountId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
