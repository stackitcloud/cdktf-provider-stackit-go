# `stackit_service_account`

Refer to the Terraform Registry for docs: [`stackit_service_account`](https://registry.terraform.io/providers/stackitcloud/stackit/0.102.0/docs/resources/service_account).
