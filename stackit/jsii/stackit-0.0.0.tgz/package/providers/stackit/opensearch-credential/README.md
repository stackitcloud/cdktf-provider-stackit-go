# `stackit_opensearch_credential`

Refer to the Terraform Registry for docs: [`stackit_opensearch_credential`](https://registry.terraform.io/providers/stackitcloud/stackit/0.108.0/docs/resources/opensearch_credential).
