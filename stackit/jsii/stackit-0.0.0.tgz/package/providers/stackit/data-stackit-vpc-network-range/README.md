# `data_stackit_vpc_network_range`

Refer to the Terraform Registry for docs: [`data_stackit_vpc_network_range`](https://registry.terraform.io/providers/stackitcloud/stackit/0.121.0/docs/data-sources/vpc_network_range).
