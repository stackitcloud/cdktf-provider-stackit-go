# `data_stackit_vpc_network_range`

Refer to the Terraform Registry for docs: [`data_stackit_vpc_network_range`](https://registry.terraform.io/providers/stackitcloud/stackit/0.107.1/docs/data-sources/vpc_network_range).
