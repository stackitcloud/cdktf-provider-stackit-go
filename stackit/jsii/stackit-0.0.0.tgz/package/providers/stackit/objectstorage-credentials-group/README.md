# `stackit_objectstorage_credentials_group`

Refer to the Terraform Registry for docs: [`stackit_objectstorage_credentials_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/objectstorage_credentials_group).
