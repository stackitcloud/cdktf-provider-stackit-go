import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObjectstorageCredentialsGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credentials group's display name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group#name ObjectstorageCredentialsGroup#name}
    */
    readonly name: string;
    /**
    * Project ID to which the credentials group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group#project_id ObjectstorageCredentialsGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group#region ObjectstorageCredentialsGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group stackit_objectstorage_credentials_group}
*/
export declare class ObjectstorageCredentialsGroup extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_objectstorage_credentials_group";
    /**
    * Generates CDKTF code for importing a ObjectstorageCredentialsGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObjectstorageCredentialsGroup to import
    * @param importFromId The id of the existing ObjectstorageCredentialsGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObjectstorageCredentialsGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.95.0/docs/resources/objectstorage_credentials_group stackit_objectstorage_credentials_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObjectstorageCredentialsGroupConfig
    */
    constructor(scope: Construct, id: string, config: ObjectstorageCredentialsGroupConfig);
    get credentialsGroupId(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
