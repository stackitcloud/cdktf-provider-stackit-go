import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitSecretsmanagerUserConfig extends cdktf.TerraformMetaArguments {
    /**
    * ID of the Secrets Manager instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user#instance_id DataStackitSecretsmanagerUser#instance_id}
    */
    readonly instanceId: string;
    /**
    * STACKIT Project ID to which the instance is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user#project_id DataStackitSecretsmanagerUser#project_id}
    */
    readonly projectId: string;
    /**
    * The user's ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user#user_id DataStackitSecretsmanagerUser#user_id}
    */
    readonly userId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user stackit_secretsmanager_user}
*/
export declare class DataStackitSecretsmanagerUser extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_secretsmanager_user";
    /**
    * Generates CDKTF code for importing a DataStackitSecretsmanagerUser resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitSecretsmanagerUser to import
    * @param importFromId The id of the existing DataStackitSecretsmanagerUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitSecretsmanagerUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.100.0/docs/data-sources/secretsmanager_user stackit_secretsmanager_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitSecretsmanagerUserConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitSecretsmanagerUserConfig);
    get description(): string;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    get userIdInput(): string | undefined;
    get username(): string;
    get writeEnabled(): cdktf.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
