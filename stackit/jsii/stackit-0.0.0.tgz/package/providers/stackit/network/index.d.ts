import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface NetworkConfig extends cdktf.TerraformMetaArguments {
    /**
    * If the network has DHCP enabled. Default value is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#dhcp Network#dhcp}
    */
    readonly dhcp?: boolean | cdktf.IResolvable;
    /**
    * The IPv4 gateway of a network. If not specified, the first IP of the network will be assigned as the gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv4_gateway Network#ipv4_gateway}
    */
    readonly ipv4Gateway?: string;
    /**
    * The IPv4 nameservers of the network. If not specified on creation, it will be set with the default nameservers from the network area. If not specified on update, it will remain unchanged.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv4_nameservers Network#ipv4_nameservers}
    */
    readonly ipv4Nameservers?: string[];
    /**
    * The IPv4 prefix of the network (CIDR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv4_prefix Network#ipv4_prefix}
    */
    readonly ipv4Prefix?: string;
    /**
    * The IPv4 prefix length of the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv4_prefix_length Network#ipv4_prefix_length}
    */
    readonly ipv4PrefixLength?: number;
    /**
    * The IPv6 gateway of a network. If not specified, the first IP of the network will be assigned as the gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv6_gateway Network#ipv6_gateway}
    */
    readonly ipv6Gateway?: string;
    /**
    * The IPv6 nameservers of the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv6_nameservers Network#ipv6_nameservers}
    */
    readonly ipv6Nameservers?: string[];
    /**
    * The IPv6 prefix of the network (CIDR).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv6_prefix Network#ipv6_prefix}
    */
    readonly ipv6Prefix?: string;
    /**
    * The IPv6 prefix length of the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#ipv6_prefix_length Network#ipv6_prefix_length}
    */
    readonly ipv6PrefixLength?: number;
    /**
    * Labels are key-value string pairs which can be attached to a resource container
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#labels Network#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * The name of the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#name Network#name}
    */
    readonly name: string;
    /**
    * If set to `true`, the network doesn't have a gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#no_ipv4_gateway Network#no_ipv4_gateway}
    */
    readonly noIpv4Gateway?: boolean | cdktf.IResolvable;
    /**
    * If set to `true`, the network doesn't have a gateway.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#no_ipv6_gateway Network#no_ipv6_gateway}
    */
    readonly noIpv6Gateway?: boolean | cdktf.IResolvable;
    /**
    * STACKIT project ID to which the network is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#project_id Network#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#region Network#region}
    */
    readonly region?: string;
    /**
    * If set to `true`, the network is routed and therefore accessible from other networks.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#routed Network#routed}
    */
    readonly routed?: boolean | cdktf.IResolvable;
    /**
    * The ID of the routing table associated with the network.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#routing_table_id Network#routing_table_id}
    */
    readonly routingTableId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network stackit_network}
*/
export declare class Network extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_network";
    /**
    * Generates CDKTF code for importing a Network resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Network to import
    * @param importFromId The id of the existing Network that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Network to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.86.0/docs/resources/network stackit_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NetworkConfig
    */
    constructor(scope: Construct, id: string, config: NetworkConfig);
    private _dhcp?;
    get dhcp(): boolean | cdktf.IResolvable;
    set dhcp(value: boolean | cdktf.IResolvable);
    resetDhcp(): void;
    get dhcpInput(): boolean | cdktf.IResolvable | undefined;
    get id(): string;
    private _ipv4Gateway?;
    get ipv4Gateway(): string;
    set ipv4Gateway(value: string);
    resetIpv4Gateway(): void;
    get ipv4GatewayInput(): string | undefined;
    private _ipv4Nameservers?;
    get ipv4Nameservers(): string[];
    set ipv4Nameservers(value: string[]);
    resetIpv4Nameservers(): void;
    get ipv4NameserversInput(): string[] | undefined;
    private _ipv4Prefix?;
    get ipv4Prefix(): string;
    set ipv4Prefix(value: string);
    resetIpv4Prefix(): void;
    get ipv4PrefixInput(): string | undefined;
    private _ipv4PrefixLength?;
    get ipv4PrefixLength(): number;
    set ipv4PrefixLength(value: number);
    resetIpv4PrefixLength(): void;
    get ipv4PrefixLengthInput(): number | undefined;
    get ipv4Prefixes(): string[];
    private _ipv6Gateway?;
    get ipv6Gateway(): string;
    set ipv6Gateway(value: string);
    resetIpv6Gateway(): void;
    get ipv6GatewayInput(): string | undefined;
    private _ipv6Nameservers?;
    get ipv6Nameservers(): string[];
    set ipv6Nameservers(value: string[]);
    resetIpv6Nameservers(): void;
    get ipv6NameserversInput(): string[] | undefined;
    private _ipv6Prefix?;
    get ipv6Prefix(): string;
    set ipv6Prefix(value: string);
    resetIpv6Prefix(): void;
    get ipv6PrefixInput(): string | undefined;
    private _ipv6PrefixLength?;
    get ipv6PrefixLength(): number;
    set ipv6PrefixLength(value: number);
    resetIpv6PrefixLength(): void;
    get ipv6PrefixLengthInput(): number | undefined;
    get ipv6Prefixes(): string[];
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkId(): string;
    private _noIpv4Gateway?;
    get noIpv4Gateway(): boolean | cdktf.IResolvable;
    set noIpv4Gateway(value: boolean | cdktf.IResolvable);
    resetNoIpv4Gateway(): void;
    get noIpv4GatewayInput(): boolean | cdktf.IResolvable | undefined;
    private _noIpv6Gateway?;
    get noIpv6Gateway(): boolean | cdktf.IResolvable;
    set noIpv6Gateway(value: boolean | cdktf.IResolvable);
    resetNoIpv6Gateway(): void;
    get noIpv6GatewayInput(): boolean | cdktf.IResolvable | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routed?;
    get routed(): boolean | cdktf.IResolvable;
    set routed(value: boolean | cdktf.IResolvable);
    resetRouted(): void;
    get routedInput(): boolean | cdktf.IResolvable | undefined;
    private _routingTableId?;
    get routingTableId(): string;
    set routingTableId(value: string);
    resetRoutingTableId(): void;
    get routingTableIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
