# `data_stackit_objectstorage_credentials_group`

Refer to the Terraform Registry for docs: [`data_stackit_objectstorage_credentials_group`](https://registry.terraform.io/providers/stackitcloud/stackit/0.93.0/docs/data-sources/objectstorage_credentials_group).
