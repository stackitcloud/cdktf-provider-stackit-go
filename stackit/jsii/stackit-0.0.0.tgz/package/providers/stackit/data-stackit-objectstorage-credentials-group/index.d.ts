import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitObjectstorageCredentialsGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * The credentials group ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group#credentials_group_id DataStackitObjectstorageCredentialsGroup#credentials_group_id}
    */
    readonly credentialsGroupId: string;
    /**
    * Object Storage Project ID to which the credentials group is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group#project_id DataStackitObjectstorageCredentialsGroup#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group#region DataStackitObjectstorageCredentialsGroup#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group stackit_objectstorage_credentials_group}
*/
export declare class DataStackitObjectstorageCredentialsGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_objectstorage_credentials_group";
    /**
    * Generates CDKTF code for importing a DataStackitObjectstorageCredentialsGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitObjectstorageCredentialsGroup to import
    * @param importFromId The id of the existing DataStackitObjectstorageCredentialsGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitObjectstorageCredentialsGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.94.0/docs/data-sources/objectstorage_credentials_group stackit_objectstorage_credentials_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitObjectstorageCredentialsGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitObjectstorageCredentialsGroupConfig);
    private _credentialsGroupId?;
    get credentialsGroupId(): string;
    set credentialsGroupId(value: string);
    get credentialsGroupIdInput(): string | undefined;
    get id(): string;
    get name(): string;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
