# `stackit_secretsmanager_secret_group_role_binding_v1`

Refer to the Terraform Registry for docs: [`stackit_secretsmanager_secret_group_role_binding_v1`](https://registry.terraform.io/providers/stackitcloud/stackit/0.117.0/docs/resources/secretsmanager_secret_group_role_binding_v1).
