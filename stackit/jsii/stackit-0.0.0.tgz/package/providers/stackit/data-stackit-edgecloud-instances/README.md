# `data_stackit_edgecloud_instances`

Refer to the Terraform Registry for docs: [`data_stackit_edgecloud_instances`](https://registry.terraform.io/providers/stackitcloud/stackit/0.99.0/docs/data-sources/edgecloud_instances).
