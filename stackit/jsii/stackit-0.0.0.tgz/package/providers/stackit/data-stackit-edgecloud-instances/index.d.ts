import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitEdgecloudInstancesConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the Edge Cloud instances are associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/edgecloud_instances#project_id DataStackitEdgecloudInstances#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/edgecloud_instances#region DataStackitEdgecloudInstances#region}
    */
    readonly region?: string;
}
export interface DataStackitEdgecloudInstancesInstances {
}
export declare function dataStackitEdgecloudInstancesInstancesToTerraform(struct?: DataStackitEdgecloudInstancesInstances): any;
export declare function dataStackitEdgecloudInstancesInstancesToHclTerraform(struct?: DataStackitEdgecloudInstancesInstances): any;
export declare class DataStackitEdgecloudInstancesInstancesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitEdgecloudInstancesInstances | undefined;
    set internalValue(value: DataStackitEdgecloudInstancesInstances | undefined);
    get created(): string;
    get description(): string;
    get displayName(): string;
    get frontendUrl(): string;
    get instanceId(): string;
    get planId(): string;
    get region(): string;
    get status(): string;
}
export declare class DataStackitEdgecloudInstancesInstancesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitEdgecloudInstancesInstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/edgecloud_instances stackit_edgecloud_instances}
*/
export declare class DataStackitEdgecloudInstances extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_edgecloud_instances";
    /**
    * Generates CDKTF code for importing a DataStackitEdgecloudInstances resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitEdgecloudInstances to import
    * @param importFromId The id of the existing DataStackitEdgecloudInstances that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/edgecloud_instances#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitEdgecloudInstances to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.110.0/docs/data-sources/edgecloud_instances stackit_edgecloud_instances} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitEdgecloudInstancesConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitEdgecloudInstancesConfig);
    get id(): string;
    private _instances;
    get instances(): DataStackitEdgecloudInstancesInstancesList;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
