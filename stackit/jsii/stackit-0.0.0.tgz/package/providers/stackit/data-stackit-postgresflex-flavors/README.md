# `data_stackit_postgresflex_flavors`

Refer to the Terraform Registry for docs: [`data_stackit_postgresflex_flavors`](https://registry.terraform.io/providers/stackitcloud/stackit/0.123.0/docs/data-sources/postgresflex_flavors).
