import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface ObservabilityScrapeconfigConfig extends cdktf.TerraformMetaArguments {
    /**
    * A basic authentication block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#basic_auth ObservabilityScrapeconfig#basic_auth}
    */
    readonly basicAuth?: ObservabilityScrapeconfigBasicAuth;
    /**
    * Observability instance ID to which the scraping job is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#instance_id ObservabilityScrapeconfig#instance_id}
    */
    readonly instanceId: string;
    /**
    * Specifies the job scraping url path. E.g. `/metrics`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#metrics_path ObservabilityScrapeconfig#metrics_path}
    */
    readonly metricsPath: string;
    /**
    * Specifies the name of the scraping job.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#name ObservabilityScrapeconfig#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID to which the scraping job is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#project_id ObservabilityScrapeconfig#project_id}
    */
    readonly projectId: string;
    /**
    * A SAML2 configuration block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#saml2 ObservabilityScrapeconfig#saml2}
    */
    readonly saml2?: ObservabilityScrapeconfigSaml2;
    /**
    * Specifies the scrape sample limit. Upper limit depends on the service plan. Defaults to `5000`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#sample_limit ObservabilityScrapeconfig#sample_limit}
    */
    readonly sampleLimit?: number;
    /**
    * Specifies the http scheme. Defaults to `https`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#scheme ObservabilityScrapeconfig#scheme}
    */
    readonly scheme?: string;
    /**
    * Specifies the scrape interval as duration string. Defaults to `5m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#scrape_interval ObservabilityScrapeconfig#scrape_interval}
    */
    readonly scrapeInterval?: string;
    /**
    * Specifies the scrape timeout as duration string. Defaults to `2m`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#scrape_timeout ObservabilityScrapeconfig#scrape_timeout}
    */
    readonly scrapeTimeout?: string;
    /**
    * The targets list (specified by the static config).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#targets ObservabilityScrapeconfig#targets}
    */
    readonly targets: ObservabilityScrapeconfigTargets[] | cdktf.IResolvable;
}
export interface ObservabilityScrapeconfigBasicAuth {
    /**
    * Specifies basic auth password.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#password ObservabilityScrapeconfig#password}
    */
    readonly password: string;
    /**
    * Specifies basic auth username.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#username ObservabilityScrapeconfig#username}
    */
    readonly username: string;
}
export declare function observabilityScrapeconfigBasicAuthToTerraform(struct?: ObservabilityScrapeconfigBasicAuth | cdktf.IResolvable): any;
export declare function observabilityScrapeconfigBasicAuthToHclTerraform(struct?: ObservabilityScrapeconfigBasicAuth | cdktf.IResolvable): any;
export declare class ObservabilityScrapeconfigBasicAuthOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObservabilityScrapeconfigBasicAuth | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityScrapeconfigBasicAuth | cdktf.IResolvable | undefined);
    private _password?;
    get password(): string;
    set password(value: string);
    get passwordInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    get usernameInput(): string | undefined;
}
export interface ObservabilityScrapeconfigSaml2 {
    /**
    * Specifies if URL parameters are enabled. Defaults to `true`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#enable_url_parameters ObservabilityScrapeconfig#enable_url_parameters}
    */
    readonly enableUrlParameters?: boolean | cdktf.IResolvable;
}
export declare function observabilityScrapeconfigSaml2ToTerraform(struct?: ObservabilityScrapeconfigSaml2 | cdktf.IResolvable): any;
export declare function observabilityScrapeconfigSaml2ToHclTerraform(struct?: ObservabilityScrapeconfigSaml2 | cdktf.IResolvable): any;
export declare class ObservabilityScrapeconfigSaml2OutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ObservabilityScrapeconfigSaml2 | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityScrapeconfigSaml2 | cdktf.IResolvable | undefined);
    private _enableUrlParameters?;
    get enableUrlParameters(): boolean | cdktf.IResolvable;
    set enableUrlParameters(value: boolean | cdktf.IResolvable);
    resetEnableUrlParameters(): void;
    get enableUrlParametersInput(): boolean | cdktf.IResolvable | undefined;
}
export interface ObservabilityScrapeconfigTargets {
    /**
    * Specifies labels.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#labels ObservabilityScrapeconfig#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Specifies target URLs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#urls ObservabilityScrapeconfig#urls}
    */
    readonly urls: string[];
}
export declare function observabilityScrapeconfigTargetsToTerraform(struct?: ObservabilityScrapeconfigTargets | cdktf.IResolvable): any;
export declare function observabilityScrapeconfigTargetsToHclTerraform(struct?: ObservabilityScrapeconfigTargets | cdktf.IResolvable): any;
export declare class ObservabilityScrapeconfigTargetsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ObservabilityScrapeconfigTargets | cdktf.IResolvable | undefined;
    set internalValue(value: ObservabilityScrapeconfigTargets | cdktf.IResolvable | undefined);
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _urls?;
    get urls(): string[];
    set urls(value: string[]);
    get urlsInput(): string[] | undefined;
}
export declare class ObservabilityScrapeconfigTargetsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    internalValue?: ObservabilityScrapeconfigTargets[] | cdktf.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ObservabilityScrapeconfigTargetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig stackit_observability_scrapeconfig}
*/
export declare class ObservabilityScrapeconfig extends cdktf.TerraformResource {
    static readonly tfResourceType = "stackit_observability_scrapeconfig";
    /**
    * Generates CDKTF code for importing a ObservabilityScrapeconfig resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ObservabilityScrapeconfig to import
    * @param importFromId The id of the existing ObservabilityScrapeconfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ObservabilityScrapeconfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.90.0/docs/resources/observability_scrapeconfig stackit_observability_scrapeconfig} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ObservabilityScrapeconfigConfig
    */
    constructor(scope: Construct, id: string, config: ObservabilityScrapeconfigConfig);
    private _basicAuth;
    get basicAuth(): ObservabilityScrapeconfigBasicAuthOutputReference;
    putBasicAuth(value: ObservabilityScrapeconfigBasicAuth): void;
    resetBasicAuth(): void;
    get basicAuthInput(): cdktf.IResolvable | ObservabilityScrapeconfigBasicAuth | undefined;
    get id(): string;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    private _metricsPath?;
    get metricsPath(): string;
    set metricsPath(value: string);
    get metricsPathInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _saml2;
    get saml2(): ObservabilityScrapeconfigSaml2OutputReference;
    putSaml2(value: ObservabilityScrapeconfigSaml2): void;
    resetSaml2(): void;
    get saml2Input(): cdktf.IResolvable | ObservabilityScrapeconfigSaml2 | undefined;
    private _sampleLimit?;
    get sampleLimit(): number;
    set sampleLimit(value: number);
    resetSampleLimit(): void;
    get sampleLimitInput(): number | undefined;
    private _scheme?;
    get scheme(): string;
    set scheme(value: string);
    resetScheme(): void;
    get schemeInput(): string | undefined;
    private _scrapeInterval?;
    get scrapeInterval(): string;
    set scrapeInterval(value: string);
    resetScrapeInterval(): void;
    get scrapeIntervalInput(): string | undefined;
    private _scrapeTimeout?;
    get scrapeTimeout(): string;
    set scrapeTimeout(value: string);
    resetScrapeTimeout(): void;
    get scrapeTimeoutInput(): string | undefined;
    private _targets;
    get targets(): ObservabilityScrapeconfigTargetsList;
    putTargets(value: ObservabilityScrapeconfigTargets[] | cdktf.IResolvable): void;
    get targetsInput(): cdktf.IResolvable | ObservabilityScrapeconfigTargets[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
