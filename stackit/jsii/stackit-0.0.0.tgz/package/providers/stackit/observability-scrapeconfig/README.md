# `stackit_observability_scrapeconfig`

Refer to the Terraform Registry for docs: [`stackit_observability_scrapeconfig`](https://registry.terraform.io/providers/stackitcloud/stackit/0.119.0/docs/resources/observability_scrapeconfig).
