import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitServerConfig extends cdktf.TerraformMetaArguments {
    /**
    * STACKIT project ID to which the server is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server#project_id DataStackitServer#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server#region DataStackitServer#region}
    */
    readonly region?: string;
    /**
    * The server ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server#server_id DataStackitServer#server_id}
    */
    readonly serverId: string;
}
export interface DataStackitServerBootVolume {
}
export declare function dataStackitServerBootVolumeToTerraform(struct?: DataStackitServerBootVolume): any;
export declare function dataStackitServerBootVolumeToHclTerraform(struct?: DataStackitServerBootVolume): any;
export declare class DataStackitServerBootVolumeOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitServerBootVolume | undefined;
    set internalValue(value: DataStackitServerBootVolume | undefined);
    get deleteOnTermination(): cdktf.IResolvable;
    get id(): string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server stackit_server}
*/
export declare class DataStackitServer extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_server";
    /**
    * Generates CDKTF code for importing a DataStackitServer resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitServer to import
    * @param importFromId The id of the existing DataStackitServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.83.0/docs/data-sources/server stackit_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitServerConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitServerConfig);
    get affinityGroup(): string;
    get availabilityZone(): string;
    private _bootVolume;
    get bootVolume(): DataStackitServerBootVolumeOutputReference;
    get createdAt(): string;
    get id(): string;
    get imageId(): string;
    get keypairName(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get launchedAt(): string;
    get machineType(): string;
    get name(): string;
    get networkInterfaces(): string[];
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverId?;
    get serverId(): string;
    set serverId(value: string);
    get serverIdInput(): string | undefined;
    get updatedAt(): string;
    get userData(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
