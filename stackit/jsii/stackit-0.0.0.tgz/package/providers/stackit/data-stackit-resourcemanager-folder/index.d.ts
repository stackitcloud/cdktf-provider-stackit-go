import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitResourcemanagerFolderConfig extends cdktf.TerraformMetaArguments {
    /**
    * Folder container ID. Globally unique, user-friendly identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/resourcemanager_folder#container_id DataStackitResourcemanagerFolder#container_id}
    */
    readonly containerId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/resourcemanager_folder stackit_resourcemanager_folder}
*/
export declare class DataStackitResourcemanagerFolder extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_resourcemanager_folder";
    /**
    * Generates CDKTF code for importing a DataStackitResourcemanagerFolder resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitResourcemanagerFolder to import
    * @param importFromId The id of the existing DataStackitResourcemanagerFolder that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/resourcemanager_folder#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitResourcemanagerFolder to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.97.0/docs/data-sources/resourcemanager_folder stackit_resourcemanager_folder} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitResourcemanagerFolderConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitResourcemanagerFolderConfig);
    private _containerId?;
    get containerId(): string;
    set containerId(value: string);
    get containerIdInput(): string | undefined;
    get creationTime(): string;
    get folderId(): string;
    get id(): string;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    get parentContainerId(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
