import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitAlbWafCustomRuleGroupConfig extends cdktf.TerraformMetaArguments {
    /**
    * Custom rule group configuration name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group#name DataStackitAlbWafCustomRuleGroup#name}
    */
    readonly name: string;
    /**
    * STACKIT project ID associated with the ALB WAF Custom Rule Group.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group#project_id DataStackitAlbWafCustomRuleGroup#project_id}
    */
    readonly projectId: string;
    /**
    * STACKIT region name the resource is located in. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group#region DataStackitAlbWafCustomRuleGroup#region}
    */
    readonly region?: string;
}
export interface DataStackitAlbWafCustomRuleGroupRulesBehavior {
}
export declare function dataStackitAlbWafCustomRuleGroupRulesBehaviorToTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesBehavior): any;
export declare function dataStackitAlbWafCustomRuleGroupRulesBehaviorToHclTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesBehavior): any;
export declare class DataStackitAlbWafCustomRuleGroupRulesBehaviorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitAlbWafCustomRuleGroupRulesBehavior | undefined;
    set internalValue(value: DataStackitAlbWafCustomRuleGroupRulesBehavior | undefined);
    get action(): string;
    get log(): cdktf.IResolvable;
    get logMsg(): string;
    get severity(): string;
}
export interface DataStackitAlbWafCustomRuleGroupRulesConditionsOperator {
}
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsOperatorToTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditionsOperator): any;
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsOperatorToHclTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditionsOperator): any;
export declare class DataStackitAlbWafCustomRuleGroupRulesConditionsOperatorOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitAlbWafCustomRuleGroupRulesConditionsOperator | undefined;
    set internalValue(value: DataStackitAlbWafCustomRuleGroupRulesConditionsOperator | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitAlbWafCustomRuleGroupRulesConditionsVariable {
}
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsVariableToTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditionsVariable): any;
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsVariableToHclTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditionsVariable): any;
export declare class DataStackitAlbWafCustomRuleGroupRulesConditionsVariableOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataStackitAlbWafCustomRuleGroupRulesConditionsVariable | undefined;
    set internalValue(value: DataStackitAlbWafCustomRuleGroupRulesConditionsVariable | undefined);
    get type(): string;
    get value(): string;
}
export interface DataStackitAlbWafCustomRuleGroupRulesConditions {
}
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsToTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditions): any;
export declare function dataStackitAlbWafCustomRuleGroupRulesConditionsToHclTerraform(struct?: DataStackitAlbWafCustomRuleGroupRulesConditions): any;
export declare class DataStackitAlbWafCustomRuleGroupRulesConditionsOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitAlbWafCustomRuleGroupRulesConditions | undefined;
    set internalValue(value: DataStackitAlbWafCustomRuleGroupRulesConditions | undefined);
    private _operator;
    get operator(): DataStackitAlbWafCustomRuleGroupRulesConditionsOperatorOutputReference;
    get transformations(): string[];
    private _variable;
    get variable(): DataStackitAlbWafCustomRuleGroupRulesConditionsVariableOutputReference;
}
export declare class DataStackitAlbWafCustomRuleGroupRulesConditionsList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitAlbWafCustomRuleGroupRulesConditionsOutputReference;
}
export interface DataStackitAlbWafCustomRuleGroupRules {
}
export declare function dataStackitAlbWafCustomRuleGroupRulesToTerraform(struct?: DataStackitAlbWafCustomRuleGroupRules): any;
export declare function dataStackitAlbWafCustomRuleGroupRulesToHclTerraform(struct?: DataStackitAlbWafCustomRuleGroupRules): any;
export declare class DataStackitAlbWafCustomRuleGroupRulesOutputReference extends cdktf.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataStackitAlbWafCustomRuleGroupRules | undefined;
    set internalValue(value: DataStackitAlbWafCustomRuleGroupRules | undefined);
    private _behavior;
    get behavior(): DataStackitAlbWafCustomRuleGroupRulesBehaviorOutputReference;
    private _conditions;
    get conditions(): DataStackitAlbWafCustomRuleGroupRulesConditionsList;
    get description(): string;
    get id(): number;
}
export declare class DataStackitAlbWafCustomRuleGroupRulesList extends cdktf.ComplexList {
    protected terraformResource: cdktf.IInterpolatingParent;
    protected terraformAttribute: string;
    protected wrapsSet: boolean;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktf.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataStackitAlbWafCustomRuleGroupRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group stackit_alb_waf_custom_rule_group}
*/
export declare class DataStackitAlbWafCustomRuleGroup extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_alb_waf_custom_rule_group";
    /**
    * Generates CDKTF code for importing a DataStackitAlbWafCustomRuleGroup resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitAlbWafCustomRuleGroup to import
    * @param importFromId The id of the existing DataStackitAlbWafCustomRuleGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitAlbWafCustomRuleGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.112.0/docs/data-sources/alb_waf_custom_rule_group stackit_alb_waf_custom_rule_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitAlbWafCustomRuleGroupConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitAlbWafCustomRuleGroupConfig);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): DataStackitAlbWafCustomRuleGroupRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
