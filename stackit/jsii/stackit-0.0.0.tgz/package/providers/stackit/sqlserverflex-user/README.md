# `stackit_sqlserverflex_user`

Refer to the Terraform Registry for docs: [`stackit_sqlserverflex_user`](https://registry.terraform.io/providers/stackitcloud/stackit/0.117.0/docs/resources/sqlserverflex_user).
