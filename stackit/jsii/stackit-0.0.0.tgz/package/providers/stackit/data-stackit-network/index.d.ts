import { Construct } from 'constructs';
import * as cdktf from 'cdktf';
export interface DataStackitNetworkConfig extends cdktf.TerraformMetaArguments {
    /**
    * The IPv4 VPC network range ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#ipv4_vpc_network_range_id DataStackitNetwork#ipv4_vpc_network_range_id}
    */
    readonly ipv4VpcNetworkRangeId?: string;
    /**
    * The IPv6 VPC network range ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#ipv6_vpc_network_range_id DataStackitNetwork#ipv6_vpc_network_range_id}
    */
    readonly ipv6VpcNetworkRangeId?: string;
    /**
    * The network ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#network_id DataStackitNetwork#network_id}
    */
    readonly networkId: string;
    /**
    * STACKIT project ID to which the network is associated.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#project_id DataStackitNetwork#project_id}
    */
    readonly projectId: string;
    /**
    * The resource region. If not defined, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#region DataStackitNetwork#region}
    */
    readonly region?: string;
    /**
    * The ID of the VPC the network is associated with.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#vpc_id DataStackitNetwork#vpc_id}
    */
    readonly vpcId?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network stackit_network}
*/
export declare class DataStackitNetwork extends cdktf.TerraformDataSource {
    static readonly tfResourceType = "stackit_network";
    /**
    * Generates CDKTF code for importing a DataStackitNetwork resource upon running "cdktf plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataStackitNetwork to import
    * @param importFromId The id of the existing DataStackitNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataStackitNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktf.TerraformProvider): cdktf.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/stackitcloud/stackit/0.107.0/docs/data-sources/network stackit_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataStackitNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataStackitNetworkConfig);
    get dhcp(): cdktf.IResolvable;
    get id(): string;
    get ipv4Gateway(): string;
    get ipv4Nameservers(): string[];
    get ipv4Prefix(): string;
    get ipv4PrefixLength(): number;
    get ipv4Prefixes(): string[];
    private _ipv4VpcNetworkRangeId?;
    get ipv4VpcNetworkRangeId(): string;
    set ipv4VpcNetworkRangeId(value: string);
    resetIpv4VpcNetworkRangeId(): void;
    get ipv4VpcNetworkRangeIdInput(): string | undefined;
    get ipv6Gateway(): string;
    get ipv6Nameservers(): string[];
    get ipv6Prefix(): string;
    get ipv6PrefixLength(): number;
    get ipv6Prefixes(): string[];
    private _ipv6VpcNetworkRangeId?;
    get ipv6VpcNetworkRangeId(): string;
    set ipv6VpcNetworkRangeId(value: string);
    resetIpv6VpcNetworkRangeId(): void;
    get ipv6VpcNetworkRangeIdInput(): string | undefined;
    private _labels;
    get labels(): cdktf.StringMap;
    get name(): string;
    private _networkId?;
    get networkId(): string;
    set networkId(value: string);
    get networkIdInput(): string | undefined;
    private _projectId?;
    get projectId(): string;
    set projectId(value: string);
    get projectIdInput(): string | undefined;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routed(): cdktf.IResolvable;
    get routingTableId(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
